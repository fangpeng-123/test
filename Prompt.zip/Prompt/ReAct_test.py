import os
from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_community.agent_toolkits.load_tools import load_tools
from langchain.agents import AgentType, initialize_agent

# 加载环境变量
load_dotenv()
os.environ["SERPAPI_API_KEY"] = os.getenv("SERPAPI_API_KEY")
base_url = os.getenv("base_url")
api_key  = os.getenv("api_key")

# 初始化 LLM
llm = init_chat_model(
    model="Qwen/Qwen3-8B",
    model_provider="openai",
    base_url=base_url,
    api_key=api_key
)

# 加载工具
tools = load_tools(["serpapi", "llm-math"], llm=llm)

# 创建 Agent
agent = initialize_agent(
    tools,
    llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True,
    handle_parsing_errors=True   # 方便调试
)

# 运行（注意用字典传参）
result = agent.invoke({"input": "奥利维亚·王尔德的男朋友是谁?他现在的年龄的0.23次方是多少?"})
print(result["output"])