from modelscope.models import Model
from transformers import AutoTokenizer
import torch

# 本地模型路径
model_path = "/home/yls/.cache/modelscope/hub/models/Qwen/Qwen3-0.6B"

# 使用 transformers 加载 tokenizer
tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)

# 使用 ModelScope 加载模型
model = Model.from_pretrained(model_path, trust_remote_code=True)

# 移动到 GPU（如果可用）
device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)
model.eval()

# 输入文本
prompt = "'apple' 这个单词中有几个 'p' 字母"
inputs = tokenizer(prompt, return_tensors="pt").to(device)

# 生成输出
with torch.no_grad():
    outputs = model.generate(
        **inputs,
        max_new_tokens=128,
        do_sample=True,
        temperature=0.7,
        top_p=0.9
    )

# 解码结果
response = tokenizer.decode(outputs[0], skip_special_tokens=True)
print("回复：", response)