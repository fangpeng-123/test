# 魔搭社区下载模型位置
/home/yls/.cache/modelscope/hub/models/Qwen/Qwen3-0.6B