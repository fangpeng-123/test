import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

np.random.seed(0)
X = np.random.rand(100,1)
y = 2 + 3 * X + np.random.rand(100,1)

model = LinearRegression()
model.fit(X, y)

X_test = np.array([[0], [1]])
y_pred = model.predict(X_test)

plt.figure(figsize=(10, 6))
plt.scatter(X, y, color = 'b', label = 'Data points')
plt.plot(X_test, y_pred, color = 'r', label = 'Regression line')
plt.legend()
plt.xlabel('X')
plt.ylabel('y')
plt.title('Liner Regression Example\nimage by iCare fp')
plt.savefig(
    fname="/media/yls/1T硬盘/picture/Linear Regression.png",   # 文件路径 + 名称（自动创建目录需手动处理）
    format="png",              # 图像格式（可省略，由后缀自动识别）
)
plt.show()


print(f"Intercept: {model.intercept_[0]:.2f}")
print(f"Coefficient: {model.coef_[0]:.2f}")