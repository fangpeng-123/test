import numpy as np
from sklearn.linear_model import LogisticRegression   # Python中的机器学习库，基于Numpy和Scipy构建的开源库，提供了大量用于数据挖掘、数据分析和机器学习任务的工具
import matplotlib.pyplot as plt

hours_studied = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape(-1, 1) # 使用reshape()函数把一个行向量变成了列向量
outcome = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 1])

model = LogisticRegression()
model.fit(hours_studied, outcome)

predicted_outcome = model.predict(hours_studied)
predicted_probabilities = model.predict_proba(hours_studied)

plt.figure(figsize=(10, 6))
plt.scatter(hours_studied, outcome, color = 'b', label = 'Data points')
# 使用 hours_studied 作为 x 轴，第二列（正类的概率）作为 y 轴
plt.plot(hours_studied, predicted_probabilities[:, 1], color = 'r', label = 'Logistic line')
plt.legend()
plt.xlabel('hours_studied')
plt.ylabel('probility of passing')
plt.title('Logistic Regression Example\nimage by iCare fp')
plt.savefig(
    fname="/media/yls/1T硬盘/picture/Logistic Regression.png",   # 文件路径 + 名称（自动创建目录需手动处理）
    format="png",              # 图像格式（可省略，由后缀自动识别）
)
plt.show()

print("Predicted Outcomes:", predicted_outcome)
print("Predicted Probabilities", predicted_probabilities)