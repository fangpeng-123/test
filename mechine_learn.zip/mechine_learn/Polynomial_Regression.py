from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Ridge
import numpy as np
import matplotlib.pyplot as plt

np.random.seed(0)
X = np.sort(5 * np.random.rand(80,1), axis = 0)
y = np.sin(X).ravel() + np.random.normal(0, 0.1, X.shape[0])

degree = 5
model = make_pipeline(PolynomialFeatures(degree), Ridge(alpha = 1e-3))
model.fit(X, y)

X_test = np.linspace(0, 5, 100)[:, np.newaxis]
y_pred = model.predict(X_test)

plt.scatter(X, y, color = 'b', label = 'Data points')
plt.plot(X_test, y_pred, color = 'r', label = 'Polynomial regrression')
plt.legend()
plt.xlabel('X')
plt.ylabel('y')
plt.title("Polynomial Regression with Ridge Regularrization")
plt.savefig('/media/yls/1T硬盘/picture/polynomial regression.png')
plt.show()