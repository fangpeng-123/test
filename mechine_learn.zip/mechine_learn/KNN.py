from sklearn.neighbors import KNeighborsClassifier
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt
import numpy as np

# 加载数据集
iris = load_iris()
X, y = iris.data, iris.target

# 只取前两个特征进行训练和预测
X_subset = X[:, [0, 1]]

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_subset, y, test_size=0.3, random_state=42)

# 创建并训练KNN分类器
model = KNeighborsClassifier(n_neighbors=3)
model.fit(X_train, y_train)

# 测试评估
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.2f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=iris.target_names))

# 绘制决策边界函数
def plot_decision_boundary(X, y, model, ax=None):
    h = .02
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                          np.arange(y_min, y_max, h))
    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    if ax is None:
        ax = plt.gca()
    ax.contourf(xx, yy, Z, alpha=0.8, cmap=plt.cm.RdYlBu)
    ax.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.RdYlBu, edgecolors='black', s=25)
    ax.set_xlabel('Sepal length')
    ax.set_ylabel('Sepal width')
    return ax

# 绘图显示
plt.figure(figsize=(10, 8))
plot_decision_boundary(X_subset, y, model)
plt.title('KNN Decision Boundary (k=3) using Sepal Length & Width \nmade by iCare fp')
plt.savefig(
    fname="/media/yls/1T硬盘/picture/Decision tree.png",
    format="png",
)
plt.show()