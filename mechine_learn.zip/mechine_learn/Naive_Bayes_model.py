import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report

# 准备数据：10封邮件样本
emails = [
    "优惠促销 免费赠品",
    "会议通知 项目进度",
    "免费获取 限时优惠",
    "周报提交 项目计划",
    "团队会议 工作总结",
    "限时折扣 免费试用",  # 你可以加入更多样本
    "项目总结 团队协作",
    "促销活动 抽奖优惠",
    "工作安排 会议记录",
    "免费课程 限时报名"
]

# 标签：0=正常邮件，1=垃圾邮件
labels = [1, 0, 1, 0, 0, 1, 0, 1, 0, 1]

# 步骤1：划分训练集和测试集（70%用于训练，30%用于测试）
X_train, X_test, y_train, y_test = train_test_split(
    emails, labels, test_size=0.3, random_state=42
)

# 步骤2：将文本转换为词频特征（词袋模型）
vectorizer = CountVectorizer()
X_train_counts = vectorizer.fit_transform(X_train)
X_test_counts = vectorizer.transform(X_test)

# 步骤3：训练朴素贝叶斯模型（使用多项式变体，适合文本）
model = MultinomialNB(alpha=1.0)  # alpha=1.0表示使用拉普拉斯平滑
model.fit(X_train_counts, y_train)

# 步骤4：在测试集上评估模型
y_pred = model.predict(X_test_counts)
accuracy = accuracy_score(y_test, y_pred)
report = classification_report(y_test, y_pred, target_names=["正常邮件", "垃圾邮件"])

print(f"模型准确率: {accuracy:.2f}")
print("\n详细评估报告:")
print(report)

# 步骤5：尝试对新邮件进行分类
new_emails = ["团队优惠 项目促销", "免费获取 限时折扣", "项目会议 工作安排"]
new_counts = vectorizer.transform(new_emails)
predictions = model.predict(new_counts)
probabilities = model.predict_proba(new_counts)

# 输出预测结果及概率
print("\n新邮件分类结果:")
for email, prediction, proba in zip(new_emails, predictions, probabilities):
    category = "垃圾邮件" if prediction == 1 else "正常邮件"
    print(f"'{email}' → {category}")
    print(f"  - 是正常邮件的概率: {proba[0]:.2f}, 是垃圾邮件的概率: {proba[1]:.2f}")
