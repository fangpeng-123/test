import requests
import json

url = "http://192.168.1.28/v1/chat-messages"
headers = {
    "Authorization": "Bearer app-kPdQWVvNqI6b7zoJ2OVGUQFB",  # 替换为你的API Key
    "Content-Type": "application/json"
}
payload = {
    "inputs": {},
    "query": "今天杭州的天气如何？",
    "response_mode": "streaming",
    "conversation_id": "",
    "user": "decade",
    "files": [
        {
            "type": "image",
            "transfer_method": "remote_url",
            "url": "https://cloud.dify.ai/logo/logo-site.png"
        }
    ]
}

# 发起流式请求
response = requests.post(url, headers=headers, json=payload, stream=True)

answer_parts = []
for line in response.iter_lines():
    if line:
        text = line.decode('utf-8')
        if text.startswith("data: "):
            try:
                event = json.loads(text[6:])
                # 提取流式返回的自然语言部分
                if event.get("event") in ["agent_message", "message"]:
                    ans = event.get("answer", "")
                    if ans:
                        answer_parts.append(ans)
            except Exception:
                continue

# 拼接完整答案
final_answer = ''.join(answer_parts)
print("Agent answer:", final_answer)
