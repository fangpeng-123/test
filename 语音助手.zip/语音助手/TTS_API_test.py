import requests
import base64

# API配置
API_URL = "http://192.168.1.28:8000/tts"
API_KEY = "iCare20250828"

# 请求数据
data = {
    "texts": [
        "实时率等于识别花的时间除以语音本身的时间", 
        "尝试持用不同版本的源码以及手动下载和脚本下载模型文件的方式进行模型部署"
    ],
    "speed": 1.0
}

# 设置请求头
headers = {
    "Content-Type": "application/json",
    "X-API-Key": API_KEY
}

# 发送请求
response = requests.post(API_URL, json=data, headers=headers)

if response.status_code == 200:
    result = response.json()
    if result["success"]:
        # 保存音频文件
        for i, audio_data in enumerate(result["audio_data"]):
            audio_bytes = base64.b64decode(audio_data)
            with open(f"output_{i}.wav", "wb") as f:
                f.write(audio_bytes)
        print("音频生成成功")
    else:
        print(f"错误: {result['message']}")
else:
    print(f"请求失败: {response.status_code} - {response.text}")