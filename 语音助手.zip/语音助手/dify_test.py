import os 
import json
import playsound
from pathlib import Path
from openai import OpenAI
import pyaudio
import dashscope
from dashscope.audio.asr import *
import threading
import requests
import time

# 设置 DashScope API Key
dashscope.api_key = "sk-60f37b1aca9a4e78acde3bf2ac2f21cd"

# 定义目标 API 配置
headers = {
    "Authorization": "Bearer app-kPdQWVvNqI6b7zoJ2OVGUQFB",
    "Content-Type": "application/json"
}

# 全局变量
mic = None
stream = None

class Callback(TranslationRecognizerCallback):
    def __init__(self):
        super().__init__()
        self.transcriptions = []  # 存储识别结果
        self.last_send_time = time.time()  # 上次发送时间
        self.lock = threading.Lock()  # 线程锁
        self.running = True
        # 启动定时器线程
        self.timer_thread = threading.Thread(target=self._timer_loop, daemon=True)
        self.timer_thread.start()

    def _timer_loop(self):
        """每1秒检查一次是否该发送数据"""
        while self.running:
            time.sleep(1)
            current_time = time.time()
            if current_time - self.last_send_time >= 5:
                self._send_collected_data()

    def _send_collected_data(self):
        with self.lock:
            if not self.transcriptions:
                return 
            current_time = time.time()
            filtered = [item for item in self.transcriptions
                        if current_time - item["timestamp"] <= 5]
            print(f"[DEBUG] 拼接后数据：{filtered}")

            if not filtered:
                return 

            query = " ".join([item["text"].strip() for item in filtered if item["text"].strip()])
            print(f"[DEBUG] 拼接后的 query : {query}")

            payload = {
                "inputs": {},
                "query": query,
                "response_mode": "streaming",
                "conversation_id": "",
                "user": "decade",
                "files": [
                    {
                        "type": "image",
                        "transfer_method": "remote_url",
                        "url": "https://cloud.dify.ai/logo/logo-site.png"
                    }
                ]
            }

            try:
                # 启用流式请求
                response = requests.post(
                    url="http://192.168.1.28/v1/chat-messages",
                    headers=headers,
                    json=payload,
                    timeout=20,
                    stream=True  # 👈 关键：启用流式响应
                )
                print(f"[DEBUG] API 响应状态码：{response.status_code}")

                answer_parts = []  # 存储流式返回的 answer 片段
                for line in response.iter_lines():
                    if line:
                        text = line.decode('utf-8')
                        if text.startswith("data: "):
                            try:
                                event = json.loads(text[6:])  # 去除 "data: " 前缀
                                if event.get("event") in ["agent_message", "message"]:
                                    ans = event.get("answer", "")
                                    if ans:
                                        answer_parts.append(ans)
                                        print(f"[INFO] 流式回答片段: {ans}")
                                elif event.get("event") == "message_end":
                                    print(f"[INFO] 完整回答: {''.join(answer_parts)}")
                            except json.JSONDecodeError as e:
                                print(f"[ERROR] JSON 解析失败: {e}")
                                continue
            except Exception as e:
                print(f"[ERROR] 请求失败：{e}")

            # 清空5秒内数据
            self.transcriptions = [item for item in self.transcriptions
                                if current_time - item["timestamp"] > 5]
            self.last_send_time = current_time  # 更新发送时间

    def on_open(self) -> None:
        global mic, stream
        print("TranslationRecognizerCallback open.")
        mic = pyaudio.PyAudio()
        stream = mic.open(
            format=pyaudio.paInt16, channels=1, rate=16000, input=True
        )

    def on_close(self) -> None:
        global mic, stream
        print("TranslationRecognizerCallback close.")
        stream.stop_stream()
        stream.close()
        mic.terminate()
        stream = None
        mic = None

    def on_event(
        self,
        request_id,
        transcription_result: TranscriptionResult,
        translation_result: TranslationResult,
        usage,
    ) -> None:
        if transcription_result is not None:
            with self.lock:
                self.transcriptions.append({
                    "sentence_id": transcription_result.sentence_id,    
                    "text": transcription_result.text,
                    "timestamp": time.time()
                })
                # 添加调试输出
                print(f"[DEBUG] 新增识别内容：{transcription_result.text}")

if __name__ == "__main__":
    callback = Callback()
    translator = TranslationRecognizerRealtime(
        model="gummy-realtime-v1",
        format="pcm",
        sample_rate=16000,
        transcription_enabled=True,
        translation_enabled=False,  # 关闭翻译功能
        callback=callback,
    )
    translator.start()
    print("请您通过麦克风讲话，每5秒的语音内容会作为输入发送到指定API")
    try:
        while True:
            if stream:
                data = stream.read(3200, exception_on_overflow=False)
                translator.send_audio_frame(data)
            else:
                break
    except KeyboardInterrupt:
        print("程序已终止")
    finally:
        translator.stop()