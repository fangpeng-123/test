import os 
import json
import playsound
from pathlib import Path
from openai import OpenAI
import pyaudio
import dashscope
from dashscope.audio.asr import *
import threading
import requests
import time

# 设置 DashScope API Key
dashscope.api_key = "sk-60f37b1aca9a4e78acde3bf2ac2f21cd"

# 定义目标 API 配置
headers = {
    "Authorization": "Bearer app-kPdQWVvNqI6b7zoJ2OVGUQFB",
    "Content-Type": "application/json"
}

# 全局变量
mic = None
stream = None

class SpeechSynthesizer:
    def __init__(self, api_key, base_url):
        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url
        )
        
    def generate_and_play_speech(self, text, model="FunAudioLLM/CosyVoice2-0.5B", 
                               voice="FunAudioLLM/CosyVoice2-0.5B:claire"):
        """
        根据文本生成语音并播放
        
        参数:
            text (str): 需要合成的文本
            model (str): 使用的TTS模型
            voice (str): 使用的音色
        """
        try:
            # 生成唯一文件名避免冲突
            speech_file_path = Path(__file__).parent / f"temp_speech_{int(time.time())}.mp3"
            
            print("[INFO] 正在生成语音...")
            
            # 调用TTS接口生成语音文件
            with self.client.audio.speech.with_streaming_response.create(
                model=model,
                voice=voice,
                input=text,
                response_format="mp3"
            ) as response:
                response.stream_to_file(speech_file_path)
            
            # 播放语音
            print("[INFO] 正在播放语音...")
            playsound.playsound(str(speech_file_path))
            
            # 清理临时文件
            os.remove(speech_file_path)
            print("[INFO] 语音播放完成，临时文件已删除")
            
        except Exception as e:
            print(f"[ERROR] 语音合成或播放失败: {e}")
            # 确保即使出错也清理文件
            if 'speech_file_path' in locals() and speech_file_path.exists():
                os.remove(speech_file_path)

class Callback(TranslationRecognizerCallback):
    def __init__(self, synthesizer):
        super().__init__()
        self.transcriptions = []  # 存储识别结果
        self.last_send_time = time.time()  # 上次发送时间
        self.lock = threading.Lock()  # 线程锁
        self.running = True
        self.synthesizer = synthesizer  # TTS合成器实例
        # 启动定时器线程
        self.timer_thread = threading.Thread(target=self._timer_loop, daemon=True)
        self.timer_thread.start()

    def _timer_loop(self):
        """每1秒检查一次是否该发送数据"""
        while self.running:
            time.sleep(1)
            current_time = time.time()
            if current_time - self.last_send_time >= 5:
                self._send_collected_data()

    def _send_collected_data(self):
        with self.lock:
            if not self.transcriptions:
                return 
            
            current_time = time.time()

            # 只保留最近5秒内的识别结果
            filtered = [item for item in self.transcriptions
                        if current_time - item["timestamp"] <= 5]
            
            if not filtered:
                return 
            
            # 按照 sentence_id 分组， 取每个句子的最新文本
            sentence_dict = {}
            for item in filtered:
                sid = item["sentence_id"]
                # 只保留该 sentence_id 的最新文本（最长或完整）
                if sid not in sentence_dict or len(item["text"]) > len(sentence_dict[sid]["text"]):
                    sentence_dict[sid] = item

            # 取出所有最完整的文本（sentence_id 崔在即为完整句）
            # 可以选择只发送最后一个完整句子(最符合要求)
            complete_sentences = [item["text"].strip() for item in sentence_dict.values() if item["text"].strip()]

            if not complete_sentences:
                return 
            
            # 只发送最后一个完整句子（推荐）
            query = complete_sentences[-1]
            # 发送完整句子
            # query = " ".join(complete_sentences)
            if len(query.strip()) < 2:
                return # 忽略太短的输入
            print(f"[DEBUG] 拼接后的 query : {query}")

            payload = {
                "inputs": {},
                "query": query,
                "response_mode": "streaming",
                "conversation_id": "",
                "user": "decade",
                "files": [
                    {
                        "type": "image",
                        "transfer_method": "remote_url",
                        "url": "https://cloud.dify.ai/logo/logo-site.png"
                    }
                ]
            }

            try:
                # 启用流式请求
                response = requests.post(
                    url="http://192.168.1.28/v1/chat-messages",
                    headers=headers,
                    json=payload,
                    timeout=20,
                    stream=True  #  关键：启用流式响应
                )
                print(f"[DEBUG] API 响应状态码：{response.status_code}")

                answer_parts = []  # 存储流式返回的 answer 片段
                for line in response.iter_lines():
                    if line:
                        text = line.decode('utf-8')
                        if text.startswith("data: "):
                            try:
                                event = json.loads(text[6:])  # 去除 "data: " 前缀
                                if event.get("event") in ["agent_message", "message"]:
                                    ans = event.get("answer", "")
                                    if ans:
                                        answer_parts.append(ans)
                                        print(f"[INFO] 流式回答片段: {ans}")
                                elif event.get("event") == "message_end":
                                    final_answer = ''.join(answer_parts)
                                    print(f"[INFO] 完整回答: {final_answer}")
                                    
                                    # 调用语音合成
                                    self.synthesizer.generate_and_play_speech(final_answer)
                            except json.JSONDecodeError as e:
                                print(f"[ERROR] JSON 解析失败: {e}")
                                continue
            except Exception as e:
                print(f"[ERROR] 请求失败：{e}")

            # 清空5秒内数据
            self.transcriptions = [item for item in self.transcriptions
                                if current_time - item["timestamp"] > 5]
            self.last_send_time = current_time  # 更新发送时间

    def on_open(self) -> None:
        global mic, stream
        print("TranslationRecognizerCallback open.")
        mic = pyaudio.PyAudio()
        stream = mic.open(
            format=pyaudio.paInt16, channels=1, rate=16000, input=True
        )

    def on_close(self) -> None:
        global mic, stream
        print("TranslationRecognizerCallback close.")
        stream.stop_stream()
        stream.close()
        mic.terminate()
        stream = None
        mic = None

    def on_event(
        self,
        request_id,
        transcription_result: TranscriptionResult,
        translation_result: TranslationResult,
        usage,
    ) -> None:
        if transcription_result is not None:
            with self.lock:
                self.transcriptions.append({
                    "sentence_id": transcription_result.sentence_id,    
                    "text": transcription_result.text,
                    "timestamp": time.time()
                })
                # 添加调试输出
                print(f"[DEBUG] 新增识别内容：{transcription_result.text}")

if __name__ == "__main__":
    # 初始化语音合成器
    synthesizer = SpeechSynthesizer(
        api_key="sk-svrsbqfsmdepxorteqsydbovhryalhznqbeoragkbqmzmpsc",  # 需要填写硅基流动 API Key
        base_url="https://api.siliconflow.cn/v1"
    )
    
    # 初始化语音助手回调
    callback = Callback(synthesizer)
    
    # 启动语音识别
    translator = TranslationRecognizerRealtime(
        model="gummy-realtime-v1",
        format="pcm",
        sample_rate=16000,
        transcription_enabled=True,
        translation_enabled=False,  # 关闭翻译功能
        callback=callback,
    )
    translator.start()
    print("请您通过麦克风讲话，每5秒的语音内容会作为输入发送到指定API")
    try:
        while True:
            if stream:
                data = stream.read(3200, exception_on_overflow=False)
                translator.send_audio_frame(data)
            else:
                break
    except KeyboardInterrupt:
        print("程序已终止")
    finally:
        translator.stop()