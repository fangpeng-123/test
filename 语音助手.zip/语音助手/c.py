import os 
import json
import playsound
import re  # 导入正则表达式模块
from pathlib import Path
from openai import OpenAI
import pyaudio
import dashscope
from dashscope.audio.asr import *
import threading
import requests
import time
import queue

# 设置 DashScope API Key
dashscope.api_key = "sk-60f37b1aca9a4e78acde3bf2ac2f21cd"

# 定义目标 API 配置
headers = {
    "Authorization": "Bearer app-kPdQWVvNqI6b7zoJ2OVGUQFB",
    "Content-Type": "application/json"
}

# 全局变量
mic = None
stream = None

class SpeechSynthesizer:
    def __init__(self, api_key, base_url):
        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url
        )
        
    def generate_and_play_speech(self, text, model="FunAudioLLM/CosyVoice2-0.5B", 
                               voice="FunAudioLLM/CosyVoice2-0.5B:claire"):
        """
        根据文本生成语音并播放
        """
        try:
            speech_file_path = Path(__file__).parent / f"temp_speech_{int(time.time())}.mp3"
            
            print("[INFO] 正在生成语音...")
            
            # 调用TTS接口生成语音文件
            with self.client.audio.speech.with_streaming_response.create(
                model=model,
                voice=voice,
                input=text,
                response_format="mp3"
            ) as response:
                response.stream_to_file(speech_file_path)
            
            # 播放语音
            print("[INFO] 正在播放语音...")
            playsound.playsound(str(speech_file_path))
            
            # 清理临时文件
            os.remove(speech_file_path)
            print("[INFO] 语音播放完成，临时文件已删除")
            
            return True
            
        except Exception as e:
            print(f"[ERROR] 语音合成或播放失败: {e}")
            if 'speech_file_path' in locals() and speech_file_path.exists():
                os.remove(speech_file_path)
            return False

class Callback(TranslationRecognizerCallback):
    def __init__(self, synthesizer):
        super().__init__()
        self.transcriptions = []  # 存储识别结果
        self.last_voice_time = time.time()  # 上次检测到语音的时间
        self.lock = threading.Lock()  # 线程锁
        self.running = True
        self.synthesizer = synthesizer  # TTS合成器实例
        self.is_processing = False  # 是否正在处理响应
        self.should_exit = False  # 是否应该退出程序
        self.audio_queue = queue.Queue()  # 音频数据队列
        
        # 启动处理线程
        self.process_thread = threading.Thread(target=self._process_loop, daemon=True)
        self.process_thread.start()

    def _process_loop(self):
        """处理循环，检查是否需要发送数据"""
        while self.running:
            try:
                # 检查是否应该发送数据（5秒内无新语音）
                current_time = time.time()
                
                with self.lock:
                    has_data = len(self.transcriptions) > 0
                    silence_duration = current_time - self.last_voice_time
                
                # 如果有数据且静默超过5秒，发送数据
                if has_data and silence_duration >= 5 and not self.is_processing:
                    self._send_collected_data()
                
                time.sleep(0.5)  # 减少CPU占用
            except Exception as e:
                print(f"[ERROR] 处理循环出错: {e}")
                
            # 检查是否应该退出程序
            if self.should_exit:
                self.running = False
                break

    def _send_collected_data(self):
        """发送收集的语音数据到API"""
        with self.lock:
            if not self.transcriptions:
                return 
                
            # 设置处理中状态
            self.is_processing = True
            
            # 获取所有转录文本
            all_text = [item["text"].strip() for item in self.transcriptions if item["text"].strip()]
            
            if not all_text:
                self.is_processing = False
                return 
            
            # 合并所有文本
            query = " ".join(all_text)
            
            if len(query) < 2:
                self.is_processing = False
                return  # 忽略太短的输入
                
            print(f"[INFO] 发送到服务器的内容: {query}")

            # 清空转录数据
            self.transcriptions = []
        
        # 发送请求到服务器（不在锁内执行，避免阻塞）
        try:
            payload = {
                "inputs": {},
                "query": query,
                "response_mode": "streaming",
                "conversation_id": "",
                "user": "decade",
                "files": [
                    {
                        "type": "image",
                        "transfer_method": "remote_url",
                        "url": "https://cloud.dify.ai/logo/logo-site.png"
                    }
                ]
            }

            # 启用流式请求
            response = requests.post(
                url="http://192.168.1.28/v1/chat-messages",
                headers=headers,
                json=payload,
                timeout=30,
                stream=True
            )
            print(f"[DEBUG] API 响应状态码：{response.status_code}")

            if response.status_code != 200:
                print(f"[ERROR] API 请求失败: {response.status_code} - {response.text}")
                self.is_processing = False
                return

            answer_parts = []  # 存储流式返回的 answer 片段
            for line in response.iter_lines():
                if line:
                    text = line.decode('utf-8')
                    if text.startswith("data: "):
                        try:
                            event = json.loads(text[6:])  # 去除 "data: " 前缀
                            if event.get("event") in ["agent_message", "message"]:
                                ans = event.get("answer", "")
                                if ans:
                                    # 去除<think>标签及其内容
                                    ans = self._remove_think_tags(ans)
                                    answer_parts.append(ans)
                                    print(f"[INFO] 流式回答片段: {ans}")
                            elif event.get("event") == "message_end":
                                final_answer = ''.join(answer_parts)
                                # 最终再次检查并去除可能残留的<think>标签
                                final_answer = self._remove_think_tags(final_answer)
                                print(f"[INFO] 完整回答: {final_answer}")
                                
                                # 调用语音合成
                                success = self.synthesizer.generate_and_play_speech(final_answer)
                                
                                # 语音播放完成后退出程序
                                if success:
                                    self.should_exit = True
                        except json.JSONDecodeError as e:
                            print(f"[ERROR] JSON 解析失败: {e}, 原始数据: {text}")
                            continue
        except Exception as e:
            print(f"[ERROR] 请求失败：{e}")
        finally:
            self.is_processing = False

    def _remove_think_tags(self, text):
        """去除文本中的<think>标签及其内容"""
        # 使用正则表达式匹配和移除<think>...</think>标签及其内容
        return re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)

    def on_open(self) -> None:
        global mic, stream
        print("TranslationRecognizerCallback open.")
        mic = pyaudio.PyAudio()
        stream = mic.open(
            format=pyaudio.paInt16, channels=1, rate=16000, input=True
        )

    def on_close(self) -> None:
        global mic, stream
        print("TranslationRecognizerCallback close.")
        if stream:
            stream.stop_stream()
            stream.close()
        if mic:
            mic.terminate()
        stream = None
        mic = None

    def on_event(
        self,
        request_id,
        transcription_result: TranscriptionResult,
        translation_result: TranslationResult,
        usage,
    ) -> None:
        # 如果正在处理响应，忽略新的识别结果
        if self.is_processing:
            return
            
        if transcription_result is not None:
            with self.lock:
                text = transcription_result.text
                print(f"[DEBUG] 识别内容：{text}")
                
                # 更新最后语音时间
                self.last_voice_time = time.time()
                
                # 保存识别结果
                self.transcriptions.append({
                    "sentence_id": transcription_result.sentence_id,    
                    "text": transcription_result.text,
                    "timestamp": time.time()
                })

if __name__ == "__main__":
    # 初始化语音合成器
    synthesizer = SpeechSynthesizer(
        api_key="sk-svrsbqfsmdepxorteqsydbovhryalhznqbeoragkbqmzmpsc",  # 需要填写硅基流动 API Key
        base_url="https://api.siliconflow.cn/v1"
    )
    
    # 初始化语音助手回调
    callback = Callback(synthesizer)
    
    # 启动语音识别
    translator = TranslationRecognizerRealtime(
        model="gummy-realtime-v1",
        format="pcm",
        sample_rate=16000,
        transcription_enabled=True,
        translation_enabled=False,  # 关闭翻译功能
        callback=callback,
    )
    translator.start()
    
    print("请开始说话，系统将在5秒静默后自动处理您的输入")
    try:
        while not callback.should_exit:
            if stream and not callback.is_processing:
                data = stream.read(3200, exception_on_overflow=False)
                # 发送到语音识别器
                translator.send_audio_frame(data)
            else:
                time.sleep(0.1)  # 减少CPU占用
    except KeyboardInterrupt:
        print("程序已终止")
    except Exception as e:
        print(f"[ERROR] 主循环出错: {e}")
    finally:
        translator.stop()
        callback.running = False
        if callback.process_thread.is_alive():
            callback.process_thread.join(timeout=1.0)