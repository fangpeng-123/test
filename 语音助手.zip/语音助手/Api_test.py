# import os
# from openai import OpenAI


# client = OpenAI(
#     # 若没有配置环境变量，请用百炼API Key将下行替换为：api_key="sk-xxx",
#     api_key=os.getenv("sk-b594b133f3274e368d577ea68e09e256"),
#     base_url="https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
# )

# completion = client.chat.completions.create(
#     # 模型列表：https://help.aliyun.com/zh/model-studio/getting-started/models
#     model="qwen-turbo",
#     messages=[
#         {"role": "system", "content": "You are a helpful assistant."},
#         {"role": "user", "content": "你是谁？"},
#     ],
#     # Qwen3模型通过enable_thinking参数控制思考过程（开源版默认True，商业版默认False）
#     # 使用Qwen3开源版模型时，若未启用流式输出，请将下行取消注释，否则会报错
#     # extra_body={"enable_thinking": False},
# )
# print(completion.model_dump_json())

from langchain_community.llms import Tongyi
from langchain_core.tools import Tool

llm = Tongyi(model_name = "qwen-turbo")

# @Tool
# def get_weather():
#     pass

print(llm.invoke("你好qwen，简单介绍一下YOLO模型！"))

# from langchain_community.chat_models import ChatTongyi
# from langchain_core.messages import HumanMessage

# chat = ChatTongyi(model_name="qwen-turbo")
# print(
#     chat.invoke([HumanMessage(content="1+1等于几")]).content
# )