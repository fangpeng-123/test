import gradio as gr
from langchain.chat_models import init_chat_model
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage

model = init_chat_model(
    model="Qwen/Qwen3-8B",
    model_provider="openai",
    base_url = "https://api.siliconflow.cn/v1/",
    api_key = "sk-hcebbggeoucrpvxhtakviksgvfwpqpmixzjycqqfpahgcfqu"
)

parser = StrOutputParser()

chatbot_prompt = ChatPromptTemplate.from_messages(
    [
        SystemMessage(content="你是一名智能助手"),
        MessagesPlaceholder(variable_name="messages"),
    ]
)

qa_chain = chatbot_prompt | model | parser

CSS = """
.main-container {max-width: 1200px; margin: 0; padding: 20px;}
.header-text {text-align: center; margin-bottom: 20px;}
"""

def create_chatbot():
    with gr.Blocks(title="聊天机器人", css=CSS) as demo:
        with gr.Column(elem_classes=["main-container"]):
            gr.Markdown("# 🤖 LangChain 智能对话机器人系统", elem_classes=["header-text"])

            chatbot = gr.Chatbot(
                height=500,
                show_copy_button=True,
                avatar_images=(
                    "picture/user.png",
                    "picture/robot.png"
                ),
            )
            msg = gr.Textbox(placeholder="请输入您的问题...", container=False, scale=7)
            submit = gr.Button("发送", scale=1, variant="primary")
            clear = gr.Button("清空", scale=1)

        state = gr.State([])

        async def respond(user_msg: str, chat_hist: list, messages_list: list):
            if not user_msg.strip():
                yield "", chat_hist, messages_list
                return 
            
            messages_list.append(HumanMessage(content=user_msg))
            chat_hist = chat_hist + [(user_msg, None)]
            yield "", chat_hist, messages_list

            partial = ""
            async for chunk in qa_chain.astream({"messages": messages_list}):
                partial += chunk
                chat_hist[-1] = (user_msg, partial)
                yield "", chat_hist, messages_list

            messages_list.append(AIMessage(content=partial))
            messages_list = messages_list[-50:]

            yield "", chat_hist, messages_list

        def clear_history():
            return [], "", []
        
        msg.submit(respond, [msg, chatbot, state], [msg, chatbot, state])
        submit.click(respond, [msg, chatbot, state], [msg, chatbot, state])
        clear.click(clear_history, outputs=[msg, chatbot, state])
    
    return demo


demo = create_chatbot()
demo.launch(server_name="0.0.0.0", server_port=7860, share=False, debug=True)