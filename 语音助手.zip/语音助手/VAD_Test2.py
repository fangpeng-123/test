import pyaudio
import dashscope
import numpy as np
from dashscope.audio.asr import *
import time
import sys

# 若没有将API Key配置到环境变量中，需将your-api-key替换为自己的API Key
dashscope.api_key = "sk-a6aded0b0ca544eca4b43f78dff7101e"

class EnergyBasedVAD:
    def __init__(self, sample_rate=16000, frame_duration_ms=30):
        """
        基于音频能量的简易VAD
        :param sample_rate: 采样率
        :param frame_duration_ms: 帧持续时间
        """
        self.sample_rate = sample_rate
        self.frame_size = int(sample_rate * frame_duration_ms / 1000)
        self.energy_threshold = 0.01  # 能量阈值，需要根据实际情况调整
        self.min_speech_duration = 0.5  # 最小语音持续时间(秒)
        self.max_silence_duration = 1.0  # 最大静音持续时间(秒)
        self.min_silence_duration = 0.3  # 最小静音持续时间(秒)
        
        # 状态变量
        self.in_speech = False
        self.speech_start_time = None
        self.silence_duration = 0
        self.speech_duration = 0
        self.speech_buffer = []
        self.max_buffer_duration = 10  # 最大语音缓冲时长(秒)
        self.energy_history = []
        self.history_length = 100  # 用于自动调整阈值的历史记录长度
        self.startup_delay = 0.5  # 启动延迟，避免立即检测到噪声
        self.startup_counter = 0
        self.startup_frames = int(self.startup_delay * 1000 / frame_duration_ms)
    
    def calculate_energy(self, frame):
        """计算音频帧的RMS能量"""
        # 将字节数据转换为numpy数组
        audio_data = np.frombuffer(frame, dtype=np.int16)
        # 计算RMS能量
        energy = np.sqrt(np.mean(audio_data.astype(np.float32) ** 2)) / 32768.0
        return energy
    
    def update_threshold(self, energy):
        """动态更新能量阈值"""
        self.energy_history.append(energy)
        if len(self.energy_history) > self.history_length:
            self.energy_history.pop(0)
        
        if len(self.energy_history) > 10:
            # 设置阈值为历史平均值的1.5倍
            avg_energy = np.mean(self.energy_history)
            self.energy_threshold = max(0.005, avg_energy * 1.5)
    
    def process_frame(self, frame):
        """
        处理音频帧并返回状态
        :return: tuple (is_speech, speech_ended)
        """
        # 添加启动延迟，避免启动时的噪声触发
        if self.startup_counter < self.startup_frames:
            self.startup_counter += 1
            return False, False
            
        # 计算音频能量
        energy = self.calculate_energy(frame)
        self.update_threshold(energy)
        
        # 检测是否为语音
        is_speech = energy > self.energy_threshold
        
        # 更新状态
        if is_speech:
            self.silence_duration = 0
            self.speech_duration += len(frame) / (2 * self.sample_rate)  # 估算时间
            self.in_speech = True
            self.speech_buffer.append(frame)
            
            # 如果是刚进入语音状态，记录开始时间
            if self.speech_start_time is None:
                self.speech_start_time = time.time()
        else:
            self.silence_duration += len(frame) / (2 * self.sample_rate)
            if self.in_speech:
                self.speech_buffer.append(frame)
        
        # 检查语音是否结束
        speech_ended = False
        if self.in_speech and self.silence_duration >= self.min_silence_duration:
            # 检查语音是否足够长
            if self.speech_duration >= self.min_speech_duration:
                speech_ended = True
                self.in_speech = False
        
        # 检查缓冲区是否过大
        buffer_duration = sum(len(f) for f in self.speech_buffer) / (2 * self.sample_rate)
        if buffer_duration > self.max_buffer_duration:
            speech_ended = True
            self.in_speech = False
        
        return is_speech, speech_ended
    
    def get_speech_data(self):
        """获取完整语音数据"""
        speech_data = b''.join(self.speech_buffer)
        self.speech_buffer = []
        self.speech_duration = 0
        self.speech_start_time = None
        return speech_data
    
    def reset(self):
        """重置VAD状态"""
        self.in_speech = False
        self.speech_start_time = None
        self.silence_duration = 0
        self.speech_duration = 0
        self.speech_buffer = []
        self.startup_counter = 0

class Callback(TranslationRecognizerCallback):
    def __init__(self):
        super().__init__()
        self.vad = EnergyBasedVAD()
        self.recording = False
        self.silence_counter = 0
        self.max_silence_frames = 20  # 最大静音帧数
        self.mic = None
        self.stream = None
        self.translator = None  # 添加识别器引用
    
    def on_open(self) -> None:
        print("TranslationRecognizerCallback open.")
        try:
            self.mic = pyaudio.PyAudio()
            # 尝试找到支持16000Hz的设备
            device_index = None
            for i in range(self.mic.get_device_count()):
                device_info = self.mic.get_device_info_by_index(i)
                if device_info['maxInputChannels'] > 0:
                    # 检查设备是否支持16000Hz
                    if device_info['defaultSampleRate'] >= 16000:
                        device_index = i
                        print(f"使用设备 {i}: {device_info['name']} (采样率: {device_info['defaultSampleRate']}Hz)")
                        break
            
            # 如果没有找到合适的设备，尝试使用默认设备
            if device_index is None:
                device_index = self.mic.get_default_input_device_info()['index']
                print("未找到明确支持16000Hz的设备，尝试使用默认设备")
            
            # 以16000Hz打开音频流
            self.stream = self.mic.open(
                format=pyaudio.paInt16, 
                channels=1, 
                rate=16000,  # 关键：必须设置为16000
                input=True,
                input_device_index=device_index,
                frames_per_buffer=320  # 20ms帧（16000 * 0.02 = 320）
            )
            print("音频设备初始化成功 (16000Hz)")
        except Exception as e:
            print(f"音频设备初始化失败: {str(e)}")
            self.try_alternative_audio_device()
    
    def try_alternative_audio_device(self):
        """尝试使用其他音频设备"""
        try:
            if self.mic:
                self.mic.terminate()
                
            self.mic = pyaudio.PyAudio()
            device_count = self.mic.get_device_count()
            print(f"检测到 {device_count} 个音频设备")
            
            for i in range(device_count):
                device_info = self.mic.get_device_info_by_index(i)
                if device_info['maxInputChannels'] > 0:
                    try:
                        print(f"尝试设备 {i}: {device_info['name']}")
                        self.stream = self.mic.open(
                            format=pyaudio.paInt16,
                            channels=1,
                            rate=16000,
                            input=True,
                            input_device_index=i,
                            frames_per_buffer=320
                        )
                        print(f"成功使用设备 {i}: {device_info['name']}")
                        return
                    except Exception as e:
                        print(f"设备 {i} 失败: {str(e)}")
            
            print("无法初始化任何音频设备，请检查麦克风连接")
        except Exception as e:
            print(f"尝试替代音频设备失败: {str(e)}")
            
    def on_close(self) -> None:
        print("TranslationRecognizerCallback close.")
        # 安全关闭所有资源
        if hasattr(self, 'stream') and self.stream:
            try:
                self.stream.stop_stream()
                # 注意：这里不再调用 self.stream.close()
                print("音频流已停止，但保持打开状态")
            except Exception as e:
                print(f"关闭音频流时出错: {str(e)}")
        
        # 重置状态，但不关闭流
        self.recording = False
        self.silence_counter = 0
    
    def start_recognizer(self):
        """安全启动识别器"""
        if not hasattr(self, 'translator') or self.translator is None:
            print("错误: 未设置translator引用")
            return False
            
        if self.recording:
            print("识别器已在运行")
            return True
            
        try:
            self.translator.start()
            self.recording = True
            print("识别器已启动")
            return True
        except Exception as e:
            print(f"启动识别器失败: {str(e)}")
            self.recording = False
            return False
            
    def stop_recognizer(self):
        """安全停止识别器"""
        if not hasattr(self, 'translator') or self.translator is None:
            print("错误: 未设置translator引用")
            return False
            
        if not self.recording:
            print("识别器未运行，无需停止")
            return False
            
        try:
            self.translator.stop()
            self.recording = False
            print("识别器已停止")
            return True
        except Exception as e:
            print(f"停止识别器失败: {str(e)}")
            self.recording = False
            return False

    def on_event(
        self,
        request_id,
        transcription_result: TranscriptionResult,
        translation_result: TranslationResult,
        usage,
    ) -> None:
        print("===== 识别结果 =====")
        print(f"request id: {request_id}")
        print(f"usage: {usage}")
        if translation_result is not None:
            print("translation_languages: ", translation_result.get_language_list())
            english_translation = translation_result.get_translation("en")
            print("sentence id: ", english_translation.sentence_id)
            print("translate to english: ", english_translation.text)
        if transcription_result is not None:
            print("sentence id: ", transcription_result.sentence_id)
            print("transcription: ", transcription_result.text)
        print("==================")

# 创建回调实例
callback = Callback()
translator = None

try:
    # 初始化实时翻译器（但不立即启动）
    translator = TranslationRecognizerRealtime(
        model="gummy-realtime-v1",
        format="pcm",
        sample_rate=16000,
        transcription_enabled=True,
        translation_enabled=True,
        translation_target_languages=["en"],
        callback=callback,
    )
    callback.translator = translator  # 重要：添加回调对识别器的引用
    
    # 先确保音频设备初始化成功
    callback.on_open()
    if callback.stream is None:
        print("音频设备初始化失败，无法继续")
        sys.exit(1)
    
    print("\n" + "="*50)
    print("系统准备就绪，请开始说话")
    print("提示：说话时应清晰、音量适中")
    print("如果3秒内无语音，系统将重置")
    print("="*50 + "\n")
    
    # 等待设备准备就绪
    time.sleep(1)
    
    # 主循环
    while True:
        try:
            # 从麦克风读取音频
            data = callback.stream.read(320, exception_on_overflow=False)
            
            # 处理VAD
            is_speech, speech_ended = callback.vad.process_frame(data)
            
            # 调试输出
            print(f"主循环: is_speech={is_speech}, speech_ended={speech_ended}, recording={callback.recording}")
            
            # 如果检测到语音，发送给识别器
            if is_speech:
                if not callback.recording:
                    print("✅ 检测到语音开始")
                    if not callback.start_recognizer():
                        continue
                
                # 发送音频帧
                try:
                    translator.send_audio_frame(data)
                    callback.silence_counter = 0
                except Exception as e:
                    print(f"❌ 发送音频帧失败: {str(e)}")
                    callback.stop_recognizer()
            else:
                if callback.recording:
                    callback.silence_counter += 1
                    
                    # 如果静音时间过长，停止识别
                    if callback.silence_counter > callback.max_silence_frames:
                        print("⏹️ 检测到语音结束")
                        callback.stop_recognizer()
                        callback.silence_counter = 0
                        callback.vad.reset()
                        print("请继续说话或等待3秒后开始新对话...")
            
            # 处理语音结束
            if speech_ended:
                print("⏹️ 完整语音片段结束，正在处理...")
                callback.stop_recognizer()
                callback.silence_counter = 0
                callback.vad.reset()
                print("请继续说话或等待3秒后开始新对话...")
                
        except Exception as e:
            print(f"❌ 主循环错误: {str(e)}")
            time.sleep(0.1)

except Exception as e:
    print(f"❌ 发生错误: {str(e)}")
    import traceback
    traceback.print_exc()
finally:
    # 安全关闭所有资源
    if hasattr(callback, 'stop_recognizer'):
        callback.stop_recognizer()
    if hasattr(callback, 'on_close'):
        callback.on_close()
    print("✅ 程序已退出")