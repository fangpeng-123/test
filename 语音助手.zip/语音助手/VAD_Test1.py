import pyaudio
import dashscope
import webrtcvad
import numpy as np
from scipy import signal
from dashscope.audio.asr import *
import time
import sys

# 若没有将API Key配置到环境变量中，需将your-api-key替换为自己的API Key
dashscope.api_key = "sk-a6aded0b0ca544eca4b43f78dff7101e"

class AudioResampler:
    """音频重采样器，将任意采样率转换为16000Hz"""
    def __init__(self, original_rate, target_rate=16000):
        self.original_rate = original_rate
        self.target_rate = target_rate
        self.resample_ratio = target_rate / original_rate
    
    def resample(self, audio_data):
        """重采样音频数据"""
        # 将16-bit PCM转换为浮点数
        audio_float = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32) / 32768.0
        
        # 重采样
        num_samples = int(len(audio_float) * self.resample_ratio)
        resampled = signal.resample(audio_float, num_samples)
        
        # 转换回16-bit PCM
        return (resampled * 32767).astype(np.int16).tobytes()

class VADHandler:
    def __init__(self, aggressiveness=1, frame_duration_ms=20, sample_rate=16000):
        """
        初始化VAD处理器
        :param aggressiveness: VAD敏感度(0-3)，值越小越敏感
        :param frame_duration_ms: 帧持续时间(10, 20, 30 ms)
        :param sample_rate: 采样率(8000, 16000, 32000, 48000)
        """
        # 验证采样率是否支持
        if sample_rate not in [8000, 16000, 32000, 48000]:
            raise ValueError(f"不支持的采样率: {sample_rate}. 必须是8000, 16000, 32000或48000")
            
        self.vad = webrtcvad.Vad(aggressiveness)
        self.frame_duration_ms = frame_duration_ms
        self.sample_rate = sample_rate
        self.frame_size = int(sample_rate * frame_duration_ms / 1000)
        
        # 确保帧大小是偶数（VAD要求）
        if self.frame_size % 2 != 0:
            self.frame_size += 1
            
        # VAD状态
        self.in_speech = False
        self.speech_start_time = None
        self.silence_duration = 0
        self.speech_duration = 0
        
        # 配置参数
        self.min_speech_duration = 0.3  # 最小语音持续时间(秒)
        self.max_silence_duration = 2.0  # 最大静音持续时间(秒)
        self.min_silence_duration = 0.5  # 最小静音持续时间(秒)
        self.startup_delay = 0.2  # 启动延迟，避免立即检测到噪声
        self.startup_counter = 0
        self.startup_frames = int(self.startup_delay * 1000 / frame_duration_ms)
        
        # 用于存储完整语音片段
        self.speech_buffer = []
        self.max_buffer_duration = 15  # 增加最大语音缓冲时长(秒)
    
    def is_speech(self, frame):
        """检测当前帧是否包含语音"""
        try:
            # 确保帧大小正确
            if len(frame) < self.frame_size:
                frame = frame + b'\x00' * (self.frame_size - len(frame))
            elif len(frame) > self.frame_size:
                frame = frame[:self.frame_size]
                
            return self.vad.is_speech(frame, self.sample_rate)
        except Exception as e:
            print(f"VAD处理错误: {str(e)}")
            return False
    
    def process_frame(self, frame):
        """
        处理音频帧并返回状态
        :return: tuple (is_speech, speech_ended)
        """
        # 调试输出
        print(f"VAD处理: 长度={len(frame)}, 帧大小={self.frame_size}, 启动计数器={self.startup_counter}/{self.startup_frames}")
        
        # 添加启动延迟，避免启动时的噪声触发
        if self.startup_counter < self.startup_frames:
            self.startup_counter += 1
            return False, False
            
        # 检测语音
        current_speech = self.is_speech(frame)
        print(f"VAD检测结果: is_speech={current_speech}")
        
        # 更新状态
        if current_speech:
            self.silence_duration = 0
            self.speech_duration += self.frame_duration_ms / 1000
            self.in_speech = True
            self.speech_buffer.append(frame)
            
            # 如果是刚进入语音状态，记录开始时间
            if self.speech_start_time is None:
                self.speech_start_time = time.time()
        else:
            self.silence_duration += self.frame_duration_ms / 1000
            if self.in_speech:
                self.speech_buffer.append(frame)
        
        # 检查语音是否结束
        speech_ended = False
        if self.in_speech and self.silence_duration >= self.min_silence_duration:
            # 检查语音是否足够长
            if self.speech_duration >= self.min_speech_duration:
                speech_ended = True
                self.in_speech = False
        
        # 检查缓冲区是否过大
        buffer_duration = len(self.speech_buffer) * (self.frame_duration_ms / 1000)
        if buffer_duration > self.max_buffer_duration:
            speech_ended = True
            self.in_speech = False
        
        return current_speech, speech_ended
    
    def get_speech_data(self):
        """获取完整语音数据"""
        speech_data = b''.join(self.speech_buffer)
        self.speech_buffer = []
        self.speech_duration = 0
        self.speech_start_time = None
        return speech_data
    
    def reset(self):
        """重置VAD状态"""
        self.in_speech = False
        self.speech_start_time = None
        self.silence_duration = 0
        self.speech_duration = 0
        self.speech_buffer = []
        self.startup_counter = 0

class Callback(TranslationRecognizerCallback):
    def __init__(self):
        super().__init__()
        self.vad = VADHandler(aggressiveness=1, sample_rate=16000)  # 确保采样率设置为16000
        self.recording = False
        self.silence_counter = 0
        self.max_silence_frames = 30  # 增加到30帧(约0.6秒)
        self.mic = None
        self.stream = None
        self.translator = None
        self.resampler = None  # 重采样器
        self.original_sample_rate = 44100  # 默认采样率
        self.vad_triggered = False  # 跟踪VAD是否触发
        self.last_stream_check = time.time()
        self.stream_health_check_interval = 5  # 每5秒检查一次流状态
    
    def check_stream_health(self):
        """定期检查音频流是否健康"""
        current_time = time.time()
        if current_time - self.last_stream_check > self.stream_health_check_interval:
            self.last_stream_check = current_time
            if hasattr(self, 'stream') and self.stream:
                try:
                    # 尝试读取一小段数据测试流
                    self.stream.read(100, exception_on_overflow=False)
                    return True
                except Exception as e:
                    print(f"⚠️ 音频流健康检查失败: {str(e)}")
                    return False
            return False
        return True
    
def on_open(self) -> None:
    print("TranslationRecognizerCallback open.")
    try:
        # 如果已有mic实例，先清理
        if hasattr(self, 'mic') and self.mic:
            try:
                if hasattr(self, 'stream') and self.stream:
                    self.stream.stop_stream()
                    self.stream.close()
                self.mic.terminate()
            except Exception as e:
                print(f"清理旧音频资源时出错: {str(e)}")
        
        self.mic = pyaudio.PyAudio()
        device_info = self.mic.get_default_input_device_info()
        self.original_sample_rate = int(device_info['defaultSampleRate'])
        
        print(f"使用默认音频设备: {device_info['name']}")
        print(f"设备原始采样率: {self.original_sample_rate}Hz")
        print(f"最大输入通道: {device_info['maxInputChannels']}")
        
        # 优先尝试16000Hz
        if self.original_sample_rate == 16000:
            self.stream = self.mic.open(
                format=pyaudio.paInt16, 
                channels=1, 
                rate=16000, 
                input=True,
                frames_per_buffer=320  # 20ms帧
            )
            print("✅ 音频设备初始化成功 (16000Hz)")
            self.resampler = None
        else:
            # 尝试使用原始采样率
            self.stream = self.mic.open(
                format=pyaudio.paInt16, 
                channels=1, 
                rate=self.original_sample_rate, 
                input=True,
                frames_per_buffer=1024
            )
            print(f"✅ 音频设备初始化成功 ({self.original_sample_rate}Hz)，将使用重采样器")
            self.resampler = AudioResampler(self.original_sample_rate)
            
    except Exception as e:
        print(f"❌ 音频设备初始化失败: {str(e)}")
        self.try_alternative_audio_device()
            
    def try_alternative_audio_device(self):
        """尝试使用其他音频设备"""
        try:
            if self.mic:
                self.mic.terminate()
                
            self.mic = pyaudio.PyAudio()
            device_count = self.mic.get_device_count()
            print(f"检测到 {device_count} 个音频设备")
            
            for i in range(device_count):
                device_info = self.mic.get_device_info_by_index(i)
                if device_info['maxInputChannels'] > 0:
                    try:
                        print(f"尝试设备 {i}: {device_info['name']}")
                        # 优先尝试16000Hz
                        try:
                            self.stream = self.mic.open(
                                format=pyaudio.paInt16,
                                channels=1,
                                rate=16000,
                                input=True,
                                input_device_index=i,
                                frames_per_buffer=320
                            )
                            print(f"成功使用设备 {i} (16000Hz): {device_info['name']}")
                            self.resampler = None
                            self.original_sample_rate = 16000
                            return
                        except:
                            # 如果16000Hz失败，尝试默认采样率
                            self.stream = self.mic.open(
                                format=pyaudio.paInt16,
                                channels=1,
                                rate=device_info['defaultSampleRate'],
                                input=True,
                                input_device_index=i,
                                frames_per_buffer=1024
                            )
                            print(f"成功使用设备 {i} ({device_info['defaultSampleRate']}Hz): {device_info['name']}")
                            self.resampler = AudioResampler(device_info['defaultSampleRate'])
                            self.original_sample_rate = int(device_info['defaultSampleRate'])
                            return
                    except Exception as e:
                        print(f"设备 {i} 失败: {str(e)}")
            
            print("无法初始化任何音频设备，请检查麦克风连接")
        except Exception as e:
            print(f"尝试替代音频设备失败: {str(e)}")
            
    def on_close(self) -> None:
        print("TranslationRecognizerCallback close.")
        # 安全关闭所有资源
        if hasattr(self, 'stream') and self.stream:
            try:
                self.stream.stop_stream()
                print("音频流已停止，但保持打开状态")
            except Exception as e:
                print(f"关闭音频流时出错: {str(e)}")
        self.recording = False
        self.silence_counter = 0
        self.vad_triggered = False
            
        if hasattr(self, 'mic') and self.mic:
            try:
                self.mic.terminate()
            except Exception as e:
                print(f"终止PyAudio时出错: {str(e)}")
            self.mic = None
            
        # 重置状态
        self.recording = False
        self.silence_counter = 0
        self.vad_triggered = False
        
    def start_recognizer(self):
        """安全启动识别器"""
        if not hasattr(self, 'translator') or self.translator is None:
            print("错误: 未设置translator引用")
            return False
            
        if self.recording:
            print("识别器已在运行")
            return True
            
        try:
            self.translator.start()
            self.recording = True
            print("识别器已启动")
            return True
        except Exception as e:
            print(f"启动识别器失败: {str(e)}")
            self.recording = False
            return False
            
    def stop_recognizer(self):
        """安全停止识别器"""
        if not hasattr(self, 'translator') or self.translator is None:
            print("错误: 未设置translator引用")
            return False
            
        if not self.recording:
            print("识别器未运行，无需停止")
            return False
            
        try:
            self.translator.stop()
            self.recording = False
            print("识别器已停止")
            return True
        except Exception as e:
            print(f"停止识别器失败: {str(e)}")
            self.recording = False
            return False

    def on_event(
        self,
        request_id,
        transcription_result: TranscriptionResult,
        translation_result: TranslationResult,
        usage,
    ) -> None:
        print("===== 识别结果 =====")
        print(f"request id: {request_id}")
        print(f"usage: {usage}")
        
        if translation_result is not None:
            print("translation_languages: ", translation_result.get_language_list())
            english_translation = translation_result.get_translation("en")
            print("sentence id: ", english_translation.sentence_id)
            print("翻译结果: ", english_translation.text)
            
        if transcription_result is not None:
            print("sentence id: ", transcription_result.sentence_id)
            print("语音识别结果: ", transcription_result.text)
            self.vad_triggered = True  # 标记VAD已触发
            
        print("==================")

# 创建回调实例
callback = Callback()
translator = None

try:
    # 初始化实时翻译器
    translator = TranslationRecognizerRealtime(
        model="gummy-realtime-v1",
        format="pcm",
        sample_rate=16000,
        transcription_enabled=True,
        translation_enabled=True,
        translation_target_languages=["en"],
        callback=callback,
    )
    callback.translator = translator
    
    # 先确保音频设备初始化成功
    callback.on_open()
    if callback.stream is None:
        print("音频设备初始化失败，无法继续")
        sys.exit(1)
    
    print("\n" + "="*50)
    print("系统准备就绪，请开始说话")
    print("提示：说话时应清晰、音量适中")
    print("如果3秒内无语音，系统将重置")
    print("="*50 + "\n")
    
    
    # 主循环
    while True:
        try:
            if not callback.check_stream_health():
                print("🔄 音频流异常，尝试重新初始化...")
                callback.on_open()
                if not callback.stream:
                    time.sleep(1)
                    continue
            # 安全检查音频流是否存在
            if not hasattr(callback, 'stream') or callback.stream is None:
                print("⚠️ 音频流未初始化，尝试重新初始化...")
                callback.on_open()
                if callback.stream is None:
                    print("❌ 无法重新初始化音频流，等待 2 秒...")
                    time.sleep(2)
                    continue
                print("✅ 音频流已重新初始化")
            
            # 从麦克风读取音频
            data = callback.stream.read(1024, exception_on_overflow=False)
            
            # ... [VAD处理和识别器调用代码保持不变] ...
            
        except Exception as e:
            error_msg = str(e)
            print(f"❌ 主循环错误: {error_msg}")
            
            # 专门处理 'NoneType' object has no attribute 'read' 错误
            if "'NoneType' object has no attribute 'read'" in error_msg:
                print("🔄 检测到音频流问题，尝试重新初始化...")
                try:
                    if hasattr(callback, 'stream') and callback.stream:
                        callback.stream.stop_stream()
                    callback.on_open()
                except Exception as init_err:
                    print(f"❌ 重新初始化音频流失败: {str(init_err)}")
            
            time.sleep(0.1)

except Exception as e:
    print(f"❌ 发生严重错误: {str(e)}")
    import traceback
    traceback.print_exc()
finally:
    # 确保在程序退出时才关闭资源
    if hasattr(callback, 'stream') and callback.stream:
        try:
            callback.stream.stop_stream()
            callback.stream.close()
        except Exception as e:
            print(f"❌ 关闭音频流时出错: {str(e)}")
    if hasattr(callback, 'mic') and callback.mic:
        try:
            callback.mic.terminate()
        except Exception as e:
            print(f"❌ 终止PyAudio时出错: {str(e)}")
    print("✅ 程序已安全退出")