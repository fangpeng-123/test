import os, json, requests, pyaudio, wave, io, tempfile, pygame
from dotenv import load_dotenv
from langchain.llms import Tongyi
from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser

load_dotenv()

# 全局配置
SILICON_KEY = os.getenv("sk-hcebbggeoucrpvxhtakviksgvfwpqpmixzjycqqfpahgcfqu")
DIFY_URL = "http://localhost:5001/v1"
DIFY_KEY = os.getenv("app-K7NiLYakai4oDe4UOe8KuGTc")

# Langchain 调用 Dify LLM
llm = Tongyi(
    llm_api_url = DIFY_URL,
    llm_api_key = DIFY_KEY,
    model = "dify",
    temperature = 0.3
)

chain = (
    ChatPromptTemplate.from_template("{question}") | 
    llm |
    StrOutputParser()
)

# 语音识别模块
def asr(audio_bytes:bytes) -> str:
    url = "https://api.siliconflow.cn/v1/audio/transcriptions"
    files = {"file":("speech.wav", audio_bytes, "audio/wav")}
    headers = {"Authorization": f"Bearer {SILICON_KEY}"}
    data = {"model": "FunAudioLLM/SenseVoiceSmall"}
    r = requests.post(url, files=files, data=data, headers=headers)
    return r.json()["text"]

# 语音合成
def tts(text: str) -> bytes:
    url = "https://api.siliconflow.cn/v1/audio/speech"
    headers = {"Authorization": f"Bearer{SILICON_KEY}", "Content-Type": "application/json"}
    payload = {"model": "FunAudioLLM/CosyVoice2-0.5B", "input": text, "voice": "female"}
    r = requests.post(url, json=payload, headers=headers)
    return r.content

# 录音与播放工具
def record(duration=5, fs=16000):
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16, channels=1, rate=fs, input=True)
    frames = [stream.read(1024) for _ in range(0, int(fs / 1024 * duration))]
    stream.stop_stream(); stream.close(); p.terminate()
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1);
        wf.setsampwidth(p.get_sample_size(pyaudio.paInt16)); wf.setframerate(fs)
        wf.writeframes(b"".join(frames))
    return buf.getvalue()

def play(audio_bytes:bytes):
    pygame.mixer.init()
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        f.write(audio_bytes)
        tmp = f.name
    pygame.mixer.music.load(tmp); pygame.mixer.music.play()
    while pygame.mixer.music.get_busy(): continue

# 主循环
if __name__ == "__main__":
    print("请说明问题..."); audio = record(5)
    user_text = asr(audio)
    print("识别内容：", user_text)

    answer = chain.invoke({"question": user_text})
    print("回答：", answer)

    print("语音回答..."); play(tts(answer))