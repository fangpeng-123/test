import csv
import random
from datetime import date, timedelta
from pathlib import Path

# ------------------------ 参数区 ------------------------
N = 500                 # 需要生成的记录数
csv_path = Path("data500.csv")   # 输出文件名
# -------------------------------------------------------

# 一些用于随机生成的“素材库”
first_names = ["张", "王", "李", "赵", "刘", "陈", "杨", "黄", "周", "吴"]
last_names  = ["伟", "芳", "娜", "秀英", "敏", "静", "强", "磊", "洋", "勇"]
departments = ["技术部", "人事部", "财务部", "市场部", "运营部"]

def random_name():
    return random.choice(first_names) + "".join(random.choices(last_names, k=random.randint(1, 2)))

def random_date(start=date(2010, 1, 1), end=date(2023, 12, 31)):
    delta = end - start
    return start + timedelta(days=random.randint(0, delta.days))

def random_record(idx):
    return {
        "id": idx,
        "name": random_name(),
        "department": random.choice(departments),
        "age": random.randint(22, 55),
        "salary": random.randint(5_000, 50_000),
        "hire_date": random_date().isoformat()
    }

# ------------------------ 主程序 ------------------------
with csv_path.open("w", newline='', encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["id", "name", "department", "age", "salary", "hire_date"])
    writer.writeheader()
    for i in range(1, N + 1):
        writer.writerow(random_record(i))

print(f"已生成 {N} 条数据，文件保存为：{csv_path.absolute()}")