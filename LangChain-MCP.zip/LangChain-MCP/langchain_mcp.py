import asyncio
import json
import logging

from dotenv import load_dotenv
from langchain import hub
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain.chat_models import init_chat_model
from langchain_mcp_adapters.client import MultiServerMCPClient

# ------------------------
# 环境配置
# ------------------------

class Configuration:
    def __init__(self) -> None:
        load_dotenv()
        self.api_key=""
        self.model=""

    @staticmethod
    def load_servers(file_path = "servers+config.json"):
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f).get("mcpServers", {})
        
async def run_chat_loop():
    """启动 MCP-Agent 聊天循环"""
    cfg = Configuration()
    servers_cfg = Configuration.load_servers()

    # 1. 连接多台 MCP 服务器
    mcp_client = MultiServerMCPClient(servers_cfg)
    tools = await mcp_client.get_tools()
    logging.info(f"已加载 {len(tools)} 个 MCP 工具：{[t.name for t in tools]}")

    # 2. 初始化大模型
    llm = init_chat_model(
        model="Qwen/Qwen3-8B",
        model_provider="openai",
        base_url="",
        api_key=""
    )

    # 3. 构建 LangChain Agent (用通用 prompt)
    prompt = hub.pull("hwchase17/openai-tools-agent")
    agent = create_openai_tools_agent(llm, tools, prompt)
    agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

    # 4. CLI 聊天
    print("\n MCP Agent 已启动，输入 'quit' 退出")
    while True:
        user_input = input("\n你：").strip()
        if user_input.lower() == "quit":
            break
        try:
            result = await agent_executor.ainvoke({"input": user_input})
            print(f"\nAI: {result['output']}")
        except Exception as exc:
            print(f"\n出错: {exc}")

# ------------------------
# 入口
# ------------------------
if __name__ ==  "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    asyncio.run(run_chat_loop())
