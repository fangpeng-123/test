"""
配置管理模块
"""

import os
from typing import Optional
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()


class Config:
    """配置管理类"""
    
    # 阿里云百炼配置
    DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY")
    
    # 默认模型配置
    DEFAULT_MODEL = "qwen-turbo"
    
    # 搜索配置
    MAX_SEARCH_RESULTS = 5
    SEARCH_TIMEOUT = 10
    
    # 分析配置
    MAX_KEYWORDS = 10
    MAX_ANNOTATIONS = 10
    
    @classmethod
    def get_dashscope_api_key(cls) -> Optional[str]:
        """获取阿里云百炼API密钥"""
        return cls.DASHSCOPE_API_KEY
    
    @classmethod
    def set_dashscope_api_key(cls, api_key: str):
        """设置阿里云百炼API密钥"""
        cls.DASHSCOPE_API_KEY = api_key
        os.environ["DASHSCOPE_API_KEY"] = api_key
    
    @classmethod
    def validate_config(cls) -> bool:
        """验证配置是否完整"""
        if not cls.DASHSCOPE_API_KEY:
            print("警告: 未设置阿里云百炼API密钥")
            print("请设置环境变量 DASHSCOPE_API_KEY 或使用 Config.set_dashscope_api_key() 方法")
            return False
        return True