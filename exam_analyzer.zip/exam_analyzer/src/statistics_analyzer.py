"""
题型分类标注统计模块
"""

import re
from typing import Dict, List, Any, Tuple
from collections import Counter, defaultdict
from dataclasses import dataclass
import numpy as np
import pandas as pd
from .data_reader import Question, ExamData
from .question_classifier import QuestionAnalysis


@dataclass
class QuestionAnnotation:
    """题目标注信息"""
    question_id: str
    question_type: str
    sub_type: str
    passage_location: str  # 在文章中的位置
    key_sentences: List[str]  # 关键句子
    option_labels: Dict[str, str]  # 选项标签
    explanation_location: str  # 解析位置
    difficulty_score: float  # 难度分数


@dataclass
class StatisticsResult:
    """统计分析结果"""
    question_type_distribution: Dict[str, int]
    subtype_distribution: Dict[str, Dict[str, int]]
    difficulty_distribution: Dict[str, int]
    option_distribution: Dict[str, Dict[str, int]]
    keyword_frequency: Dict[str, int]
    passage_analysis: Dict[str, Any]
    annotations: List[QuestionAnnotation]


class StatisticsAnalyzer:
    """统计分析器"""
    
    def __init__(self):
        self.difficulty_scores = {
            'easy': 1.0,
            'medium': 2.0,
            'hard': 3.0
        }
        
        self.question_type_mapping = {
            'reading': '阅读理解',
            'cloze': '完形填空',
            'translation': '翻译',
            'writing': '写作'
        }
    
    def analyze_exam_statistics(self, exam_data: ExamData, 
                               question_analyses: List[QuestionAnalysis]) -> StatisticsResult:
        """分析试卷统计信息"""
        # 题型分布统计
        type_distribution = self._analyze_question_type_distribution(exam_data.questions)
        
        # 子类型分布统计
        subtype_distribution = self._analyze_subtype_distribution(question_analyses)
        
        # 难度分布统计
        difficulty_distribution = self._analyze_difficulty_distribution(question_analyses)
        
        # 选项分布统计
        option_distribution = self._analyze_option_distribution(exam_data.questions)
        
        # 关键词频率统计
        keyword_frequency = self._analyze_keyword_frequency(question_analyses)
        
        # 文章分析
        passage_analysis = self._analyze_passages(exam_data.questions)
        
        # 生成标注信息
        annotations = self._generate_annotations(exam_data.questions, question_analyses)
        
        return StatisticsResult(
            question_type_distribution=type_distribution,
            subtype_distribution=subtype_distribution,
            difficulty_distribution=difficulty_distribution,
            option_distribution=option_distribution,
            keyword_frequency=keyword_frequency,
            passage_analysis=passage_analysis,
            annotations=annotations
        )
    
    def _analyze_question_type_distribution(self, questions: List[Question]) -> Dict[str, int]:
        """分析题型分布"""
        type_counter = Counter()
        
        for question in questions:
            type_counter[question.type] += 1
        
        # 转换为中文标签
        chinese_distribution = {}
        for q_type, count in type_counter.items():
            chinese_name = self.question_type_mapping.get(q_type, q_type)
            chinese_distribution[chinese_name] = count
        
        return dict(chinese_distribution)
    
    def _analyze_subtype_distribution(self, analyses: List[QuestionAnalysis]) -> Dict[str, Dict[str, int]]:
        """分析子类型分布"""
        subtype_stats = defaultdict(lambda: defaultdict(int))
        
        for analysis in analyses:
            q_type = analysis.question_type
            sub_type = analysis.sub_type
            subtype_stats[q_type][sub_type] += 1
        
        return dict(subtype_stats)
    
    def _analyze_difficulty_distribution(self, analyses: List[QuestionAnalysis]) -> Dict[str, int]:
        """分析难度分布"""
        difficulty_counter = Counter()
        
        for analysis in analyses:
            difficulty_counter[analysis.difficulty] += 1
        
        return dict(difficulty_counter)
    
    def _analyze_option_distribution(self, questions: List[Question]) -> Dict[str, Dict[str, int]]:
        """分析选项分布"""
        option_stats = defaultdict(lambda: defaultdict(int))
        
        for question in questions:
            if question.options and len(question.options) == 4:
                q_type = question.type
                
                # 统计每个选项位置的内容特征
                for i, option in enumerate(question.options):
                    option_letter = chr(65 + i)  # A, B, C, D
                    
                    # 分析选项长度
                    length_category = self._categorize_option_length(len(option))
                    option_stats[q_type][f'{option_letter}_length_{length_category}'] += 1
                    
                    # 分析选项内容特征
                    if self._contains_negation(option):
                        option_stats[q_type][f'{option_letter}_negation'] += 1
                    
                    if self._contains_absolute_words(option):
                        option_stats[q_type][f'{option_letter}_absolute'] += 1
                    
                    if self._contains_comparison(option):
                        option_stats[q_type][f'{option_letter}_comparison'] += 1
        
        return dict(option_stats)
    
    def _analyze_keyword_frequency(self, analyses: List[QuestionAnalysis]) -> Dict[str, int]:
        """分析关键词频率"""
        all_keywords = []
        
        for analysis in analyses:
            all_keywords.extend(analysis.keywords)
        
        keyword_counter = Counter(all_keywords)
        
        # 返回前20个高频关键词
        return dict(keyword_counter.most_common(20))
    
    def _analyze_passages(self, questions: List[Question]) -> Dict[str, Any]:
        """分析文章特征"""
        passages = [q.passage for q in questions if q.passage and q.passage.strip()]
        
        if not passages:
            return {}
        
        passage_analysis = {
            'total_passages': len(passages),
            'average_length': 0,
            'length_distribution': {'short': 0, 'medium': 0, 'long': 0},
            'topic_keywords': [],
            'sentence_structure': {
                'average_sentences': 0,
                'complex_sentences': 0,
                'simple_sentences': 0
            }
        }
        
        total_length = 0
        total_sentences = 0
        all_words = []
        
        for passage in passages:
            # 长度统计
            passage_length = len(passage)
            total_length += passage_length
            
            if passage_length < 500:
                passage_analysis['length_distribution']['short'] += 1
            elif passage_length < 1000:
                passage_analysis['length_distribution']['medium'] += 1
            else:
                passage_analysis['length_distribution']['long'] += 1
            
            # 句子结构分析
            sentences = re.split(r'[.!?]+', passage)
            sentences = [s.strip() for s in sentences if s.strip()]
            total_sentences += len(sentences)
            
            complex_count = sum(1 for s in sentences if self._is_complex_sentence(s))
            passage_analysis['sentence_structure']['complex_sentences'] += complex_count
            passage_analysis['sentence_structure']['simple_sentences'] += len(sentences) - complex_count
            
            # 提取词汇
            words = re.findall(r'\b[a-zA-Z]+\b', passage.lower())
            all_words.extend(words)
        
        passage_analysis['average_length'] = total_length / len(passages) if passages else 0
        passage_analysis['sentence_structure']['average_sentences'] = total_sentences / len(passages) if passages else 0
        
        # 高频词汇
        word_counter = Counter(all_words)
        passage_analysis['topic_keywords'] = dict(word_counter.most_common(15))
        
        return passage_analysis
    
    def _generate_annotations(self, questions: List[Question], 
                            analyses: List[QuestionAnalysis]) -> List[QuestionAnnotation]:
        """生成题目标注信息"""
        annotations = []
        
        for i, (question, analysis) in enumerate(zip(questions, analyses)):
            # 在文章中定位题目相关信息
            passage_location = self._locate_in_passage(question, analysis)
            
            # 提取关键句子
            key_sentences = self._extract_key_sentences_from_passage(question, analysis)
            
            # 标注选项
            option_labels = self._label_options(question.options, analysis)
            
            # 定位解析位置
            explanation_location = self._locate_explanation(question)
            
            # 计算难度分数
            difficulty_score = self.difficulty_scores.get(analysis.difficulty, 2.0)
            
            annotation = QuestionAnnotation(
                question_id=question.id,
                question_type=question.type,
                sub_type=analysis.sub_type,
                passage_location=passage_location,
                key_sentences=key_sentences,
                option_labels=option_labels,
                explanation_location=explanation_location,
                difficulty_score=difficulty_score
            )
            
            annotations.append(annotation)
        
        return annotations
    
    def _categorize_option_length(self, length: int) -> str:
        """分类选项长度"""
        if length < 30:
            return 'short'
        elif length < 60:
            return 'medium'
        else:
            return 'long'
    
    def _contains_negation(self, text: str) -> bool:
        """检查是否包含否定词"""
        negation_words = ['not', 'never', 'no', 'none', 'nothing', 'neither', 'nor']
        text_lower = text.lower()
        return any(word in text_lower for word in negation_words)
    
    def _contains_absolute_words(self, text: str) -> bool:
        """检查是否包含绝对词"""
        absolute_words = ['always', 'never', 'all', 'only', 'must', 'every', 'completely']
        text_lower = text.lower()
        return any(word in text_lower for word in absolute_words)
    
    def _contains_comparison(self, text: str) -> bool:
        """检查是否包含比较结构"""
        comparison_patterns = [
            r'\b(more|less|better|worse|greater|smaller)\b',
            r'\b-er\b',
            r'\b(most|least|best|worst|greatest|smallest)\b'
        ]
        
        for pattern in comparison_patterns:
            if re.search(pattern, text.lower()):
                return True
        
        return False
    
    def _is_complex_sentence(self, sentence: str) -> bool:
        """判断是否为复杂句"""
        # 检查从句标志词
        clause_markers = [
            'which', 'that', 'who', 'whom', 'whose',
            'because', 'since', 'although', 'though', 'while',
            'when', 'where', 'if', 'unless', 'as', 'since'
        ]
        
        sentence_lower = sentence.lower()
        clause_count = sum(1 for marker in clause_markers if marker in sentence_lower)
        
        # 检查逗号数量（复杂句通常有更多逗号）
        comma_count = sentence.count(',')
        
        return clause_count >= 1 or comma_count >= 2
    
    def _locate_in_passage(self, question: Question, analysis: QuestionAnalysis) -> str:
        """在文章中定位题目相关信息"""
        if not question.passage:
            return "无文章"
        
        # 基于关键词在文章中定位
        keywords = analysis.keywords[:3]  # 使用前3个关键词
        locations = []
        
        for keyword in keywords:
            # 查找关键词在文章中的位置
            matches = list(re.finditer(re.escape(keyword), question.passage, re.IGNORECASE))
            
            for match in matches:
                # 获取匹配位置的上下文
                start = max(0, match.start() - 50)
                end = min(len(question.passage), match.end() + 50)
                context = question.passage[start:end].strip()
                locations.append(f"关键词'{keyword}'附近: ...{context}...")
        
        return "; ".join(locations) if locations else "未找到明确位置"
    
    def _extract_key_sentences_from_passage(self, question: Question, 
                                          analysis: QuestionAnalysis) -> List[str]:
        """从文章中提取关键句子"""
        if not question.passage:
            return []
        
        sentences = re.split(r'[.!?]+', question.passage)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        key_sentences = []
        keywords = set(analysis.keywords[:5])  # 使用前5个关键词
        
        for sentence in sentences:
            sentence_words = set(re.findall(r'\w+', sentence.lower()))
            
            # 计算关键词重叠度
            overlap = len(keywords & sentence_words)
            
            # 如果重叠度较高，认为是关键句子
            if overlap >= 2 or (overlap >= 1 and len(sentence) > 50):
                key_sentences.append(sentence)
        
        return key_sentences[:3]  # 返回前3个关键句子
    
    def _label_options(self, options: List[str], analysis: QuestionAnalysis) -> Dict[str, str]:
        """标注选项特征"""
        labels = {}
        
        if not options:
            return labels
        
        for i, option in enumerate(options):
            option_letter = chr(65 + i)
            label_features = []
            
            # 检查各种特征
            if self._contains_negation(option):
                label_features.append("否定")
            
            if self._contains_absolute_words(option):
                label_features.append("绝对")
            
            if self._contains_comparison(option):
                label_features.append("比较")
            
            # 检查长度特征
            length_category = self._categorize_option_length(len(option))
            label_features.append(f"长度{length_category}")
            
            labels[option_letter] = ", ".join(label_features) if label_features else "常规"
        
        return labels
    
    def _locate_explanation(self, question: Question) -> str:
        """定位解析位置"""
        if question.explanation:
            return "题目包含解析"
        else:
            return "无解析信息"
    
    def generate_summary_statistics(self, stats: StatisticsResult) -> Dict[str, Any]:
        """生成汇总统计"""
        summary = {
            'total_questions': sum(stats.question_type_distribution.values()),
            'question_types': list(stats.question_type_distribution.keys()),
            'most_common_type': max(stats.question_type_distribution.items(), key=lambda x: x[1]) if stats.question_type_distribution else None,
            'average_difficulty': self._calculate_average_difficulty(stats.difficulty_distribution),
            'top_keywords': list(stats.keyword_frequency.keys())[:10] if stats.keyword_frequency else [],
            'option_patterns': self._analyze_option_patterns(stats.option_distribution)
        }
        
        return summary
    
    def _calculate_average_difficulty(self, difficulty_dist: Dict[str, int]) -> float:
        """计算平均难度"""
        if not difficulty_dist:
            return 0.0
        
        total_questions = sum(difficulty_dist.values())
        weighted_sum = sum(
            self.difficulty_scores.get(difficulty, 2.0) * count
            for difficulty, count in difficulty_dist.items()
        )
        
        return weighted_sum / total_questions if total_questions > 0 else 0.0
    
    def _analyze_option_patterns(self, option_dist: Dict[str, Dict[str, int]]) -> Dict[str, Any]:
        """分析选项模式"""
        patterns = {
            'negation_frequency': {},
            'absolute_frequency': {},
            'length_distribution': {}
        }
        
        for q_type, type_stats in option_dist.items():
            # 统计否定词频率
            negation_count = sum(count for key, count in type_stats.items() if 'negation' in key)
            patterns['negation_frequency'][q_type] = negation_count
            
            # 统计绝对词频率
            absolute_count = sum(count for key, count in type_stats.items() if 'absolute' in key)
            patterns['absolute_frequency'][q_type] = absolute_count
            
            # 统计长度分布
            length_stats = {'short': 0, 'medium': 0, 'long': 0}
            for key, count in type_stats.items():
                if 'length_short' in key:
                    length_stats['short'] += count
                elif 'length_medium' in key:
                    length_stats['medium'] += count
                elif 'length_long' in key:
                    length_stats['long'] += count
            
            patterns['length_distribution'][q_type] = length_stats
        
        return patterns