"""
考研英语试卷分析智能体
"""

__version__ = "1.0.0"
__author__ = "Exam Analyzer Team"