"""
文章溯源模块
"""

import re
import requests
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from urllib.parse import quote
from bs4 import BeautifulSoup
import time


@dataclass
class SourceInfo:
    """文章来源信息"""
    title: str
    author: str
    publication: str
    date: str
    url: str
    confidence: float  # 匹配置信度
    source_type: str  # 来源类型：news, academic, blog, etc.


class SourceTracker:
    """文章溯源器"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.search_engines = {
            'google': self._search_google,
            'bing': self._search_bing,
            'duckduckgo': self._search_duckduckgo
        }
        self.source_patterns = {
            'news': [
                r'(?:Reuters|AP|AFP|BBC|CNN|New York Times|Washington Post)',
                r'(?:新华社|人民日报|光明日报)',
                r'(?:The Guardian|Financial Times|The Economist)'
            ],
            'academic': [
                r'(?:Nature|Science|Cell|The Lancet)',
                r'(?:Journal of|Proceedings of|Transactions on)',
                r'(?:University|College|Institute|Research)'
            ],
            'magazine': [
                r'(TIME|Newsweek|The Atlantic|New Yorker)',
                r'(National Geographic|Scientific American)',
                r'(读者|青年文摘|三联生活周刊)'
            ]
        }
    
    def track_source(self, passage: str, max_results: int = 5) -> List[SourceInfo]:
        """追踪文章来源"""
        if not passage or len(passage.strip()) < 50:
            return []
        
        # 提取关键句子进行搜索
        key_sentences = self._extract_key_sentences(passage)
        
        all_sources = []
        
        for sentence in key_sentences[:3]:  # 最多搜索3个关键句子
            try:
                sources = self._search_sentence(sentence, max_results)
                all_sources.extend(sources)
                time.sleep(1)  # 避免请求过快
            except Exception as e:
                print(f"搜索句子时出错: {e}")
                continue
        
        # 去重并按置信度排序
        unique_sources = self._deduplicate_sources(all_sources)
        return sorted(unique_sources, key=lambda x: x.confidence, reverse=True)[:max_results]
    
    def _extract_key_sentences(self, passage: str) -> List[str]:
        """提取关键句子"""
        sentences = re.split(r'[.!?]+', passage)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        # 过滤出长度适中的句子
        key_sentences = []
        for sentence in sentences:
            if 50 <= len(sentence) <= 200:
                key_sentences.append(sentence)
        
        return key_sentences
    
    def _search_sentence(self, sentence: str, max_results: int = 5) -> List[SourceInfo]:
        """搜索句子来源"""
        sources = []
        
        # 尝试不同的搜索引擎
        for engine_name, search_func in self.search_engines.items():
            try:
                engine_sources = search_func(sentence, max_results)
                sources.extend(engine_sources)
                if len(sources) >= max_results:
                    break
            except Exception as e:
                print(f"{engine_name}搜索失败: {e}")
                continue
        
        return sources
    
    def _search_google(self, query: str, max_results: int) -> List[SourceInfo]:
        """Google搜索（需要API密钥）"""
        if not self.api_key:
            return self._search_duckduckgo(query, max_results)
        
        url = "https://www.googleapis.com/customsearch/v1"
        params = {
            'key': self.api_key,
            'cx': 'YOUR_SEARCH_ENGINE_ID',  # 需要配置搜索引擎ID
            'q': f'"{query}"',  # 精确匹配
            'num': max_results
        }
        
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            sources = []
            for item in data.get('items', []):
                source = SourceInfo(
                    title=item.get('title', ''),
                    author='',
                    publication=self._extract_publication(item.get('displayLink', '')),
                    date='',
                    url=item.get('link', ''),
                    confidence=self._calculate_confidence(query, item.get('snippet', '')),
                    source_type=self._determine_source_type(item.get('displayLink', ''))
                )
                sources.append(source)
            
            return sources
        except Exception as e:
            print(f"Google搜索错误: {e}")
            return []
    
    def _search_bing(self, query: str, max_results: int) -> List[SourceInfo]:
        """Bing搜索"""
        url = "https://www.bing.com/search"
        params = {
            'q': f'"{query}"',
            'count': max_results
        }
        
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, params=params, headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            sources = []
            
            for result in soup.find_all('li', class_='b_algo')[:max_results]:
                title_elem = result.find('h2')
                link_elem = result.find('a')
                snippet_elem = result.find('div', class_='b_caption')
                
                if title_elem and link_elem:
                    source = SourceInfo(
                        title=title_elem.get_text().strip(),
                        author='',
                        publication=self._extract_publication(link_elem.get('href', '')),
                        date='',
                        url=link_elem.get('href', ''),
                        confidence=self._calculate_confidence(
                            query, 
                            snippet_elem.get_text() if snippet_elem else ''
                        ),
                        source_type=self._determine_source_type(link_elem.get('href', ''))
                    )
                    sources.append(source)
            
            return sources
        except Exception as e:
            print(f"Bing搜索错误: {e}")
            return []
    
    def _search_duckduckgo(self, query: str, max_results: int) -> List[SourceInfo]:
        """DuckDuckGo搜索"""
        url = "https://duckduckgo.com/html/"
        params = {
            'q': f'"{query}"'
        }
        
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, params=params, headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            sources = []
            
            for result in soup.find_all('div', class_='result')[:max_results]:
                title_elem = result.find('a', class_='result__a')
                snippet_elem = result.find('a', class_='result__snippet')
                
                if title_elem:
                    source = SourceInfo(
                        title=title_elem.get_text().strip(),
                        author='',
                        publication=self._extract_publication(title_elem.get('href', '')),
                        date='',
                        url=title_elem.get('href', ''),
                        confidence=self._calculate_confidence(
                            query, 
                            snippet_elem.get_text() if snippet_elem else ''
                        ),
                        source_type=self._determine_source_type(title_elem.get('href', ''))
                    )
                    sources.append(source)
            
            return sources
        except Exception as e:
            print(f"DuckDuckGo搜索错误: {e}")
            return []
    
    def _extract_publication(self, url_or_domain: str) -> str:
        """从URL或域名提取出版物名称"""
        # 提取域名
        domain_match = re.search(r'(?:https?://)?(?:www\.)?([^/]+)', url_or_domain)
        if domain_match:
            domain = domain_match.group(1)
            
            # 移除常见的TLD
            domain = re.sub(r'\.(com|org|net|edu|gov|co\.[a-z]{2})$', '', domain)
            
            return domain
        
        return url_or_domain
    
    def _determine_source_type(self, url_or_domain: str) -> str:
        """确定来源类型"""
        text = url_or_domain.lower()
        
        for source_type, patterns in self.source_patterns.items():
            for pattern in patterns:
                if re.search(pattern, text, re.IGNORECASE):
                    return source_type
        
        # 基于域名的启发式判断
        if any(tld in text for tld in ['.edu', '.ac.', '.gov']):
            return 'academic'
        elif any(domain in text for domain in ['news', 'press', 'media']):
            return 'news'
        elif any(domain in text for domain in ['blog', 'medium', 'substack']):
            return 'blog'
        else:
            return 'website'
    
    def _calculate_confidence(self, original: str, snippet: str) -> float:
        """计算匹配置信度"""
        if not snippet:
            return 0.0
        
        original_words = set(re.findall(r'\w+', original.lower()))
        snippet_words = set(re.findall(r'\w+', snippet.lower()))
        
        if not original_words:
            return 0.0
        
        # 计算词汇重叠度
        overlap = len(original_words & snippet_words)
        confidence = overlap / len(original_words)
        
        # 如果是精确匹配，提高置信度
        if original.lower() in snippet.lower():
            confidence = min(confidence + 0.3, 1.0)
        
        return confidence
    
    def _deduplicate_sources(self, sources: List[SourceInfo]) -> List[SourceInfo]:
        """去重来源信息"""
        seen_urls = set()
        seen_titles = set()
        unique_sources = []
        
        for source in sources:
            # 基于URL去重
            if source.url and source.url in seen_urls:
                continue
            if source.url:
                seen_urls.add(source.url)
            
            # 基于标题去重（相似度检查）
            title_similar = False
            for seen_title in seen_titles:
                if self._calculate_similarity(source.title, seen_title) > 0.8:
                    title_similar = True
                    break
            
            if title_similar:
                continue
            
            seen_titles.add(source.title)
            unique_sources.append(source)
        
        return unique_sources
    
    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """计算文本相似度"""
        words1 = set(re.findall(r'\w+', text1.lower()))
        words2 = set(re.findall(r'\w+', text2.lower()))
        
        if not words1 or not words2:
            return 0.0
        
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        
        return intersection / union if union > 0 else 0.0
    
    def analyze_source_patterns(self, sources: List[SourceInfo]) -> Dict[str, Any]:
        """分析来源模式"""
        if not sources:
            return {}
        
        analysis = {
            'total_sources': len(sources),
            'source_types': {},
            'publications': {},
            'confidence_distribution': {'high': 0, 'medium': 0, 'low': 0},
            'average_confidence': 0.0
        }
        
        total_confidence = 0.0
        
        for source in sources:
            # 统计来源类型
            source_type = source.source_type
            analysis['source_types'][source_type] = analysis['source_types'].get(source_type, 0) + 1
            
            # 统计出版物
            publication = source.publication
            if publication:
                analysis['publications'][publication] = analysis['publications'].get(publication, 0) + 1
            
            # 统计置信度分布
            if source.confidence >= 0.7:
                analysis['confidence_distribution']['high'] += 1
            elif source.confidence >= 0.4:
                analysis['confidence_distribution']['medium'] += 1
            else:
                analysis['confidence_distribution']['low'] += 1
            
            total_confidence += source.confidence
        
        analysis['average_confidence'] = total_confidence / len(sources) if sources else 0.0
        
        return analysis