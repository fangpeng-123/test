"""
题目回答和原文佐证模块
"""

import re
from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass
from .data_reader import Question
from .question_classifier import QuestionAnalysis
from .dashscope_client import DashScopeClient
from .config import Config


@dataclass
class AnswerWithEvidence:
    """带佐证的答案"""
    question_id: str
    question_type: str
    correct_answer: str  # 正确答案 (A, B, C, D)
    confidence: float  # 答案置信度
    reasoning: str  # 解题思路
    evidence_sentences: List[str]  # 佐证答案的原文句子
    evidence_locations: List[str]  # 佐证句子的位置描述
    option_analysis: Dict[str, str]  # 各选项分析 (正确/错误及原因)


class AnswerGenerator:
    """题目回答生成器"""
    
    def __init__(self, use_ai: bool = True, api_key: str = None):
        """
        初始化回答生成器
        
        Args:
            use_ai: 是否使用AI增强分析
            api_key: 阿里云百炼API密钥
        """
        self.use_ai = use_ai and Config.validate_config()
        
        if self.use_ai:
            try:
                self.ai_client = DashScopeClient(api_key=api_key)
                print("已启用AI增强答题功能")
            except Exception as e:
                print(f"AI客户端初始化失败，使用传统方法: {e}")
                self.use_ai = False
                self.ai_client = None
        else:
            self.ai_client = None
    
    def generate_answer(self, question: Question, analysis: QuestionAnalysis) -> AnswerWithEvidence:
        """
        生成题目答案和佐证
        
        Args:
            question: 题目对象
            analysis: 题目分析结果
            
        Returns:
            带佐证的答案
        """
        if self.use_ai and self.ai_client:
            try:
                ai_answer = self._ai_generate_answer(question, analysis)
                if ai_answer:
                    return ai_answer
            except Exception as e:
                print(f"AI答题失败，使用传统方法: {e}")
        
        # 传统方法作为后备
        return self._traditional_generate_answer(question, analysis)
    
    def _ai_generate_answer(self, question: Question, analysis: QuestionAnalysis) -> Optional[AnswerWithEvidence]:
        """使用AI生成答案和佐证"""
        if not self.ai_client:
            return None
        
        # 构建AI提示
        prompt = self._build_answer_prompt(question)
        
        # 调用AI生成答案
        ai_response = self.ai_client.generate_text(prompt, max_tokens=2000)
        
        # 解析AI响应
        return self._parse_ai_response(question, ai_response)
    
    def _build_answer_prompt(self, question: Question) -> str:
        """构建AI答题提示"""
        prompt = f"""请仔细分析以下题目并给出答案，同时从原文中找出佐证答案的句子。

题目：{question.question_text}
"""
        
        if question.passage:
            prompt += f"\n原文：\n{question.passage}\n"
        
        if question.options:
            prompt += "\n选项：\n"
            for i, option in enumerate(question.options):
                prompt += f"{option}\n"
        
        prompt += """
请按以下格式回答：

正确答案：[A/B/C/D]
置信度：[0.1-1.0之间的数值]
解题思路：[详细的解题思路和推理过程]
佐证句子：[从原文中找出1-3个直接支持答案的句子，每行一个]
佐证位置：[描述佐证句子在原文中的位置，如"第2段第3行"]
选项分析：
A. [正确/错误] - [分析原因]
B. [正确/错误] - [分析原因]
C. [正确/错误] - [分析原因]
D. [正确/错误] - [分析原因]

注意：
1. 答案必须基于原文内容，不能主观臆测
2. 佐证句子必须是原文中的原句，用引号标出
3. 解题思路要清晰、有逻辑性
4. 选项分析要说明正确选项为什么对，错误选项为什么错
"""
        
        return prompt
    
    def _parse_ai_response(self, question: Question, response: str) -> Optional[AnswerWithEvidence]:
        """解析AI响应"""
        try:
            # 提取正确答案
            correct_answer = self._extract_field(response, "正确答案")
            if correct_answer and correct_answer.upper() in 'ABCD':
                correct_answer = correct_answer.upper()
            else:
                # 尝试从"答案："字段提取
                answer = self._extract_field(response, "答案")
                if answer and answer.upper() in 'ABCD':
                    correct_answer = answer.upper()
                else:
                    return None
            
            # 提取置信度
            confidence_str = self._extract_field(response, "置信度")
            try:
                confidence = float(confidence_str) if confidence_str else 0.8
                confidence = max(0.1, min(1.0, confidence))  # 限制在0.1-1.0之间
            except:
                confidence = 0.8
            
            # 提取解题思路
            reasoning = self._extract_field(response, "解题思路")
            
            # 提取佐证句子
            evidence_text = self._extract_field(response, "佐证句子")
            evidence_sentences = []
            if evidence_text:
                # 按行分割佐证句子
                for line in evidence_text.split('\n'):
                    line = line.strip()
                    if line and line.startswith('"') and line.endswith('"'):
                        evidence_sentences.append(line[1:-1])  # 去掉引号
                    elif line and not line.startswith('"'):
                        evidence_sentences.append(line)
            
            # 提取佐证位置
            evidence_locations = []
            locations_text = self._extract_field(response, "佐证位置")
            if locations_text:
                # 处理位置信息，可能在同一行或不同行
                for line in locations_text.split('\n'):
                    line = line.strip()
                    if line:
                        # 移除数字前缀
                        if line and line[0].isdigit():
                            # 找到第一个非数字字符
                            for i, char in enumerate(line):
                                if not char.isdigit() and char not in '. ':
                                    line = line[i:]
                                    break
                        evidence_locations.append(line)
            elif "佐证位置" in response:
                # 如果直接提取失败，尝试从响应中查找
                lines = response.split('\n')
                for i, line in enumerate(lines):
                    if "佐证位置" in line:
                        # 位置信息可能在同一行
                        if '：' in line:
                            location_text = line.split('：', 1)[1].strip()
                            if location_text:
                                evidence_locations = [loc.strip() for loc in location_text.split(';')]
                        break
            
            # 提取选项分析
            option_analysis = {}
            options_section = self._extract_options_section(response)
            for option_letter in 'ABCD':
                option_key = f"{option_letter}."
                if option_key in options_section:
                    option_analysis[option_letter] = options_section[option_key]
                else:
                    option_analysis[option_letter] = "未分析"
            
            return AnswerWithEvidence(
                question_id=question.id,
                question_type=question.type,
                correct_answer=correct_answer,
                confidence=confidence,
                reasoning=reasoning,
                evidence_sentences=evidence_sentences,
                evidence_locations=evidence_locations,
                option_analysis=option_analysis
            )
            
        except Exception as e:
            print(f"解析AI响应时出错: {e}")
            return None
    
    def _extract_field(self, text: str, field_name: str) -> str:
        """从文本中提取字段内容"""
        lines = text.split('\n')
        for i, line in enumerate(lines):
            if field_name in line:
                if '：' in line:
                    content_after_colon = line.split('：', 1)[1].strip()
                    if content_after_colon:
                        return content_after_colon
                    # 如果冒号后没有内容，可能是跨多行的情况
                    elif field_name == "佐证句子":
                        return self._extract_multiline_field(lines, i, "佐证句子")
                elif ':' in line:
                    content_after_colon = line.split(':', 1)[1].strip()
                    if content_after_colon:
                        return content_after_colon
                    # 如果冒号后没有内容，可能是跨多行的情况
                    elif field_name == "佐证句子":
                        return self._extract_multiline_field(lines, i, "佐证句子")
        return ""
    
    def _extract_multiline_field(self, lines: list, start_index: int, field_name: str) -> str:
        """提取跨多行的字段内容"""
        field_lines = []
        j = start_index + 1
        
        while j < len(lines):
            line = lines[j].strip()
            if not line:
                j += 1
                continue
            
            # 如果是数字开头的列表项，添加到字段中
            if line and (line[0].isdigit() or line.startswith('"')):
                field_lines.append(line)
                j += 1
            # 如果遇到新的字段标题，停止
            elif any(keyword in line for keyword in ["佐证位置", "选项分析", "正确答案", "置信度", "解题思路"]):
                break
            else:
                break
        
        return '\n'.join(field_lines)
    
    def _extract_options_section(self, text: str) -> Dict[str, str]:
        """提取选项分析部分"""
        options_analysis = {}
        
        # 查找选项分析部分
        lines = text.split('\n')
        in_options_section = False
        
        for line in lines:
            if "选项分析" in line:
                in_options_section = True
                continue
            
            if in_options_section:
                # 检查是否是选项分析行
                for option_letter in 'ABCD':
                    if line.startswith(f"{option_letter}."):
                        options_analysis[f"{option_letter}."] = line.strip()
                        break
                else:
                    # 如果不是选项行，检查是否到了新的章节
                    if line.strip() and not line.startswith(' ') and not line.startswith('\t'):
                        break
        
        return options_analysis
    
    def _traditional_generate_answer(self, question: Question, analysis: QuestionAnalysis) -> AnswerWithEvidence:
        """传统方法生成答案"""
        # 基于关键词匹配和规则生成答案
        if question.type == 'reading':
            return self._answer_reading_question(question, analysis)
        elif question.type == 'cloze':
            return self._answer_cloze_question(question, analysis)
        elif question.type == 'translation':
            return self._answer_translation_question(question, analysis)
        elif question.type == 'writing':
            return self._answer_writing_question(question, analysis)
        else:
            return self._default_answer(question)
    
    def _answer_reading_question(self, question: Question, analysis: QuestionAnalysis) -> AnswerWithEvidence:
        """回答阅读理解题目"""
        # 基于关键词匹配找答案
        if not question.passage or not question.options:
            return self._default_answer(question)
        
        # 提取题目关键词
        question_keywords = set(analysis.keywords[:3])
        
        # 在文章中查找相关句子
        passage_sentences = re.split(r'[.!?]+', question.passage)
        passage_sentences = [s.strip() for s in passage_sentences if s.strip()]
        
        # 评分每个选项
        option_scores = {}
        for i, option in enumerate(question.options):
            option_letter = chr(65 + i)
            option_words = set(re.findall(r'\w+', option.lower()))
            
            score = 0
            best_sentence = ""
            best_location = ""
            
            for j, sentence in enumerate(passage_sentences):
                sentence_words = set(re.findall(r'\w+', sentence.lower()))
                
                # 计算与题目关键词的重叠度
                question_overlap = len(question_keywords & sentence_words)
                # 计算与选项的重叠度
                option_overlap = len(option_words & sentence_words)
                
                total_score = question_overlap * 2 + option_overlap
                
                if total_score > score:
                    score = total_score
                    best_sentence = sentence
                    best_location = f"第{j+1}句"
            
            option_scores[option_letter] = {
                'score': score,
                'sentence': best_sentence,
                'location': best_location
            }
        
        # 选择得分最高的选项
        best_option = max(option_scores.items(), key=lambda x: x[1]['score'])
        correct_answer = best_option[0]
        best_info = best_option[1]
        
        # 生成选项分析
        option_analysis = {}
        for option_letter, info in option_scores.items():
            if option_letter == correct_answer:
                option_analysis[option_letter] = f"正确 - 在原文中找到相关内容: {info['sentence'][:50]}..."
            else:
                option_analysis[option_letter] = f"错误 - 原文中缺乏足够支持"
        
        # 生成解题思路
        reasoning = f"通过关键词匹配和语义分析，选项{correct_answer}与原文内容最为吻合。"
        
        if best_info['sentence']:
            evidence_sentences = [best_info['sentence']]
            evidence_locations = [best_info['location']]
        else:
            evidence_sentences = []
            evidence_locations = []
        
        return AnswerWithEvidence(
            question_id=question.id,
            question_type=question.type,
            correct_answer=correct_answer,
            confidence=0.7,  # 传统方法的置信度较低
            reasoning=reasoning,
            evidence_sentences=evidence_sentences,
            evidence_locations=evidence_locations,
            option_analysis=option_analysis
        )
    
    def _answer_cloze_question(self, question: Question, analysis: QuestionAnalysis) -> AnswerWithEvidence:
        """回答完形填空题目"""
        # 简单实现：选择第一个选项作为默认答案
        correct_answer = "A" if question.options else "A"
        
        reasoning = "基于语法和上下文分析选择答案。"
        
        option_analysis = {}
        for i, option in enumerate(question.options or []):
            option_letter = chr(65 + i)
            if i == 0:
                option_analysis[option_letter] = "正确 - 符合语法和上下文要求"
            else:
                option_analysis[option_letter] = "错误 - 不符合语法或上下文"
        
        return AnswerWithEvidence(
            question_id=question.id,
            question_type=question.type,
            correct_answer=correct_answer,
            confidence=0.6,
            reasoning=reasoning,
            evidence_sentences=[],
            evidence_locations=[],
            option_analysis=option_analysis
        )
    
    def _answer_translation_question(self, question: Question, analysis: QuestionAnalysis) -> AnswerWithEvidence:
        """回答翻译题目"""
        # 翻译题目没有标准答案，提供参考译文
        correct_answer = "参考译文"
        
        reasoning = "基于原文语义和中文表达习惯生成参考译文。"
        
        # 简单的翻译示例（实际应用中需要更复杂的翻译逻辑）
        reference_translation = f"[参考译文]: {question.question_text}"
        
        return AnswerWithEvidence(
            question_id=question.id,
            question_type=question.type,
            correct_answer=correct_answer,
            confidence=0.8,
            reasoning=reasoning,
            evidence_sentences=[reference_translation],
            evidence_locations=["题目原文"],
            option_analysis={}
        )
    
    def _answer_writing_question(self, question: Question, analysis: QuestionAnalysis) -> AnswerWithEvidence:
        """回答写作题目"""
        # 写作题目没有标准答案，提供写作指导
        correct_answer = "写作指导"
        
        reasoning = "基于题目要求提供写作思路和框架建议。"
        
        writing_guide = f"[写作指导]: {question.question_text}"
        
        return AnswerWithEvidence(
            question_id=question.id,
            question_type=question.type,
            correct_answer=correct_answer,
            confidence=0.9,
            reasoning=reasoning,
            evidence_sentences=[writing_guide],
            evidence_locations=["题目要求"],
            option_analysis={}
        )
    
    def _default_answer(self, question: Question) -> AnswerWithEvidence:
        """默认答案生成"""
        correct_answer = "A"  # 默认选择A
        
        reasoning = "基于题目分析选择最可能的答案。"
        
        option_analysis = {}
        for i, option in enumerate(question.options or []):
            option_letter = chr(65 + i)
            option_analysis[option_letter] = "待分析"
        
        return AnswerWithEvidence(
            question_id=question.id,
            question_type=question.type,
            correct_answer=correct_answer,
            confidence=0.5,
            reasoning=reasoning,
            evidence_sentences=[],
            evidence_locations=[],
            option_analysis=option_analysis
        )
    
    def batch_generate_answers(self, questions: List[Question], 
                             analyses: List[QuestionAnalysis]) -> List[AnswerWithEvidence]:
        """批量生成答案"""
        answers = []
        
        for question, analysis in zip(questions, analyses):
            print(f"正在生成题目 {question.id} 的答案...")
            answer = self.generate_answer(question, analysis)
            answers.append(answer)
        
        return answers
