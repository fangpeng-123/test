"""
试卷分析智能体主程序
"""

import os
from typing import Optional, List
from pathlib import Path

from .data_reader import ExamDataReader, ExamData
from .question_classifier import QuestionClassifier, QuestionAnalysis
from .source_tracker import SourceTracker, SourceInfo
from .statistics_analyzer import StatisticsAnalyzer, StatisticsResult
from .technique_analyzer import TechniqueAnalyzer, TechniqueAnalysis
from .answer_generator import AnswerGenerator, AnswerWithEvidence
from .report_generator import ReportGenerator
from .config import Config


class ExamAnalyzer:
    """试卷分析智能体主类"""
    
    def __init__(self, api_key: Optional[str] = None, dashscope_api_key: Optional[str] = None, use_ai: bool = True):
        """
        初始化试卷分析器
        
        Args:
            api_key: 搜索API密钥，用于文章溯源
            dashscope_api_key: 阿里云百炼API密钥，用于AI增强分析
            use_ai: 是否使用AI增强分析
        """
        # 设置API密钥
        if dashscope_api_key:
            Config.set_dashscope_api_key(dashscope_api_key)
        
        self.data_reader = ExamDataReader()
        self.question_classifier = QuestionClassifier(use_ai=use_ai, api_key=dashscope_api_key)
        self.source_tracker = SourceTracker(api_key=api_key)
        self.statistics_analyzer = StatisticsAnalyzer()
        self.technique_analyzer = TechniqueAnalyzer()
        self.answer_generator = AnswerGenerator(use_ai=use_ai, api_key=dashscope_api_key)
        self.report_generator = ReportGenerator()
    
    def analyze_exam(self, exam_file_path: str, 
                    enable_source_tracking: bool = True,
                    enable_answer_generation: bool = True,
                    output_dir: str = "output") -> str:
        """
        分析试卷并生成报告
        
        Args:
            exam_file_path: 试卷文件路径
            enable_source_tracking: 是否启用文章溯源
            enable_answer_generation: 是否启用答案生成
            output_dir: 输出目录
            
        Returns:
            生成的报告文件路径
        """
        print(f"开始分析试卷: {exam_file_path}")
        
        # 1. 读取试卷数据
        print("1. 读取试卷数据...")
        exam_data = self.data_reader.read_markdown_file(exam_file_path)
        print(f"   读取完成，共{len(exam_data.questions)}道题目")
        
        # 2. 题目分类和拆解
        print("2. 题目分类和拆解...")
        question_analyses = []
        for i, question in enumerate(exam_data.questions):
            analysis = self.question_classifier.classify_question(question)
            question_analyses.append(analysis)
            if (i + 1) % 5 == 0:
                print(f"   已处理{i + 1}/{len(exam_data.questions)}道题目")
        
        # 3. 生成答案和佐证
        answers = []
        if enable_answer_generation:
            print("3. 生成答案和佐证...")
            answers = self.answer_generator.batch_generate_answers(exam_data.questions, question_analyses)
        
        # 4. 文章溯源
        source_infos = []
        if enable_source_tracking:
            print("4. 文章溯源分析...")
            passages = [q.passage for q in exam_data.questions if q.passage and q.passage.strip()]
            for i, passage in enumerate(passages):
                print(f"   正在溯源第{i + 1}/{len(passages)}篇文章...")
                sources = self.source_tracker.track_source(passage)
                source_infos.extend(sources)
        
        # 5. 统计分析
        print("5. 统计分析...")
        statistics = self.statistics_analyzer.analyze_exam_statistics(exam_data, question_analyses)
        
        # 6. 技巧分析
        print("6. 技巧分析...")
        technique_analysis = self.technique_analyzer.analyze_techniques(
            exam_data.questions, question_analyses, statistics.annotations
        )
        
        # 7. 生成报告
        print("7. 生成分析报告...")
        
        # 确保输出目录存在
        os.makedirs(output_dir, exist_ok=True)
        
        # 生成完整报告
        report_filename = f"{exam_data.year}_考研英语分析报告.md"
        report_path = os.path.join(output_dir, report_filename)
        
        self.report_generator.generate_report(
            exam_data=exam_data,
            question_analyses=question_analyses,
            statistics=statistics,
            source_infos=source_infos,
            technique_analysis=technique_analysis,
            answers=answers,
            output_path=report_path
        )
        
        # 生成简要报告
        summary_filename = f"{exam_data.year}_考研英语简要分析.md"
        summary_path = os.path.join(output_dir, summary_filename)
        
        self.report_generator.generate_summary_report(
            exam_data=exam_data,
            statistics=statistics,
            output_path=summary_path
        )
        
        # 生成答题报告
        if enable_answer_generation:
            answer_filename = f"{exam_data.year}_考研英语答题报告.md"
            answer_path = os.path.join(output_dir, answer_filename)
            
            self.report_generator.generate_answer_report(
                exam_data=exam_data,
                answers=answers,
                output_path=answer_path
            )
            
            print(f"分析完成！报告已保存到:")
            print(f"   完整报告: {report_path}")
            print(f"   简要报告: {summary_path}")
            print(f"   答题报告: {answer_path}")
        else:
            print(f"分析完成！报告已保存到:")
            print(f"   完整报告: {report_path}")
            print(f"   简要报告: {summary_path}")
        
        return report_path
    
    def analyze_single_question(self, question_text: str, 
                              passage: str = None,
                              options: List[str] = None) -> QuestionAnalysis:
        """
        分析单个题目
        
        Args:
            question_text: 题目文本
            passage: 文章内容（可选）
            options: 选项列表（可选）
            
        Returns:
            题目分析结果
        """
        from .data_reader import Question
        
        # 创建题目对象
        question = Question(
            id="single_question",
            type="reading",  # 默认为阅读理解类型
            passage=passage,
            question_text=question_text,
            options=options or []
        )
        
        # 自动判断题目类型
        if "翻译" in question_text or "translate" in question_text.lower():
            question.type = "translation"
        elif "写作" in question_text or "writing" in question_text.lower():
            question.type = "writing"
        elif "完形" in question_text or "cloze" in question_text.lower():
            question.type = "cloze"
        
        # 进行分析
        analysis = self.question_classifier.classify_question(question)
        
        return analysis
    
    def track_passage_source(self, passage: str) -> List[SourceInfo]:
        """
        追踪单篇文章来源
        
        Args:
            passage: 文章内容
            
        Returns:
            来源信息列表
        """
        return self.source_tracker.track_source(passage)
    
    def batch_analyze(self, exam_file_paths: List[str], 
                     output_dir: str = "output") -> List[str]:
        """
        批量分析多份试卷
        
        Args:
            exam_file_paths: 试卷文件路径列表
            output_dir: 输出目录
            
        Returns:
            生成的报告文件路径列表
        """
        report_paths = []
        
        for exam_file_path in exam_file_paths:
            print(f"\n{'='*50}")
            print(f"分析试卷: {exam_file_path}")
            print(f"{'='*50}")
            
            try:
                report_path = self.analyze_exam(exam_file_path, output_dir=output_dir)
                report_paths.append(report_path)
            except Exception as e:
                print(f"分析试卷 {exam_file_path} 时出错: {e}")
                continue
        
        print(f"\n批量分析完成！共生成{len(report_paths)}份报告")
        return report_paths
    
    def generate_answers(self, exam_file_path: str, output_dir: str = "output") -> str:
        """
        生成试卷答案和佐证
        
        Args:
            exam_file_path: 试卷文件路径
            output_dir: 输出目录
            
        Returns:
            答题报告文件路径
        """
        print(f"开始生成答案: {exam_file_path}")
        
        # 1. 读取试卷数据
        print("1. 读取试卷数据...")
        exam_data = self.data_reader.read_markdown_file(exam_file_path)
        print(f"   读取完成，共{len(exam_data.questions)}道题目")
        
        # 2. 题目分类和拆解
        print("2. 题目分类和拆解...")
        question_analyses = []
        for i, question in enumerate(exam_data.questions):
            analysis = self.question_classifier.classify_question(question)
            question_analyses.append(analysis)
            if (i + 1) % 5 == 0:
                print(f"   已处理{i + 1}/{len(exam_data.questions)}道题目")
        
        # 3. 生成答案和佐证
        print("3. 生成答案和佐证...")
        answers = self.answer_generator.batch_generate_answers(exam_data.questions, question_analyses)
        
        # 4. 生成答题报告
        print("4. 生成答题报告...")
        
        # 确保输出目录存在
        os.makedirs(output_dir, exist_ok=True)
        
        # 生成答题报告
        answer_filename = f"{exam_data.year}_考研英语答题报告.md"
        answer_path = os.path.join(output_dir, answer_filename)
        
        self.report_generator.generate_answer_report(
            exam_data=exam_data,
            answers=answers,
            output_path=answer_path
        )
        
        print(f"答题报告已保存到: {answer_path}")
        
        return answer_path
    
    def get_analysis_summary(self, exam_file_path: str) -> dict:
        """
        获取试卷分析摘要（不生成完整报告）
        
        Args:
            exam_file_path: 试卷文件路径
            
        Returns:
            分析摘要字典
        """
        # 读取试卷数据
        exam_data = self.data_reader.read_markdown_file(exam_file_path)
        
        # 题目分类和拆解
        question_analyses = []
        for question in exam_data.questions:
            analysis = self.question_classifier.classify_question(question)
            question_analyses.append(analysis)
        
        # 统计分析
        statistics = self.statistics_analyzer.analyze_exam_statistics(exam_data, question_analyses)
        
        # 生成摘要
        summary = self.report_generator._generate_summary_statistics(statistics)
        
        return {
            'exam_info': {
                'title': exam_data.title,
                'year': exam_data.year,
                'total_questions': len(exam_data.questions)
            },
            'statistics': summary,
            'question_types': statistics.question_type_distribution,
            'difficulty_distribution': statistics.difficulty_distribution
        }


def main():
    """主函数 - 命令行接口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='考研英语试卷分析智能体')
    parser.add_argument('exam_file', nargs='?', help='试卷文件路径')
    parser.add_argument('--output', '-o', default='output', help='输出目录')
    parser.add_argument('--no-source', action='store_true', help='禁用文章溯源')
    parser.add_argument('--api-key', help='搜索API密钥')
    parser.add_argument('--dashscope-api-key', help='阿里云百炼API密钥')
    parser.add_argument('--no-ai', action='store_true', help='禁用AI增强分析')
    parser.add_argument('--batch', nargs='+', help='批量分析多个文件')
    parser.add_argument('--test-ai', action='store_true', help='测试AI连接')
    parser.add_argument('--answers-only', action='store_true', help='仅生成答案和佐证，不进行完整分析')
    
    args = parser.parse_args()
    
    # 测试AI连接
    if args.test_ai:
        from .dashscope_client import DashScopeClient
        try:
            client = DashScopeClient(args.dashscope_api_key)
            if client.test_connection():
                print("✅ 阿里云百炼连接测试成功")
            else:
                print("❌ 阿里云百炼连接测试失败")
        except Exception as e:
            print(f"❌ 连接测试出错: {e}")
        return 0
    
    # 检查参数
    if not args.exam_file and not args.batch:
        parser.print_help()
        return 1
    
    # 初始化分析器
    analyzer = ExamAnalyzer(
        api_key=args.api_key,
        dashscope_api_key=args.dashscope_api_key,
        use_ai=not args.no_ai
    )
    
    try:
        if args.batch:
            # 批量分析
            if args.answers_only:
                answer_paths = []
                for exam_file in args.batch:
                    answer_path = analyzer.generate_answers(exam_file, output_dir=args.output)
                    answer_paths.append(answer_path)
                print(f"\n批量答题完成，生成报告:")
                for path in answer_paths:
                    print(f"  - {path}")
            else:
                report_paths = analyzer.batch_analyze(args.batch, output_dir=args.output)
                print(f"\n批量分析完成，生成报告:")
                for path in report_paths:
                    print(f"  - {path}")
        else:
            if args.answers_only:
                # 仅生成答案
                answer_path = analyzer.generate_answers(args.exam_file, output_dir=args.output)
                print(f"\n答题完成，报告保存至: {answer_path}")
            else:
                # 单文件分析
                report_path = analyzer.analyze_exam(
                    args.exam_file, 
                    enable_source_tracking=not args.no_source,
                    output_dir=args.output
                )
                print(f"\n分析完成，报告保存至: {report_path}")
    
    except Exception as e:
        print(f"分析过程中出现错误: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())