"""
技巧分析和统计功能模块
"""

import re
from typing import Dict, List, Any, Tuple, Set
from collections import Counter, defaultdict
from dataclasses import dataclass
import numpy as np
from .data_reader import Question
from .question_classifier import QuestionAnalysis
from .statistics_analyzer import QuestionAnnotation


@dataclass
class InterferingOption:
    """干扰选项分析"""
    position: str  # 选项位置 (A, B, C, D)
    content: str  # 选项内容
    interference_type: str  # 干扰类型
    detection_method: str  # 检测方法
    confidence: float  # 置信度


@dataclass
class TechniqueAnalysis:
    """技巧分析结果"""
    interfering_options: List[InterferingOption]
    high_frequency_words: Dict[str, int]
    option_distribution: Dict[str, int]
    answer_patterns: Dict[str, Any]
    solving_techniques: List[str]
    time_management_tips: List[str]


class TechniqueAnalyzer:
    """技巧分析器"""
    
    def __init__(self):
        self.interference_patterns = {
            'partial_correct': r'(?:部分正确|partially.*?correct|some.*?true)',
            'irrelevant': r'(?:无关|irrelevant|unrelated|not.*?mentioned)',
            'opposite': r'(?:相反|opposite|contrary|reverse)',
            'extreme': r'(?:极端|extreme|absolute|always|never)',
            'too_specific': r'(?:过于具体|too.*?specific|overly.*?detailed)',
            'too_general': r'(?:过于笼统|too.*?general|overly.*?broad)'
        }
        
        self.solving_techniques = {
            'reading': [
                '先看问题再读文章',
                '定位关键词在文章中的位置',
                '排除含有绝对词的选项',
                '注意同义替换',
                '关注文章结构信号词'
            ],
            'cloze': [
                '注意上下文逻辑关系',
                '分析语法结构',
                '考虑固定搭配',
                '注意词汇复现',
                '排除语法错误选项'
            ],
            'translation': [
                '理解句子主干结构',
                '注意时态和语态',
                '处理长难句拆分',
                '注意中英文表达差异',
                '保持译文通顺自然'
            ],
            'writing': [
                '审清题目要求',
                '构建文章框架',
                '使用恰当的连接词',
                '注意语法准确性',
                '控制字数和时间'
            ]
        }
    
    def analyze_techniques(self, questions: List[Question], 
                          question_analyses: List[QuestionAnalysis],
                          annotations: List[QuestionAnnotation]) -> TechniqueAnalysis:
        """分析解题技巧"""
        # 分析干扰选项
        interfering_options = self._analyze_interfering_options(questions, question_analyses)
        
        # 统计高频词
        high_frequency_words = self._analyze_high_frequency_words(questions, question_analyses)
        
        # 分析选项分布
        option_distribution = self._analyze_option_distribution_patterns(questions)
        
        # 分析答题模式
        answer_patterns = self._analyze_answer_patterns(questions, annotations)
        
        # 生成解题技巧
        solving_techniques = self._generate_solving_techniques(questions, question_analyses)
        
        # 生成时间管理建议
        time_management_tips = self._generate_time_management_tips(questions)
        
        return TechniqueAnalysis(
            interfering_options=interfering_options,
            high_frequency_words=high_frequency_words,
            option_distribution=option_distribution,
            answer_patterns=answer_patterns,
            solving_techniques=solving_techniques,
            time_management_tips=time_management_tips
        )
    
    def _analyze_interfering_options(self, questions: List[Question], 
                                   analyses: List[QuestionAnalysis]) -> List[InterferingOption]:
        """分析干扰选项"""
        interfering_options = []
        
        for question, analysis in zip(questions, analyses):
            if not question.options:
                continue
            
            for i, option in enumerate(question.options):
                option_letter = chr(65 + i)
                
                # 检测各种干扰模式
                for interference_type, pattern in self.interference_patterns.items():
                    if re.search(pattern, option, re.IGNORECASE):
                        interfering_option = InterferingOption(
                            position=option_letter,
                            content=option,
                            interference_type=interference_type,
                            detection_method=f"正则匹配: {pattern}",
                            confidence=self._calculate_interference_confidence(option, interference_type)
                        )
                        interfering_options.append(interfering_option)
        
        return interfering_options
    
    def _analyze_high_frequency_words(self, questions: List[Question], 
                                    analyses: List[QuestionAnalysis]) -> Dict[str, int]:
        """分析高频词汇"""
        all_words = []
        
        # 收集题目中的词汇
        for question in questions:
            words = self._extract_words(question.question_text)
            all_words.extend(words)
            
            if question.passage:
                passage_words = self._extract_words(question.passage)
                all_words.extend(passage_words)
            
            for option in question.options or []:
                option_words = self._extract_words(option)
                all_words.extend(option_words)
        
        # 收集分析结果中的关键词
        for analysis in analyses:
            all_words.extend(analysis.keywords)
        
        # 统计词频
        word_counter = Counter(all_words)
        
        # 过滤掉常见停用词
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 
            'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 
            'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 
            'might', 'can', 'this', 'that', 'these', 'those', 'i', 'you', 'he', 
            'she', 'it', 'we', 'they', 'what', 'which', 'who', 'when', 'where', 
            'why', 'how', 'not', 'no', 'yes'
        }
        
        filtered_words = {word: count for word, count in word_counter.items() 
                         if word not in stop_words and len(word) > 2}
        
        # 返回前30个高频词
        return dict(Counter(filtered_words).most_common(30))
    
    def _analyze_option_distribution_patterns(self, questions: List[Question]) -> Dict[str, int]:
        """分析选项分布模式"""
        option_counts = Counter()
        
        for question in questions:
            if question.correct_answer and question.correct_answer.upper() in 'ABCD':
                option_counts[question.correct_answer.upper()] += 1
        
        # 如果没有正确答案信息，分析选项位置的特征
        if not option_counts:
            for question in questions:
                if question.options:
                    # 分析哪个位置的选项最长（可能是正确答案的特征）
                    lengths = [(len(opt), i) for i, opt in enumerate(question.options)]
                    max_length_pos = max(lengths)[1]
                    option_counts[chr(65 + max_length_pos)] += 1
        
        return dict(option_counts)
    
    def _analyze_answer_patterns(self, questions: List[Question], 
                               annotations: List[QuestionAnnotation]) -> Dict[str, Any]:
        """分析答题模式"""
        patterns = {
            'difficulty_vs_position': {},
            'option_length_patterns': {},
            'question_type_patterns': defaultdict(list)
        }
        
        # 分析难度和选项位置的关系
        for annotation in annotations:
            difficulty = annotation.difficulty_score
            # 这里可以分析不同难度题目的选项位置特征
            patterns['difficulty_vs_position'][difficulty] = patterns['difficulty_vs_position'].get(difficulty, 0) + 1
        
        # 分析选项长度模式
        for question in questions:
            if question.options:
                lengths = [len(opt) for opt in question.options]
                patterns['option_length_patterns'][question.id] = {
                    'lengths': lengths,
                    'max_position': chr(65 + lengths.index(max(lengths))),
                    'min_position': chr(65 + lengths.index(min(lengths))),
                    'average_length': np.mean(lengths)
                }
        
        # 按题型分析模式
        for question in questions:
            patterns['question_type_patterns'][question.type].append({
                'option_count': len(question.options or []),
                'question_length': len(question.question_text),
                'has_passage': bool(question.passage)
            })
        
        return dict(patterns)
    
    def _generate_solving_techniques(self, questions: List[Question], 
                                   analyses: List[QuestionAnalysis]) -> List[str]:
        """生成解题技巧"""
        techniques = []
        
        # 统计题型分布
        type_counter = Counter(q.type for q in questions)
        
        # 为每种题型生成相应技巧
        for q_type, count in type_counter.items():
            if q_type in self.solving_techniques:
                techniques.append(f"\n## {self._get_chinese_type_name(q_type)}解题技巧 ({count}题):")
                techniques.extend(self.solving_techniques[q_type])
        
        # 添加通用技巧
        techniques.append("\n## 通用解题技巧:")
        techniques.extend([
            "合理分配答题时间",
            "先易后难，确保基础分",
            "仔细审题，避免理解偏差",
            "保持答题卡填涂准确",
            "留出检查时间"
        ])
        
        return techniques
    
    def _generate_time_management_tips(self, questions: List[Question]) -> List[str]:
        """生成时间管理建议"""
        total_questions = len(questions)
        type_counter = Counter(q.type for q in questions)
        
        tips = []
        
        # 基于题目数量给出时间分配建议
        if total_questions > 0:
            tips.append(f"总题数: {total_questions}题")
            
            for q_type, count in type_counter.items():
                chinese_name = self._get_chinese_type_name(q_type)
                
                if q_type == 'reading':
                    suggested_time = count * 15  # 阅读理解每题约15分钟
                    tips.append(f"{chinese_name}: {count}题，建议用时{suggested_time}分钟")
                elif q_type == 'cloze':
                    suggested_time = count * 3   # 完形填空每题约3分钟
                    tips.append(f"{chinese_name}: {count}题，建议用时{suggested_time}分钟")
                elif q_type == 'translation':
                    suggested_time = count * 10  # 翻译每题约10分钟
                    tips.append(f"{chinese_name}: {count}题，建议用时{suggested_time}分钟")
                elif q_type == 'writing':
                    suggested_time = count * 30  # 写作每题约30分钟
                    tips.append(f"{chinese_name}: {count}题，建议用时{suggested_time}分钟")
        
        tips.extend([
            "\n时间管理策略:",
            "开考前5分钟预览试卷",
            "每10分钟检查一次进度",
            "遇到难题先标记，继续做后面的题目",
            "留出最后10分钟检查和填涂答题卡"
        ])
        
        return tips
    
    def _extract_words(self, text: str) -> List[str]:
        """提取文本中的单词"""
        # 提取英文字母组成的单词
        words = re.findall(r'\b[a-zA-Z]+\b', text.lower())
        return words
    
    def _calculate_interference_confidence(self, option: str, interference_type: str) -> float:
        """计算干扰选项的置信度"""
        confidence = 0.5  # 基础置信度
        
        # 根据干扰类型调整置信度
        if interference_type == 'extreme':
            confidence += 0.3
        elif interference_type == 'opposite':
            confidence += 0.4
        elif interference_type == 'partial_correct':
            confidence += 0.2
        
        # 根据选项长度调整置信度
        if len(option) > 50:
            confidence += 0.1
        
        return min(confidence, 1.0)
    
    def _get_chinese_type_name(self, q_type: str) -> str:
        """获取题型的中文名称"""
        type_mapping = {
            'reading': '阅读理解',
            'cloze': '完形填空',
            'translation': '翻译',
            'writing': '写作'
        }
        return type_mapping.get(q_type, q_type)
    
    def analyze_interfering_patterns(self, interfering_options: List[InterferingOption]) -> Dict[str, Any]:
        """分析干扰选项模式"""
        if not interfering_options:
            return {}
        
        analysis = {
            'total_interfering_options': len(interfering_options),
            'interference_types': Counter(),
            'position_distribution': Counter(),
            'average_confidence': 0.0,
            'high_confidence_options': []
        }
        
        total_confidence = 0.0
        
        for option in interfering_options:
            # 统计干扰类型
            analysis['interference_types'][option.interference_type] += 1
            
            # 统计位置分布
            analysis['position_distribution'][option.position] += 1
            
            # 累计置信度
            total_confidence += option.confidence
            
            # 收集高置信度选项
            if option.confidence >= 0.7:
                analysis['high_confidence_options'].append(option)
        
        analysis['average_confidence'] = total_confidence / len(interfering_options)
        
        return analysis
    
    def generate_option_elimination_guide(self, interfering_options: List[InterferingOption]) -> List[str]:
        """生成选项排除指南"""
        guide = []
        
        # 统计常见干扰类型
        interference_types = Counter(opt.interference_type for opt in interfering_options)
        
        guide.append("## 选项排除技巧:")
        
        for interference_type, count in interference_types.most_common():
            type_guide = self._get_interference_type_guide(interference_type)
            if type_guide:
                guide.append(f"### {self._get_chinese_interference_name(interference_type)} (出现{count}次):")
                guide.extend(type_guide)
        
        return guide
    
    def _get_interference_type_guide(self, interference_type: str) -> List[str]:
        """获取特定干扰类型的排除指南"""
        guides = {
            'extreme': [
                "警惕含有'always', 'never', 'all', 'only'等绝对词的选项",
                "绝对化表达通常不符合实际情况",
                "考虑是否有例外情况"
            ],
            'partial_correct': [
                "注意部分正确的选项",
                "确保选项完全符合题目要求",
                "检查是否有遗漏或错误信息"
            ],
            'opposite': [
                "识别与原文意思相反的选项",
                "注意否定词和反义词",
                "确认逻辑关系是否正确"
            ],
            'irrelevant': [
                "排除与题目无关的选项",
                "检查选项是否回答了所问问题",
                "注意偷换概念的情况"
            ],
            'too_specific': [
                "警惕过于具体的选项",
                "检查是否超出题目范围",
                "考虑是否缺乏普遍性"
            ],
            'too_general': [
                "避免过于笼统的选项",
                "检查是否缺乏具体内容",
                "确保选项有足够的信息量"
            ]
        }
        
        return guides.get(interference_type, [])
    
    def _get_chinese_interference_name(self, interference_type: str) -> str:
        """获取干扰类型的中文名称"""
        name_mapping = {
            'extreme': '绝对化干扰',
            'partial_correct': '部分正确干扰',
            'opposite': '相反干扰',
            'irrelevant': '无关干扰',
            'too_specific': '过于具体干扰',
            'too_general': '过于笼统干扰'
        }
        return name_mapping.get(interference_type, interference_type)
