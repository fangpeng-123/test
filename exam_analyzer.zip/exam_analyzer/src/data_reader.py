"""
试卷数据读取模块
"""

import re
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Question:
    """题目数据结构"""
    id: str
    type: str  # 题型：reading, cloze, translation, writing
    passage: Optional[str] = None  # 文章内容
    question_text: str = ""  # 题目文本
    options: List[str] = None  # 选项
    correct_answer: str = ""  # 正确答案
    explanation: str = ""  # 解析
    
    def __post_init__(self):
        if self.options is None:
            self.options = []


@dataclass
class ExamData:
    """试卷数据结构"""
    title: str
    year: int
    questions: List[Question]
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class ExamDataReader:
    """试卷数据读取器"""
    
    def __init__(self):
        self.question_patterns = {
            'reading': r'(?:阅读理解|Reading.*?Comprehension|Part.*?A)',
            'cloze': r'(?:完形填空|Cloze.*?Test|Part.*?B)',
            'translation': r'(?:翻译|Translation|Part.*?C)',
            'writing': r'(?:写作|Writing|Part.*?D)'
        }
    
    def read_markdown_file(self, file_path: str) -> ExamData:
        """读取Markdown格式的试卷文件"""
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return self.parse_exam_content(content)
    
    def parse_exam_content(self, content: str) -> ExamData:
        """解析试卷内容"""
        # 提取试卷标题和年份
        title, year = self._extract_header_info(content)
        
        # 按题型分割内容
        sections = self._split_by_question_type(content)
        
        # 解析每个题型的题目
        questions = []
        for section_type, section_content in sections.items():
            section_questions = self._parse_section_questions(
                section_type, section_content
            )
            questions.extend(section_questions)
        
        return ExamData(
            title=title,
            year=year,
            questions=questions
        )
    
    def _extract_header_info(self, content: str) -> tuple[str, int]:
        """提取试卷标题和年份"""
        lines = content.split('\n')
        title = "考研英语真题"
        year = 2024
        
        for line in lines[:10]:  # 只检查前10行
            year_match = re.search(r'(20\d{2})', line)
            if year_match:
                year = int(year_match.group(1))
            
            if line.strip() and not line.startswith('#'):
                title = line.strip()
                break
        
        return title, year
    
    def _split_by_question_type(self, content: str) -> Dict[str, str]:
        """按题型分割内容"""
        sections = {}
        
        # 使用正则表达式找到各题型的开始位置
        reading_match = re.search(r'# 阅读理解|# Reading.*?Comprehension', content, re.IGNORECASE)
        cloze_match = re.search(r'# 完形填空|# Cloze.*?Test', content, re.IGNORECASE)
        translation_match = re.search(r'# 翻译|# Translation', content, re.IGNORECASE)
        writing_match = re.search(r'# 写作|# Writing', content, re.IGNORECASE)
        
        # 提取阅读理解部分
        if reading_match:
            start_pos = reading_match.start()
            end_pos = len(content)
            
            # 找到下一个题型的开始位置
            if cloze_match and cloze_match.start() > start_pos:
                end_pos = cloze_match.start()
            elif translation_match and translation_match.start() > start_pos:
                end_pos = translation_match.start()
            elif writing_match and writing_match.start() > start_pos:
                end_pos = writing_match.start()
            
            sections['reading'] = content[start_pos:end_pos]
        
        # 提取完形填空部分
        if cloze_match:
            start_pos = cloze_match.start()
            end_pos = len(content)
            
            # 找到下一个题型的开始位置
            if translation_match and translation_match.start() > start_pos:
                end_pos = translation_match.start()
            elif writing_match and writing_match.start() > start_pos:
                end_pos = writing_match.start()
            
            sections['cloze'] = content[start_pos:end_pos]
        
        # 提取翻译部分
        if translation_match:
            start_pos = translation_match.start()
            end_pos = len(content)
            
            # 找到下一个题型的开始位置
            if writing_match and writing_match.start() > start_pos:
                end_pos = writing_match.start()
            
            sections['translation'] = content[start_pos:end_pos]
        
        # 提取写作部分
        if writing_match:
            sections['writing'] = content[writing_match.start():]
        
        return sections
    
    def _parse_section_questions(self, section_type: str, content: str) -> List[Question]:
        """解析特定题型的题目"""
        if section_type == 'reading':
            return self._parse_reading_questions(content)
        elif section_type == 'cloze':
            return self._parse_cloze_questions(content)
        elif section_type == 'translation':
            return self._parse_translation_questions(content)
        elif section_type == 'writing':
            return self._parse_writing_questions(content)
        else:
            return []
    
    def _parse_reading_questions(self, content: str) -> List[Question]:
        """解析阅读理解题目"""
        questions = []
        
        # 按文章分割
        passages = re.split(r'## Passage \d+', content)
        if len(passages) <= 1:
            # 尝试其他分割方式
            passages = re.split(r'(?:Passage|文章|第.*?篇)', content)
            if len(passages) > 1:
                passages = passages[1:]  # 去掉第一个空元素
            else:
                # 如果没有找到Passage标记，尝试直接解析
                passages = [content]
        
        for i, passage_content in enumerate(passages):
            if not passage_content.strip():
                continue
                
            # 提取文章内容
            passage_text = self._extract_passage_text(passage_content)
            
            # 查找所有题目和选项
            # 首先找到所有题目开始位置
            question_starts = []
            for match in re.finditer(r'\n(\d+\.\s*)', passage_content):
                question_starts.append(match.start())
            
            # 如果没有找到题目，尝试其他模式
            if not question_starts:
                for match in re.finditer(r'(\d+\.\s*)', passage_content):
                    question_starts.append(match.start())
            
            # 解析每个题目
            for j, start_pos in enumerate(question_starts):
                # 确定题目结束位置
                if j < len(question_starts) - 1:
                    end_pos = question_starts[j + 1]
                else:
                    end_pos = len(passage_content)
                
                question_content = passage_content[start_pos:end_pos].strip()
                
                # 分离题目文本和选项
                lines = question_content.split('\n')
                question_lines = []
                option_lines = []
                in_options = False
                
                for line in lines:
                    line = line.strip()
                    if not line:
                        continue
                    
                    if re.match(r'^[A-D]\.', line):
                        in_options = True
                        option_lines.append(line)
                    elif in_options:
                        option_lines.append(line)
                    else:
                        question_lines.append(line)
                
                question_text = '\n'.join(question_lines)
                options = option_lines
                
                if question_text and options:
                    question = Question(
                        id=f"reading_{i+1}_{j+1}",
                        type="reading",
                        passage=passage_text.strip(),
                        question_text=question_text,
                        options=options
                    )
                    questions.append(question)
        
        return questions
    
    def _parse_cloze_questions(self, content: str) -> List[Question]:
        """解析完形填空题目"""
        questions = []
        
        # 提取完形填空文章
        passage_match = re.search(r'(?:Directions|说明).*?\n\n(.*?)(?:\n\d+\.|$)', content, re.DOTALL)
        passage_text = passage_match.group(1).strip() if passage_match else ""
        
        # 提取题目
        question_matches = re.findall(r'(\d+\.\s*[A-D]\s*.*?)(?=\n\d+\.|\n\n|$)', content)
        
        for i, q_text in enumerate(question_matches):
            question = Question(
                id=f"cloze_{i+1}",
                type="cloze",
                passage=passage_text,
                question_text=q_text.strip()
            )
            questions.append(question)
        
        return questions
    
    def _parse_translation_questions(self, content: str) -> List[Question]:
        """解析翻译题目"""
        questions = []
        
        # 提取翻译题目
        translation_matches = re.findall(r'(\d+\.\s*.*?)(?=\n\d+\.|\n\n|$)', content, re.DOTALL)
        
        for i, q_text in enumerate(translation_matches):
            question = Question(
                id=f"translation_{i+1}",
                type="translation",
                question_text=q_text.strip()
            )
            questions.append(question)
        
        return questions
    
    def _parse_writing_questions(self, content: str) -> List[Question]:
        """解析写作题目"""
        questions = []
        
        # 提取写作题目
        writing_match = re.search(r'(?:Directions|说明).*?\n\n(.*?)(?=\n\n|$)', content, re.DOTALL)
        
        if writing_match:
            question = Question(
                id="writing_1",
                type="writing",
                question_text=writing_match.group(1).strip()
            )
            questions.append(question)
        
        return questions
    
    def _extract_passage_text(self, content: str) -> str:
        """提取文章文本"""
        # 移除题目部分，只保留文章
        lines = content.split('\n')
        passage_lines = []
        in_passage = True
        
        for line in lines:
            # 如果遇到题目格式，停止收集文章
            if re.match(r'\d+\.', line):
                in_passage = False
            
            if in_passage and line.strip():
                passage_lines.append(line)
        
        return '\n'.join(passage_lines)