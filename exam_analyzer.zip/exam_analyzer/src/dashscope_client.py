"""
阿里云百炼LLM客户端模块
"""

from typing import Dict, List, Any, Optional
import dashscope
from dashscope import Generation
from .config import Config


class DashScopeClient:
    """阿里云百炼LLM客户端"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        初始化客户端
        
        Args:
            api_key: API密钥，如果不提供则从配置中获取
        """
        self.api_key = api_key or Config.get_dashscope_api_key()
        if self.api_key:
            dashscope.api_key = self.api_key
        else:
            raise ValueError("未设置阿里云百炼API密钥")
    
    def generate_text(self, prompt: str, model: str = None, max_tokens: int = 1500) -> str:
        """
        生成文本
        
        Args:
            prompt: 输入提示
            model: 模型名称，默认使用配置中的模型
            max_tokens: 最大token数
            
        Returns:
            生成的文本
        """
        model = model or Config.DEFAULT_MODEL
        
        try:
            response = Generation.call(
                model=model,
                prompt=prompt,
                max_tokens=max_tokens,
                temperature=0.7
            )
            
            if response.status_code == 200:
                return response.output.text
            else:
                raise Exception(f"API调用失败: {response.message}")
                
        except Exception as e:
            print(f"生成文本时出错: {e}")
            return ""
    
    def analyze_question(self, question_text: str, passage: str = None, 
                        options: List[str] = None) -> Dict[str, Any]:
        """
        分析题目
        
        Args:
            question_text: 题目文本
            passage: 文章内容（可选）
            options: 选项列表（可选）
            
        Returns:
            分析结果字典
        """
        prompt = self._build_question_analysis_prompt(question_text, passage, options)
        
        response = self.generate_text(prompt)
        
        # 解析响应（这里简化处理，实际可能需要更复杂的解析）
        return {
            "question_type": self._extract_field(response, "题目类型"),
            "difficulty": self._extract_field(response, "难度"),
            "keywords": self._extract_keywords(response),
            "analysis": response
        }
    
    def extract_keywords(self, text: str, max_keywords: int = 10) -> List[str]:
        """
        提取关键词
        
        Args:
            text: 输入文本
            max_keywords: 最大关键词数量
            
        Returns:
            关键词列表
        """
        prompt = f"""请从以下文本中提取{max_keywords}个最重要的关键词：

文本：{text}

请只返回关键词，每行一个："""
        
        response = self.generate_text(prompt, max_tokens=200)
        
        # 解析关键词
        keywords = []
        for line in response.split('\n'):
            keyword = line.strip().strip('- ').strip()
            if keyword and len(keyword) > 1:
                keywords.append(keyword)
        
        return keywords[:max_keywords]
    
    def classify_text(self, text: str, categories: List[str]) -> str:
        """
        文本分类
        
        Args:
            text: 输入文本
            categories: 分类类别列表
            
        Returns:
            分类结果
        """
        categories_str = "、".join(categories)
        prompt = f"""请将以下文本分类到以下类别之一：{categories_str}

文本：{text}

请只返回最合适的类别名称："""
        
        response = self.generate_text(prompt, max_tokens=100)
        
        # 清理响应
        for category in categories:
            if category in response:
                return category
        
        return response.strip()
    
    def summarize_text(self, text: str, max_length: int = 200) -> str:
        """
        文本摘要
        
        Args:
            text: 输入文本
            max_length: 摘要最大长度
            
        Returns:
            摘要文本
        """
        prompt = f"""请为以下文本生成一个简洁的摘要，长度不超过{max_length}字：

文本：{text}

摘要："""
        
        return self.generate_text(prompt, max_tokens=max_length//2)
    
    def _build_question_analysis_prompt(self, question_text: str, 
                                      passage: str = None, 
                                      options: List[str] = None) -> str:
        """构建题目分析提示"""
        prompt = f"""请分析以下题目：

题目：{question_text}
"""
        
        if passage:
            prompt += f"\n文章：{passage}\n"
        
        if options:
            prompt += "\n选项：\n"
            for i, option in enumerate(options):
                prompt += f"{option}\n"
        
        prompt += """
请从以下几个方面分析这道题目：
1. 题目类型（如：阅读理解、完形填空、翻译、写作等）
2. 子类型（如：细节理解、推理判断、主旨大意等）
3. 难度等级（简单/中等/困难）
4. 关键词（5-10个）
5. 解题要点

请按以下格式回答：
题目类型：[类型]
子类型：[子类型]
难度：[难度等级]
关键词：[关键词1，关键词2，...]
解题要点：[要点说明]
"""
        
        return prompt
    
    def _extract_field(self, text: str, field_name: str) -> str:
        """从响应文本中提取字段"""
        lines = text.split('\n')
        for line in lines:
            if field_name in line:
                if '：' in line:
                    return line.split('：')[1].strip()
                elif ':' in line:
                    return line.split(':')[1].strip()
        return ""
    
    def _extract_keywords(self, text: str) -> List[str]:
        """从响应文本中提取关键词"""
        keywords_line = ""
        lines = text.split('\n')
        for line in lines:
            if "关键词" in line:
                keywords_line = line
                break
        
        if not keywords_line:
            return []
        
        # 提取关键词部分
        if '：' in keywords_line:
            keywords_part = keywords_line.split('：')[1].strip()
        elif ':' in keywords_line:
            keywords_part = keywords_line.split(':')[1].strip()
        else:
            return []
        
        # 分割关键词
        keywords = []
        for keyword in keywords_part.split('，'):
            keyword = keyword.strip().strip('、')
            if keyword:
                keywords.append(keyword)
        
        return keywords
    
    def test_connection(self) -> bool:
        """测试连接"""
        try:
            response = self.generate_text("测试", max_tokens=10)
            return len(response) > 0
        except Exception as e:
            print(f"连接测试失败: {e}")
            return False