"""
MD格式报告生成模块
"""

from typing import Dict, List, Any
from datetime import datetime
import os
from .data_reader import ExamData
from .question_classifier import QuestionAnalysis
from .statistics_analyzer import StatisticsResult, QuestionAnnotation
from .source_tracker import SourceInfo
from .technique_analyzer import TechniqueAnalysis
from .answer_generator import AnswerWithEvidence


class ReportGenerator:
    """报告生成器"""
    
    def __init__(self):
        self.report_template = """
# {title} 分析报告

## 基本信息

- **试卷年份**: {year}
- **分析时间**: {analysis_time}
- **题目总数**: {total_questions}
- **题型分布**: {question_types}

---

## 1. 试卷概览

### 1.1 题型分布统计
{type_distribution}

### 1.2 难度分布
{difficulty_distribution}

### 1.3 总体统计摘要
{summary_statistics}

---

## 2. 文章溯源分析

### 2.1 文章来源统计
{source_statistics}

### 2.2 文章来源详情
{source_details}

---

## 3. 题目分类标注

### 3.1 阅读理解分析
{reading_analysis}

### 3.2 完形填空分析
{cloze_analysis}

### 3.3 翻译题目分析
{translation_analysis}

### 3.4 写作题目分析
{writing_analysis}

---

## 4. 技巧分析与统计

### 4.1 干扰选项分析
{interfering_analysis}

### 4.2 高频词汇统计
{high_frequency_words}

### 4.3 选项分布规律
{option_distribution}

### 4.4 解题技巧总结
{solving_techniques}

### 4.5 时间管理建议
{time_management}

---

## 5. 详细题目标注

{detailed_annotations}

---

## 6. 结论与建议

### 6.1 试卷特点总结
{exam_characteristics}

### 6.2 备考建议
{study_recommendations}

---

*报告生成时间: {generation_time}*
"""
    
    def generate_report(self, exam_data: ExamData,
                       question_analyses: List[QuestionAnalysis],
                       statistics: StatisticsResult,
                       source_infos: List[SourceInfo],
                       technique_analysis: TechniqueAnalysis,
                       output_path: str,
                       answers: List[AnswerWithEvidence] = None) -> str:
        """生成完整的分析报告"""
        
        # 准备报告数据
        report_data = self._prepare_report_data(
            exam_data, question_analyses, statistics, 
            source_infos, technique_analysis, output_path, answers
        )
        
        # 生成报告内容
        report_content = self._generate_report_content(report_data)
        
        # 保存报告
        self._save_report(report_content, output_path)
        
        return report_content
    
    def _prepare_report_data(self, exam_data: ExamData,
                           question_analyses: List[QuestionAnalysis],
                           statistics: StatisticsResult,
                           source_infos: List[SourceInfo],
                           technique_analysis: TechniqueAnalysis,
                           output_path: str,
                           answers: List[AnswerWithEvidence] = None) -> Dict[str, Any]:
        """准备报告数据"""
        
        total_questions = len(exam_data.questions)
        question_types = ", ".join([f"{k}({v}题)" for k, v in statistics.question_type_distribution.items()])
        
        return {
            'title': exam_data.title,
            'year': exam_data.year,
            'analysis_time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'total_questions': total_questions,
            'question_types': question_types,
            
            'type_distribution': self._format_type_distribution(statistics.question_type_distribution),
            'difficulty_distribution': self._format_difficulty_distribution(statistics.difficulty_distribution),
            'summary_statistics': self._format_summary_statistics(statistics),
            
            'source_statistics': self._format_source_statistics(source_infos),
            'source_details': self._format_source_details(source_infos),
            
            'reading_analysis': self._format_reading_analysis(statistics, question_analyses),
            'cloze_analysis': self._format_cloze_analysis(statistics, question_analyses),
            'translation_analysis': self._format_translation_analysis(statistics, question_analyses),
            'writing_analysis': self._format_writing_analysis(statistics, question_analyses),
            
            'interfering_analysis': self._format_interfering_analysis(technique_analysis.interfering_options),
            'high_frequency_words': self._format_high_frequency_words(technique_analysis.high_frequency_words),
            'option_distribution': self._format_option_distribution(technique_analysis.option_distribution),
            'solving_techniques': self._format_solving_techniques(technique_analysis.solving_techniques),
            'time_management': self._format_time_management(technique_analysis.time_management_tips),
            
            'detailed_annotations': self._format_detailed_annotations(statistics.annotations),
            
            'exam_characteristics': self._generate_exam_characteristics(statistics, technique_analysis),
            'study_recommendations': self._generate_study_recommendations(statistics, technique_analysis),
            
            'generation_time': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    
    def _format_type_distribution(self, distribution: Dict[str, int]) -> str:
        """格式化题型分布"""
        if not distribution:
            return "暂无数据"
        
        content = ["| 题型 | 题目数量 | 占比 |"]
        content.append("|------|----------|------|")
        
        total = sum(distribution.values())
        for q_type, count in distribution.items():
            percentage = (count / total) * 100
            content.append(f"| {q_type} | {count} | {percentage:.1f}% |")
        
        return "\n".join(content)
    
    def _format_difficulty_distribution(self, distribution: Dict[str, int]) -> str:
        """格式化难度分布"""
        if not distribution:
            return "暂无数据"
        
        content = ["| 难度等级 | 题目数量 | 占比 |"]
        content.append("|----------|----------|------|")
        
        total = sum(distribution.values())
        for difficulty, count in distribution.items():
            percentage = (count / total) * 100
            difficulty_cn = {'easy': '简单', 'medium': '中等', 'hard': '困难'}.get(difficulty, difficulty)
            content.append(f"| {difficulty_cn} | {count} | {percentage:.1f}% |")
        
        return "\n".join(content)
    
    def _format_summary_statistics(self, statistics: StatisticsResult) -> str:
        """格式化统计摘要"""
        summary = self._generate_summary_statistics(statistics)
        
        content = []
        content.append(f"- **题目总数**: {summary['total_questions']}题")
        content.append(f"- **主要题型**: {', '.join(summary['question_types'])}")
        
        if summary['most_common_type']:
            content.append(f"- **最多题型**: {summary['most_common_type'][0]}({summary['most_common_type'][1]}题)")
        
        content.append(f"- **平均难度**: {summary['average_difficulty']:.2f}")
        
        if summary['top_keywords']:
            content.append(f"- **高频关键词**: {', '.join(summary['top_keywords'][:10])}")
        
        return "\n".join(content)
    
    def _format_source_statistics(self, source_infos: List[SourceInfo]) -> str:
        """格式化来源统计"""
        if not source_infos:
            return "未找到文章来源信息"
        
        # 统计来源类型
        type_counts = {}
        publication_counts = {}
        
        for source in source_infos:
            source_type = source.source_type
            publication = source.publication
            
            type_counts[source_type] = type_counts.get(source_type, 0) + 1
            if publication:
                publication_counts[publication] = publication_counts.get(publication, 0) + 1
        
        content = ["| 来源类型 | 数量 |"]
        content.append("|----------|------|")
        
        for source_type, count in type_counts.items():
            content.append(f"| {source_type} | {count} |")
        
        return "\n".join(content)
    
    def _format_source_details(self, source_infos: List[SourceInfo]) -> str:
        """格式化来源详情"""
        if not source_infos:
            return "未找到详细来源信息"
        
        content = []
        
        for i, source in enumerate(source_infos[:10], 1):  # 最多显示10个
            confidence_pct = source.confidence * 100
            content.append(f"**{i}. {source.title}**")
            content.append(f"- 来源: {source.publication}")
            content.append(f"- 类型: {source.source_type}")
            content.append(f"- 置信度: {confidence_pct:.1f}%")
            if source.url:
                content.append(f"- 链接: {source.url}")
            content.append("")
        
        return "\n".join(content)
    
    def _format_reading_analysis(self, statistics: StatisticsResult, 
                                analyses: List[QuestionAnalysis]) -> str:
        """格式化阅读理解分析"""
        reading_analyses = [a for a in analyses if a.question_type == 'reading']
        
        if not reading_analyses:
            return "无阅读理解题目"
        
        content = [f"**阅读理解题目数量**: {len(reading_analyses)}题"]
        
        # 统计子类型
        subtype_counts = {}
        for analysis in reading_analyses:
            subtype = analysis.sub_type
            subtype_counts[subtype] = subtype_counts.get(subtype, 0) + 1
        
        content.append("\n**题目类型分布**:")
        for subtype, count in subtype_counts.items():
            subtype_cn = self._get_subtype_chinese_name(subtype)
            content.append(f"- {subtype_cn}: {count}题")
        
        return "\n".join(content)
    
    def _format_cloze_analysis(self, statistics: StatisticsResult, 
                              analyses: List[QuestionAnalysis]) -> str:
        """格式化完形填空分析"""
        cloze_analyses = [a for a in analyses if a.question_type == 'cloze']
        
        if not cloze_analyses:
            return "无完形填空题目"
        
        content = [f"**完形填空题目数量**: {len(cloze_analyses)}题"]
        
        # 分析考察重点
        grammar_focus = []
        vocabulary_level = []
        
        for analysis in cloze_analyses:
            if hasattr(analysis, 'grammar_focus'):
                grammar_focus.extend(analysis.grammar_focus)
            if hasattr(analysis, 'vocabulary_level'):
                vocabulary_level.append(analysis.vocabulary_level)
        
        return "\n".join(content)
    
    def _format_translation_analysis(self, statistics: StatisticsResult, 
                                   analyses: List[QuestionAnalysis]) -> str:
        """格式化翻译题目分析"""
        translation_analyses = [a for a in analyses if a.question_type == 'translation']
        
        if not translation_analyses:
            return "无翻译题目"
        
        content = [f"**翻译题目数量**: {len(translation_analyses)}题"]
        
        return "\n".join(content)
    
    def _format_writing_analysis(self, statistics: StatisticsResult, 
                                analyses: List[QuestionAnalysis]) -> str:
        """格式化写作题目分析"""
        writing_analyses = [a for a in analyses if a.question_type == 'writing']
        
        if not writing_analyses:
            return "无写作题目"
        
        content = [f"**写作题目数量**: {len(writing_analyses)}题"]
        
        return "\n".join(content)
    
    def _format_interfering_analysis(self, interfering_options: List) -> str:
        """格式化干扰选项分析"""
        if not interfering_options:
            return "未检测到明显的干扰选项"
        
        content = [f"**检测到干扰选项数量**: {len(interfering_options)}个"]
        
        # 统计干扰类型
        type_counts = {}
        for option in interfering_options:
            interference_type = option.interference_type
            type_counts[interference_type] = type_counts.get(interference_type, 0) + 1
        
        content.append("\n**干扰类型分布**:")
        for interference_type, count in sorted(type_counts.items(), key=lambda x: x[1], reverse=True):
            content.append(f"- {interference_type}: {count}个")
        
        return "\n".join(content)
    
    def _format_high_frequency_words(self, words: Dict[str, int]) -> str:
        """格式化高频词汇"""
        if not words:
            return "无高频词汇数据"
        
        content = ["| 词汇 | 频次 |"]
        content.append("|------|------|")
        
        for word, count in list(words.items())[:20]:  # 显示前20个
            content.append(f"| {word} | {count} |")
        
        return "\n".join(content)
    
    def _format_option_distribution(self, distribution: Dict[str, int]) -> str:
        """格式化选项分布"""
        if not distribution:
            return "无选项分布数据"
        
        content = ["| 选项 | 数量 | 占比 |"]
        content.append("|------|------|------|")
        
        total = sum(distribution.values())
        for option, count in distribution.items():
            percentage = (count / total) * 100
            content.append(f"| {option} | {count} | {percentage:.1f}% |")
        
        return "\n".join(content)
    
    def _format_solving_techniques(self, techniques: List[str]) -> str:
        """格式化解题技巧"""
        return "\n".join(techniques)
    
    def _format_time_management(self, tips: List[str]) -> str:
        """格式化时间管理建议"""
        return "\n".join(tips)
    
    def _format_detailed_annotations(self, annotations: List[QuestionAnnotation]) -> str:
        """格式化详细标注"""
        if not annotations:
            return "无详细标注信息"
        
        content = []
        
        for annotation in annotations[:10]:  # 最多显示10个题目的详细标注
            content.append(f"### 题目 {annotation.question_id}")
            content.append(f"**题型**: {annotation.question_type}")
            content.append(f"**子类型**: {annotation.sub_type}")
            content.append(f"**难度分数**: {annotation.difficulty_score}")
            
            if annotation.passage_location:
                content.append(f"**文章定位**: {annotation.passage_location}")
            
            if annotation.key_sentences:
                content.append("**关键句子**:")
                for sentence in annotation.key_sentences:
                    content.append(f"- {sentence}")
            
            if annotation.option_labels:
                content.append("**选项标注**:")
                for option, label in annotation.option_labels.items():
                    content.append(f"- {option}: {label}")
            
            content.append("")
        
        return "\n".join(content)
    
    def _generate_exam_characteristics(self, statistics: StatisticsResult, 
                                     technique_analysis: TechniqueAnalysis) -> str:
        """生成试卷特点总结"""
        characteristics = []
        
        # 基于题型分布总结特点
        if statistics.question_type_distribution:
            main_type = max(statistics.question_type_distribution.items(), key=lambda x: x[1])
            characteristics.append(f"- 本试卷以{main_type[0]}为主，共{main_type[1]}题")
        
        # 基于难度分布总结特点
        if statistics.difficulty_distribution:
            total = sum(statistics.difficulty_distribution.values())
            hard_ratio = statistics.difficulty_distribution.get('hard', 0) / total
            if hard_ratio > 0.3:
                characteristics.append("- 试卷难度较高，困难题目占比较大")
            elif hard_ratio < 0.1:
                characteristics.append("- 试卷难度相对较低")
            else:
                characteristics.append("- 试卷难度适中")
        
        # 基于干扰选项分析总结特点
        if technique_analysis.interfering_options:
            characteristics.append(f"- 检测到{len(technique_analysis.interfering_options)}个干扰选项")
        
        return "\n".join(characteristics) if characteristics else "- 试卷结构标准，无明显特点"
    
    def _generate_study_recommendations(self, statistics: StatisticsResult, 
                                      technique_analysis: TechniqueAnalysis) -> str:
        """生成备考建议"""
        recommendations = []
        
        # 基于题型分布给出建议
        if statistics.question_type_distribution:
            for q_type, count in statistics.question_type_distribution.items():
                if q_type == '阅读理解' and count > 10:
                    recommendations.append("- 加强阅读理解训练，提高阅读速度和理解能力")
                elif q_type == '完形填空' and count > 15:
                    recommendations.append("- 注重词汇积累和语法知识掌握")
                elif q_type == '翻译':
                    recommendations.append("- 练习中英文互译，提高语言转换能力")
                elif q_type == '写作':
                    recommendations.append("- 多练习写作，熟悉不同文体的写作要求")
        
        # 基于高频词汇给出建议
        if technique_analysis.high_frequency_words:
            recommendations.append(f"- 重点掌握高频词汇: {', '.join(list(technique_analysis.high_frequency_words.keys())[:10])}")
        
        # 基于干扰选项分析给出建议
        if technique_analysis.interfering_options:
            recommendations.append("- 学会识别和排除干扰选项，提高答题准确率")
        
        return "\n".join(recommendations) if recommendations else "- 按计划复习，注重基础知识掌握"
    
    def _get_subtype_chinese_name(self, subtype: str) -> str:
        """获取子类型中文名称"""
        name_mapping = {
            'detail': '细节理解题',
            'inference': '推理判断题',
            'main_idea': '主旨大意题',
            'attitude': '态度观点题',
            'vocabulary': '词义猜测题',
            'structure': '文章结构题'
        }
        return name_mapping.get(subtype, subtype)
    
    def _generate_summary_statistics(self, statistics: StatisticsResult) -> Dict[str, Any]:
        """生成汇总统计"""
        total_questions = sum(statistics.question_type_distribution.values())
        question_types = list(statistics.question_type_distribution.keys())
        
        most_common_type = None
        if statistics.question_type_distribution:
            most_common_type = max(statistics.question_type_distribution.items(), key=lambda x: x[1])
        
        # 计算平均难度
        difficulty_scores = {'easy': 1, 'medium': 2, 'hard': 3}
        total_difficulty = 0
        total_count = 0
        
        for difficulty, count in statistics.difficulty_distribution.items():
            score = difficulty_scores.get(difficulty, 2)
            total_difficulty += score * count
            total_count += count
        
        average_difficulty = total_difficulty / total_count if total_count > 0 else 2.0
        
        return {
            'total_questions': total_questions,
            'question_types': question_types,
            'most_common_type': most_common_type,
            'average_difficulty': average_difficulty,
            'top_keywords': list(statistics.keyword_frequency.keys()) if statistics.keyword_frequency else []
        }
    
    def _generate_report_content(self, report_data: Dict[str, Any]) -> str:
        """生成报告内容"""
        return self.report_template.format(**report_data)
    
    def _save_report(self, content: str, output_path: str) -> None:
        """保存报告到文件"""
        # 确保输出目录存在
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(content)
    
    def generate_summary_report(self, exam_data: ExamData,
                              statistics: StatisticsResult,
                              output_path: str) -> str:
        """生成简要报告"""
        summary_data = {
            'title': exam_data.title,
            'year': exam_data.year,
            'total_questions': len(exam_data.questions),
            'question_types': statistics.question_type_distribution,
            'difficulty_distribution': statistics.difficulty_distribution
        }
        
        content = f"""# {exam_data.title} 简要分析

## 基本信息
- 年份: {exam_data.year}
- 题目总数: {summary_data['total_questions']}

## 题型分布
{self._format_type_distribution(summary_data['question_types'])}

## 难度分布
{self._format_difficulty_distribution(summary_data['difficulty_distribution'])}

---
*生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}*
"""
        
        # 保存简要报告
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return content
    
    def generate_answer_report(self, exam_data: ExamData,
                             answers: List[AnswerWithEvidence],
                             output_path: str) -> str:
        """生成答题报告"""
        content = f"""# {exam_data.title} 答题报告

## 基本信息

- **试卷年份**: {exam_data.year}
- **题目总数**: {len(exam_data.questions)}
- **生成时间**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

---

## 答题结果汇总

"""
        
        # 统计答题结果
        answer_stats = self._generate_answer_statistics(answers)
        content += self._format_answer_statistics(answer_stats)
        
        content += "\n---\n\n## 详细答题解析\n\n"
        
        # 按题目类型分组
        answers_by_type = {}
        for answer in answers:
            q_type = answer.question_type
            if q_type not in answers_by_type:
                answers_by_type[q_type] = []
            answers_by_type[q_type].append(answer)
        
        # 生成各题型的答题解析
        for q_type, type_answers in answers_by_type.items():
            type_name = self._get_question_type_chinese_name(q_type)
            content += f"### {type_name}\n\n"
            
            for answer in type_answers:
                content += self._format_answer_detail(answer)
                content += "\n---\n\n"
        
        # 保存答题报告
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return content
    
    def _generate_answer_statistics(self, answers: List[AnswerWithEvidence]) -> Dict[str, Any]:
        """生成答题统计"""
        stats = {
            'total_questions': len(answers),
            'question_types': {},
            'confidence_distribution': {'high': 0, 'medium': 0, 'low': 0},
            'average_confidence': 0.0,
            'answer_distribution': {'A': 0, 'B': 0, 'C': 0, 'D': 0}
        }
        
        total_confidence = 0.0
        
        for answer in answers:
            # 统计题型分布
            q_type = answer.question_type
            stats['question_types'][q_type] = stats['question_types'].get(q_type, 0) + 1
            
            # 统计置信度分布
            confidence = answer.confidence
            total_confidence += confidence
            
            if confidence >= 0.8:
                stats['confidence_distribution']['high'] += 1
            elif confidence >= 0.6:
                stats['confidence_distribution']['medium'] += 1
            else:
                stats['confidence_distribution']['low'] += 1
            
            # 统计答案分布
            if answer.correct_answer in stats['answer_distribution']:
                stats['answer_distribution'][answer.correct_answer] += 1
        
        stats['average_confidence'] = total_confidence / len(answers) if answers else 0.0
        
        return stats
    
    def _format_answer_statistics(self, stats: Dict[str, Any]) -> str:
        """格式化答题统计"""
        content = []
        
        # 基本统计
        content.append(f"**题目总数**: {stats['total_questions']}题")
        content.append(f"**平均置信度**: {stats['average_confidence']:.2f}")
        
        # 题型分布
        content.append("\n**题型分布**:")
        for q_type, count in stats['question_types'].items():
            type_name = self._get_question_type_chinese_name(q_type)
            content.append(f"- {type_name}: {count}题")
        
        # 置信度分布
        content.append("\n**置信度分布**:")
        content.append(f"- 高置信度(≥0.8): {stats['confidence_distribution']['high']}题")
        content.append(f"- 中等置信度(0.6-0.8): {stats['confidence_distribution']['medium']}题")
        content.append(f"- 低置信度(<0.6): {stats['confidence_distribution']['low']}题")
        
        # 答案分布
        content.append("\n**答案分布**:")
        for answer, count in stats['answer_distribution'].items():
            if stats['total_questions'] > 0:
                content.append(f"- 选项{answer}: {count}题 ({count/stats['total_questions']*100:.1f}%)")
            else:
                content.append(f"- 选项{answer}: {count}题")
        
        return "\n".join(content)
    
    def _format_answer_detail(self, answer: AnswerWithEvidence) -> str:
        """格式化单个答案详情"""
        content = []
        
        content.append(f"#### 题目 {answer.question_id}")
        content.append(f"**题型**: {self._get_question_type_chinese_name(answer.question_type)}")
        content.append(f"**正确答案**: **{answer.correct_answer}**")
        content.append(f"**置信度**: {answer.confidence:.2f}")
        
        # 解题思路
        if answer.reasoning:
            content.append(f"\n**解题思路**:\n{answer.reasoning}")
        
        # 佐证句子
        if answer.evidence_sentences:
            content.append("\n**原文佐证**:")
            for i, sentence in enumerate(answer.evidence_sentences):
                location = answer.evidence_locations[i] if i < len(answer.evidence_locations) else ""
                content.append(f"- {location}: \"{sentence}\"")
        
        # 选项分析
        if answer.option_analysis:
            content.append("\n**选项分析**:")
            for option, analysis in answer.option_analysis.items():
                content.append(f"- **{option}**: {analysis}")
        
        return "\n".join(content)
    
    def _get_question_type_chinese_name(self, q_type: str) -> str:
        """获取题型的中文名称"""
        type_mapping = {
            'reading': '阅读理解',
            'cloze': '完形填空',
            'translation': '翻译',
            'writing': '写作'
        }
        return type_mapping.get(q_type, q_type)