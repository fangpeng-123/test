"""
题目分类和拆解模块
"""

import re
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass
from .data_reader import Question
from .dashscope_client import DashScopeClient
from .config import Config


@dataclass
class QuestionAnalysis:
    """题目分析结果"""
    question_type: str
    sub_type: str  # 子类型
    difficulty: str  # 难度
    keywords: List[str]  # 关键词
    passage_segments: List[str]  # 文章段落
    question_parts: Dict[str, str]  # 题目组成部分
    option_analysis: Dict[str, Any]  # 选项分析


class QuestionClassifier:
    """题目分类器"""
    
    def __init__(self, use_ai: bool = True, api_key: str = None):
        """
        初始化题目分类器
        
        Args:
            use_ai: 是否使用AI增强分析
            api_key: 阿里云百炼API密钥
        """
        self.use_ai = use_ai and Config.validate_config()
        
        if self.use_ai:
            try:
                self.ai_client = DashScopeClient(api_key=api_key)
                print("已启用阿里云百炼AI增强分析")
            except Exception as e:
                print(f"AI客户端初始化失败，使用传统分析方法: {e}")
                self.use_ai = False
                self.ai_client = None
        else:
            self.ai_client = None
        
        self.reading_subtypes = {
            'detail': r'(?:what|which|when|where|who|how.*?many|how.*?much)',
            'inference': r'(?:infer|imply|suggest|conclude|can.*?be.*?inferred)',
            'main_idea': r'(?:main.*?idea|primary.*?purpose|best.*?title|mainly.*?about)',
            'attitude': r'(?:attitude|tone|feeling|opinion)',
            'vocabulary': r'(?:mean|meaning|definition|refer.*?to)',
            'structure': r'(?:organization|structure|function|purpose.*?of.*?paragraph)'
        }
        
        self.difficulty_keywords = {
            'easy': ['simple', 'basic', 'direct', 'obvious'],
            'medium': ['moderate', 'reasonable', 'fairly'],
            'hard': ['complex', 'difficult', 'challenging', 'sophisticated']
        }
    
    def classify_question(self, question: Question) -> QuestionAnalysis:
        """对题目进行分类和拆解"""
        # 如果启用AI，首先尝试AI分析
        if self.use_ai and self.ai_client:
            try:
                ai_analysis = self._ai_analyze_question(question)
                if ai_analysis:
                    return ai_analysis
            except Exception as e:
                print(f"AI分析失败，使用传统方法: {e}")
        
        # 传统分析方法作为后备
        if question.type == 'reading':
            return self._analyze_reading_question(question)
        elif question.type == 'cloze':
            return self._analyze_cloze_question(question)
        elif question.type == 'translation':
            return self._analyze_translation_question(question)
        elif question.type == 'writing':
            return self._analyze_writing_question(question)
        else:
            return self._default_analysis(question)
    
    def _analyze_reading_question(self, question: Question) -> QuestionAnalysis:
        """分析阅读理解题目"""
        # 确定子类型
        sub_type = self._determine_reading_subtype(question.question_text)
        
        # 评估难度
        difficulty = self._assess_difficulty(question)
        
        # 提取关键词
        keywords = self._extract_keywords(question.question_text, question.passage)
        
        # 分割文章段落
        passage_segments = self._split_passage_into_segments(question.passage)
        
        # 拆解题目组成部分
        question_parts = self._decompose_question(question.question_text)
        
        # 分析选项
        option_analysis = self._analyze_options(question.options)
        
        return QuestionAnalysis(
            question_type='reading',
            sub_type=sub_type,
            difficulty=difficulty,
            keywords=keywords,
            passage_segments=passage_segments,
            question_parts=question_parts,
            option_analysis=option_analysis
        )
    
    def _analyze_cloze_question(self, question: Question) -> QuestionAnalysis:
        """分析完形填空题目"""
        sub_type = 'vocabulary_grammar'
        difficulty = self._assess_difficulty(question)
        keywords = self._extract_keywords(question.question_text, question.passage)
        
        # 分析完形填空的上下文
        context_analysis = self._analyze_cloze_context(question)
        
        return QuestionAnalysis(
            question_type='cloze',
            sub_type=sub_type,
            difficulty=difficulty,
            keywords=keywords,
            passage_segments=[question.passage] if question.passage else [],
            question_parts={'context': context_analysis},
            option_analysis={}
        )
    
    def _analyze_translation_question(self, question: Question) -> QuestionAnalysis:
        """分析翻译题目"""
        sub_type = self._determine_translation_subtype(question.question_text)
        difficulty = self._assess_difficulty(question)
        keywords = self._extract_keywords(question.question_text)
        
        # 分析翻译要点
        translation_points = self._analyze_translation_points(question.question_text)
        
        return QuestionAnalysis(
            question_type='translation',
            sub_type=sub_type,
            difficulty=difficulty,
            keywords=keywords,
            passage_segments=[],
            question_parts={'translation_points': translation_points},
            option_analysis={}
        )
    
    def _analyze_writing_question(self, question: Question) -> QuestionAnalysis:
        """分析写作题目"""
        sub_type = self._determine_writing_subtype(question.question_text)
        difficulty = self._assess_difficulty(question)
        keywords = self._extract_keywords(question.question_text)
        
        # 分析写作要求
        writing_requirements = self._analyze_writing_requirements(question.question_text)
        
        return QuestionAnalysis(
            question_type='writing',
            sub_type=sub_type,
            difficulty=difficulty,
            keywords=keywords,
            passage_segments=[],
            question_parts={'requirements': writing_requirements},
            option_analysis={}
        )
    
    def _determine_reading_subtype(self, question_text: str) -> str:
        """确定阅读理解题目的子类型"""
        question_lower = question_text.lower()
        
        for subtype, pattern in self.reading_subtypes.items():
            if re.search(pattern, question_lower):
                return subtype
        
        return 'general'
    
    def _assess_difficulty(self, question: Question) -> str:
        """评估题目难度"""
        text = (question.question_text + ' ' + 
                ' '.join(question.options) + ' ' + 
                (question.passage or '')).lower()
        
        # 基于关键词判断难度
        for difficulty, keywords in self.difficulty_keywords.items():
            for keyword in keywords:
                if keyword in text:
                    return difficulty
        
        # 基于文本长度判断
        if len(question.question_text) > 200:
            return 'hard'
        elif len(question.question_text) > 100:
            return 'medium'
        else:
            return 'easy'
    
    def _extract_keywords(self, question_text: str, passage: str = "") -> List[str]:
        """提取关键词"""
        # 移除标点符号并转为小写
        text = re.sub(r'[^\w\s]', ' ', question_text.lower())
        words = text.split()
        
        # 过滤停用词
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 
                     'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 
                     'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 
                     'would', 'could', 'should', 'may', 'might', 'can', 'this', 
                     'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 
                     'we', 'they', 'what', 'which', 'who', 'when', 'where', 'why', 'how'}
        
        keywords = [word for word in words if word not in stop_words and len(word) > 2]
        
        # 如果有文章内容，也在文章中查找相关词汇
        if passage:
            passage_lower = passage.lower()
            related_keywords = []
            for keyword in keywords:
                if keyword in passage_lower:
                    related_keywords.append(keyword)
            if related_keywords:
                keywords = related_keywords
        
        return keywords[:10]  # 返回前10个关键词
    
    def _split_passage_into_segments(self, passage: str) -> List[str]:
        """将文章分割为段落"""
        if not passage:
            return []
        
        # 按段落分割
        paragraphs = re.split(r'\n\s*\n', passage.strip())
        
        # 过滤空段落
        segments = [p.strip() for p in paragraphs if p.strip()]
        
        return segments
    
    def _decompose_question(self, question_text: str) -> Dict[str, str]:
        """拆解题目组成部分"""
        parts = {}
        
        # 提取问题类型词
        question_words = re.findall(r'\b(what|which|when|where|who|why|how)\b', question_text, re.IGNORECASE)
        if question_words:
            parts['question_word'] = question_words[0].lower()
        
        # 提取核心问题
        core_match = re.search(r'\?\s*(.*)', question_text)
        if core_match:
            parts['core_question'] = core_match.group(1).strip()
        
        # 提取限制条件
        condition_match = re.search(r'(?:according to|based on|as mentioned in)\s+(.*?)[\?.]', question_text, re.IGNORECASE)
        if condition_match:
            parts['condition'] = condition_match.group(1).strip()
        
        return parts
    
    def _analyze_options(self, options: List[str]) -> Dict[str, Any]:
        """分析选项"""
        analysis = {
            'total_count': len(options),
            'lengths': [len(opt) for opt in options],
            'patterns': {}
        }
        
        # 分析选项模式
        for i, option in enumerate(options):
            opt_lower = option.lower()
            
            # 检查是否包含否定词
            if any(word in opt_lower for word in ['not', 'never', 'no', 'none']):
                analysis['patterns'][f'option_{chr(65+i)}_negative'] = True
            
            # 检查是否包含绝对词
            if any(word in opt_lower for word in ['always', 'never', 'all', 'only', 'must']):
                analysis['patterns'][f'option_{chr(65+i)}_absolute'] = True
            
            # 检查是否包含比较级
            if re.search(r'\b(more|less|better|worse|greater|smaller)\b', opt_lower):
                analysis['patterns'][f'option_{chr(65+i)}_comparative'] = True
        
        return analysis
    
    def _analyze_cloze_context(self, question: Question) -> Dict[str, Any]:
        """分析完形填空的上下文"""
        context = {
            'sentence_type': 'unknown',
            'grammar_focus': [],
            'vocabulary_level': 'medium'
        }
        
        if question.passage:
            # 分析句子类型
            if '?' in question.passage:
                context['sentence_type'] = 'question'
            elif '!' in question.passage:
                context['sentence_type'] = 'exclamation'
            else:
                context['sentence_type'] = 'statement'
        
        return context
    
    def _determine_translation_subtype(self, question_text: str) -> str:
        """确定翻译题目的子类型"""
        if 'sentence' in question_text.lower():
            return 'sentence_translation'
        elif 'paragraph' in question_text.lower():
            return 'paragraph_translation'
        else:
            return 'general_translation'
    
    def _analyze_translation_points(self, question_text: str) -> List[str]:
        """分析翻译要点"""
        points = []
        
        # 查找需要特别注意的语法结构
        if re.search(r'(?:if.*?then|unless|provided that)', question_text, re.IGNORECASE):
            points.append('条件句')
        
        if re.search(r'(?:although|though|while|whereas)', question_text, re.IGNORECASE):
            points.append('让步状语从句')
        
        if re.search(r'(?:because|since|as.*?reason)', question_text, re.IGNORECASE):
            points.append('原因状语从句')
        
        return points
    
    def _determine_writing_subtype(self, question_text: str) -> str:
        """确定写作题目的子类型"""
        text_lower = question_text.lower()
        
        if 'essay' in text_lower:
            return 'essay'
        elif 'letter' in text_lower:
            return 'letter'
        elif 'email' in text_lower:
            return 'email'
        elif 'report' in text_lower:
            return 'report'
        else:
            return 'general_writing'
    
    def _analyze_writing_requirements(self, question_text: str) -> Dict[str, Any]:
        """分析写作要求"""
        requirements = {
            'word_count': None,
            'format': None,
            'key_points': [],
            'tone': None
        }
        
        # 提取字数要求
        word_count_match = re.search(r'(\d+)\s*words?', question_text, re.IGNORECASE)
        if word_count_match:
            requirements['word_count'] = int(word_count_match.group(1))
        
        # 提取格式要求
        if 'letter' in question_text.lower():
            requirements['format'] = 'letter'
        elif 'email' in question_text.lower():
            requirements['format'] = 'email'
        
        # 提取语气要求
        if re.search(r'(?:formal|official)', question_text, re.IGNORECASE):
            requirements['tone'] = 'formal'
        elif re.search(r'(?:informal|casual)', question_text, re.IGNORECASE):
            requirements['tone'] = 'informal'
        
        return requirements
    
    def _default_analysis(self, question: Question) -> QuestionAnalysis:
        """默认分析"""
        return QuestionAnalysis(
            question_type=question.type,
            sub_type='unknown',
            difficulty='medium',
            keywords=self._extract_keywords(question.question_text),
            passage_segments=[],
            question_parts={},
            option_analysis={}
        )
    
    def _ai_analyze_question(self, question: Question) -> QuestionAnalysis:
        """使用AI分析题目"""
        if not self.ai_client:
            return None
        
        # 构建分析内容
        analysis_content = question.question_text
        if question.passage:
            analysis_content += f"\n\n文章：{question.passage}"
        if question.options:
            analysis_content += f"\n\n选项：\n" + "\n".join(question.options)
        
        # 使用AI分析
        ai_result = self.ai_client.analyze_question(
            question.question_text,
            question.passage,
            question.options
        )
        
        # 解析AI结果
        question_type = self._map_ai_type_to_standard(ai_result.get("question_type", question.type))
        sub_type = ai_result.get("sub_type", "unknown")
        difficulty = self._map_ai_difficulty_to_standard(ai_result.get("difficulty", "medium"))
        keywords = ai_result.get("keywords", [])
        
        # 如果AI没有提供关键词，使用传统方法提取
        if not keywords:
            keywords = self._extract_keywords(question.question_text, question.passage)
        
        # 分割文章段落
        passage_segments = self._split_passage_into_segments(question.passage) if question.passage else []
        
        # 拆解题目组成部分
        question_parts = self._decompose_question(question.question_text)
        
        # 分析选项
        option_analysis = self._analyze_options(question.options) if question.options else {}
        
        return QuestionAnalysis(
            question_type=question_type,
            sub_type=sub_type,
            difficulty=difficulty,
            keywords=keywords,
            passage_segments=passage_segments,
            question_parts=question_parts,
            option_analysis=option_analysis
        )
    
    def _map_ai_type_to_standard(self, ai_type: str) -> str:
        """将AI返回的题目类型映射到标准类型"""
        type_mapping = {
            "阅读理解": "reading",
            "完形填空": "cloze",
            "翻译": "translation",
            "写作": "writing",
            "reading": "reading",
            "cloze": "cloze",
            "translation": "translation",
            "writing": "writing"
        }
        return type_mapping.get(ai_type, ai_type)
    
    def _map_ai_difficulty_to_standard(self, ai_difficulty: str) -> str:
        """将AI返回的难度映射到标准难度"""
        difficulty_mapping = {
            "简单": "easy",
            "中等": "medium",
            "困难": "hard",
            "easy": "easy",
            "medium": "medium",
            "hard": "hard"
        }
        return difficulty_mapping.get(ai_difficulty, "medium")