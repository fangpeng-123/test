2024年考研英语真题

# 阅读理解

## Passage 1

The grammar school boy from Stratford-upon-Avon has landed a scholarly punch after groundbreaking research showed that Shakespeare does benefit children's literacy and emotional development. But only if you act him out.

A study found that a "rehearsal room" approach to teaching Shakespeare broadened children's vocabulary and the complexity of their writing as well as their emotional literacy. "The research shows that the way actors work makes a big difference to the way children use language and also how they think about themselves," Jacqui O'Hanlon of the Royal Shakespeare Company (RSC), which commissioned the study, said.

The randomised control trial involved hundreds of year 5 pupils — aged nine and ten — at 45 state primary schools that had not been "previously exposed to RSC pedagogy." They were split into target and control groups and asked to write, for example, a message in a bottle as Ferdinand following the shipwreck in The Tempest. The target group were given a 30-minute drama-based activity to accompany the passage.

The peer-reviewed results showed that the target group of pupils drew on a wider vocabulary, used words "classed as more sophisticated or rarer", and wrote at greater length. They also "appear to be more comfortable writing in role...while [control] pupils imagine how they would react to being shipwrecked, [target] children put themselves in the shoes of a literary character and express that character's emotion". The Time to Act study, which is published by the RSC this week, also found that while control pupils relied on "desert island clichés" such as palm trees, target pupils were "more expansive [giving] a broader picture of the sky, the sea and the atmospheric conditions".

O'Hanlon said she had been most surprised by the "emotional literacy that was evident in the [target] children's writing" and that they were "more resilient in their writing, more hopeful". She added "The emotional understanding was very evident and it is probably related to the [rehearsal room process] where you are used to trying to imagine your way through. They were comfortable in describing different emotional states and part of what you do in drama is put yourself in different shoes." The study showed the importance of embedding arts in education, she said.

But could the results be replicated with any old dramatist? O'Hanlon said more research would be needed but suggested that Shakespeare's use of 20,000 words, compared with the everyday 2,000 words, gave a "massive expansion of language into children's lives", which was combined with children "using their whole bodies to bring words to life".

21. The "rehearsal room" approach requires pupils to ____
A. rewrite the lines from Shakespeare.
B. watch RSC actors' performances.
C. play the roles in Shakespeare.
D. study drama under RSC artists.

22. The study divided the pupils into two groups to find whether ____
A. the change in instruction enhances learning outcomes.
B. expanding vocabulary helps develop reading fluency.
C. emotion affects understanding of sophisticated works.
D. the classroom activity stimulates interest in the arts.

23. Control pupils' reliance on "desert island clichés" shows their ____
A. weakness in description.
B. omission of small details.
C. casual style of writing.
D. preference for big words.

24. What can promote children's emotional literacy according to O'Hanlon?
A. Writing in an imaginative manner.
B. Identifying with literary characters.
C. Drawing inspiration from nature.
D. Concentrating on real-life situations.

25. It can be inferred from the last paragraph that ____
A. the new teaching method may work best with Shakespeare.
B. the language of Shakespeare may be formidable for pupils.
C. other old dramatists may be included in primary education.
D. pupils may be reluctant to work on other old dramatists.