# 考研英语试卷分析智能体使用指南

## 项目概述

本项目是一个基于LangChain框架开发的考研英语真题分析工具，能够对试卷进行全面分析并生成详细的MD格式报告。

## 功能特性

1. **试卷数据读取和解析** - 支持Markdown格式的考研英语真题
2. **题目分类和拆解** - 自动识别题型并进行结构化分析
3. **文章溯源分析** - 通过网络搜索追踪文章来源（需要API密钥）
4. **题型分类标注统计** - 详细统计各类题型的分布和特征
5. **技巧分析和统计** - 分析干扰选项、高频词汇和解题技巧
6. **MD文档生成** - 生成完整的分析报告和简要摘要

## 安装和配置

### 1. 安装依赖

```bash
cd /media/yls/1T硬盘4/code/Agent/LangChain/exam_analyzer
pip install -r requirements.txt
```

### 2. 配置搜索API（可选）

如果需要使用文章溯源功能，需要配置搜索API密钥：

```bash
export SEARCH_API_KEY="your_api_key_here"
```

支持的搜索引擎：
- Google Custom Search API
- Bing Search API
- DuckDuckGo（免费，无需API密钥）

## 使用方法

### 1. 基本用法

```bash
# 分析单个试卷文件
python main.py data/sample_exam.md

# 指定输出目录
python main.py data/sample_exam.md --output my_reports

# 禁用文章溯源（加快分析速度）
python main.py data/sample_exam.md --no-source

# 批量分析多个文件
python main.py --batch file1.md file2.md file3.md
```

### 2. 编程接口使用

```python
from src.exam_analyzer import ExamAnalyzer

# 初始化分析器
analyzer = ExamAnalyzer(api_key="your_api_key")

# 分析试卷
report_path = analyzer.analyze_exam(
    "data/sample_exam.md",
    enable_source_tracking=True,
    output_dir="output"
)

# 分析单个题目
analysis = analyzer.analyze_single_question(
    question_text="What is the main topic?",
    passage="The passage discusses education technology...",
    options=["A. Option 1", "B. Option 2", "C. Option 3", "D. Option 4"]
)

# 获取分析摘要
summary = analyzer.get_analysis_summary("data/sample_exam.md")
```

### 3. 运行示例

```bash
# 运行完整示例
python example_usage.py
```

## 试卷文件格式

试卷文件应为Markdown格式，包含以下结构：

```markdown
# 年份 + 考研英语真题

## 阅读理解

### Passage 1

文章内容...

1. 题目文本？
A. 选项A
B. 选项B
C. 选项C
D. 选项D

### Passage 2

更多文章内容...

## 完形填空

Directions: 说明文字...

文章内容，有(1)_____这样的空白。

1. A. 选项A
B. 选项B
C. 选项C
D. 选项D

## 翻译

Translate the following sentences...

1. 要翻译的句子1
2. 要翻译的句子2

## 写作

Directions: 写作说明...

写作题目和要求...
```

## 输出报告说明

分析完成后，会在指定输出目录生成两个文件：

1. **完整报告** (`{年份}_考研英语分析报告.md`)
   - 包含所有分析内容的详细报告
   - 适合深入研究和备课使用

2. **简要报告** (`{年份}_考研英语简要分析.md`)
   - 包含关键统计信息的摘要
   - 适合快速了解试卷特点

## 报告内容结构

完整报告包含以下部分：

1. **试卷概览**
   - 题型分布统计
   - 难度分布
   - 总体统计摘要

2. **文章溯源分析**
   - 文章来源统计
   - 来源详情和置信度

3. **题目分类标注**
   - 阅读理解分析
   - 完形填空分析
   - 翻译题目分析
   - 写作题目分析

4. **技巧分析与统计**
   - 干扰选项分析
   - 高频词汇统计
   - 选项分布规律
   - 解题技巧总结
   - 时间管理建议

5. **详细题目标注**
   - 每道题目的详细分析
   - 文章定位信息
   - 选项特征标注

6. **结论与建议**
   - 试卷特点总结
   - 备考建议

## 高级功能

### 1. 自定义分析器

```python
from src.data_reader import ExamDataReader
from src.question_classifier import QuestionClassifier

# 创建自定义数据读取器
reader = ExamDataReader()
exam_data = reader.read_markdown_file("your_file.md")

# 创建自定义分类器
classifier = QuestionClassifier()
for question in exam_data.questions:
    analysis = classifier.classify_question(question)
    # 自定义处理逻辑
```

### 2. 批量处理

```python
# 批量分析多个年份的试卷
import glob

analyzer = ExamAnalyzer()
exam_files = glob.glob("data/*.md")

report_paths = analyzer.batch_analyze(exam_files, output_dir="batch_results")
print(f"生成了{len(report_paths)}份报告")
```

### 3. 集成到其他应用

```python
# 作为模块集成到其他LangChain应用中
from src.exam_analyzer import ExamAnalyzer

class YourLangChainApp:
    def __init__(self):
        self.exam_analyzer = ExamAnalyzer()
    
    def process_exam_query(self, exam_file, query):
        # 获取试卷摘要
        summary = self.exam_analyzer.get_analysis_summary(exam_file)
        
        # 基于分析结果回答用户问题
        # 你的自定义逻辑
        return response
```

## 故障排除

### 1. 常见问题

**问题**: 无法解析试卷文件
- 检查文件格式是否为Markdown
- 确认文件编码为UTF-8
- 检查题型标题是否符合格式要求

**问题**: 文章溯源失败
- 检查网络连接
- 确认API密钥配置正确
- 尝试使用`--no-source`选项禁用溯源

**问题**: 依赖包安装失败
- 使用虚拟环境
- 更新pip版本
- 检查Python版本兼容性

### 2. 调试模式

```python
# 启用详细日志
import logging
logging.basicConfig(level=logging.DEBUG)

# 分析时显示进度
analyzer = ExamAnalyzer()
analyzer.analyze_exam("data/sample_exam.md", enable_source_tracking=False)
```

## 扩展开发

### 1. 添加新的题型支持

在`src/question_classifier.py`中扩展：

```python
def _parse_new_question_type(self, content: str) -> List[Question]:
    # 实现新题型的解析逻辑
    pass
```

### 2. 自定义报告格式

在`src/report_generator.py`中修改模板：

```python
def _generate_custom_report(self, report_data: Dict[str, Any]) -> str:
    # 自定义报告生成逻辑
    pass
```

### 3. 添加新的分析功能

创建新的分析器模块：

```python
class CustomAnalyzer:
    def analyze(self, questions: List[Question]) -> Dict[str, Any]:
        # 实现自定义分析逻辑
        pass
```

## 性能优化建议

1. **大型试卷处理**: 对于包含大量题目的试卷，建议禁用文章溯源功能
2. **批量处理**: 使用批量分析接口处理多个文件
3. **缓存结果**: 对于重复分析，可以缓存中间结果
4. **并行处理**: 对于大量文件，可以考虑并行分析

## 许可证

本项目采用MIT许可证，详见LICENSE文件。

## 联系方式

如有问题或建议，请通过以下方式联系：
- 提交Issue到项目仓库
- 发送邮件至开发团队

---

*最后更新: 2025年10月30日*