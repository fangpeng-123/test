#!/usr/bin/env python3
"""
使用示例脚本
"""

import os
import sys

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.exam_analyzer import ExamAnalyzer


def example_single_analysis():
    """示例：分析单个试卷"""
    print("=== 单个试卷分析示例 ===")
    
    # 初始化分析器（使用AI增强分析）
    # 注意：需要先设置环境变量 DASHSCOPE_API_KEY 或传入API密钥
    analyzer = ExamAnalyzer(use_ai=True)
    
    # 分析示例试卷
    sample_file = "data/sample_exam.md"
    output_dir = "output"
    
    if os.path.exists(sample_file):
        report_path = analyzer.analyze_exam(
            sample_file,
            enable_source_tracking=False,  # 示例中禁用网络溯源
            output_dir=output_dir
        )
        print(f"分析完成，报告保存在: {report_path}")
    else:
        print(f"示例文件不存在: {sample_file}")


def example_single_question():
    """示例：分析单个题目"""
    print("\n=== 单个题目分析示例 ===")
    
    analyzer = ExamAnalyzer()
    
    # 分析一个阅读理解题目
    question_text = "What is the main benefit of artificial intelligence in healthcare?"
    passage = "Artificial intelligence has revolutionized healthcare by providing accurate diagnoses and personalized treatment recommendations."
    options = [
        "A. Reduced costs for patients",
        "B. Improved diagnostic accuracy and personalized treatment",
        "C. Fewer doctors needed in hospitals",
        "D. Simplified medical procedures"
    ]
    
    analysis = analyzer.analyze_single_question(question_text, passage, options)
    
    print(f"题目类型: {analysis.question_type}")
    print(f"子类型: {analysis.sub_type}")
    print(f"难度: {analysis.difficulty}")
    print(f"关键词: {', '.join(analysis.keywords[:5])}")


def example_summary():
    """示例：获取分析摘要"""
    print("\n=== 分析摘要示例 ===")
    
    analyzer = ExamAnalyzer()
    sample_file = "data/sample_exam.md"
    
    if os.path.exists(sample_file):
        summary = analyzer.get_analysis_summary(sample_file)
        
        print(f"试卷标题: {summary['exam_info']['title']}")
        print(f"年份: {summary['exam_info']['year']}")
        print(f"题目总数: {summary['exam_info']['total_questions']}")
        print(f"平均难度: {summary['statistics']['average_difficulty']:.2f}")
        print("题型分布:")
        for q_type, count in summary['question_types'].items():
            print(f"  {q_type}: {count}题")


def example_ai_config():
    """示例：AI配置和连接测试"""
    print("\n=== AI配置示例 ===")
    
    # 方法1：通过环境变量配置
    print("方法1：设置环境变量 DASHSCOPE_API_KEY")
    print("export DASHSCOPE_API_KEY='your_api_key_here'")
    
    # 方法2：通过代码配置
    print("\n方法2：通过代码配置API密钥")
    from src.config import Config
    Config.set_dashscope_api_key('your_api_key_here')
    
    # 方法3：初始化时传入
    print("\n方法3：初始化时传入API密钥")
    analyzer = ExamAnalyzer(dashscope_api_key='your_api_key_here')
    
    # 测试AI连接
    print("\n=== 测试AI连接 ===")
    from src.dashscope_client import DashScopeClient
    try:
        client = DashScopeClient()
        if client.test_connection():
            print("✅ AI连接测试成功")
        else:
            print("❌ AI连接测试失败")
    except Exception as e:
        print(f"❌ AI连接测试失败: {e}")


def main():
    """主函数"""
    print("考研英语试卷分析智能体 - 使用示例")
    print("=" * 50)
    
    # 运行各种示例
    example_single_analysis()
    example_single_question()
    example_summary()
    example_ai_config()
    
    print("\n" + "=" * 50)
    print("示例运行完成！")
    print("\n使用说明:")
    print("1. 配置阿里云百炼API密钥:")
    print("   - 设置环境变量：export DASHSCOPE_API_KEY='your_api_key'")
    print("   - 或复制 .env.example 为 .env 并填入API密钥")
    print("2. 将你的考研英语真题保存为Markdown格式")
    print("3. 使用以下命令分析试卷:")
    print("   python main.py data/your_exam.md")
    print("4. 测试AI连接:")
    print("   python main.py --test-ai --dashscope-api-key your_api_key")
    print("5. 分析结果将保存在output目录中")
    print("\n更多选项请运行: python main.py --help")


if __name__ == "__main__":
    main()