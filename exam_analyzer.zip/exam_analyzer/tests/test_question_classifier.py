"""
题目分类器测试用例
"""

import unittest
from src.data_reader import Question
from src.question_classifier import QuestionClassifier, QuestionAnalysis


class TestQuestionClassifier(unittest.TestCase):
    """测试题目分类器"""
    
    def setUp(self):
        """测试前准备"""
        self.classifier = QuestionClassifier()
    
    def test_classify_reading_question_detail(self):
        """测试分类细节理解题"""
        question = Question(
            id="test_1",
            type="reading",
            passage="Technology has revolutionized education in recent years.",
            question_text="What has technology revolutionized according to the passage?",
            options=[
                "A. Education",
                "B. Healthcare",
                "C. Transportation",
                "D. Communication"
            ]
        )
        
        analysis = self.classifier.classify_question(question)
        
        self.assertEqual(analysis.question_type, "reading")
        self.assertEqual(analysis.sub_type, "detail")
        self.assertIn("technology", analysis.keywords)
        self.assertIn("revolutionized", analysis.keywords)
    
    def test_classify_reading_question_inference(self):
        """测试分类推理判断题"""
        question = Question(
            id="test_2",
            type="reading",
            passage="Many students struggle with online learning due to lack of motivation.",
            question_text="What can be inferred from the passage about online learning?",
            options=[
                "A. It is always effective",
                "B. It can be challenging for some students",
                "C. It is better than traditional learning",
                "D. All students prefer it"
            ]
        )
        
        analysis = self.classifier.classify_question(question)
        
        self.assertEqual(analysis.question_type, "reading")
        self.assertEqual(analysis.sub_type, "inference")
    
    def test_classify_reading_question_main_idea(self):
        """测试分类主旨大意题"""
        question = Question(
            id="test_3",
            type="reading",
            passage="The passage discusses the benefits and challenges of artificial intelligence in modern society.",
            question_text="What is the main idea of the passage?",
            options=[
                "A. AI is only beneficial",
                "B. AI has both advantages and disadvantages",
                "C. AI should be banned",
                "D. AI is not important"
            ]
        )
        
        analysis = self.classifier.classify_question(question)
        
        self.assertEqual(analysis.question_type, "reading")
        self.assertEqual(analysis.sub_type, "main_idea")
    
    def test_classify_cloze_question(self):
        """测试分类完形填空题"""
        question = Question(
            id="test_4",
            type="cloze",
            passage="Education has always been _____ important part of human society.",
            question_text="1. A. a  B. an  C. the  D. /",
            options=["A. a", "B. an", "C. the", "D. /"]
        )
        
        analysis = self.classifier.classify_question(question)
        
        self.assertEqual(analysis.question_type, "cloze")
        self.assertEqual(analysis.sub_type, "vocabulary_grammar")
    
    def test_classify_translation_question(self):
        """测试分类翻译题"""
        question = Question(
            id="test_5",
            type="translation",
            question_text="Translate the following sentence: Technology has revolutionized education."
        )
        
        analysis = self.classifier.classify_question(question)
        
        self.assertEqual(analysis.question_type, "translation")
        self.assertEqual(analysis.sub_type, "sentence_translation")
    
    def test_classify_writing_question(self):
        """测试分类写作题"""
        question = Question(
            id="test_6",
            type="writing",
            question_text="Write an essay of about 200 words on the topic 'The Importance of Education'."
        )
        
        analysis = self.classifier.classify_question(question)
        
        self.assertEqual(analysis.question_type, "writing")
        self.assertEqual(analysis.sub_type, "essay")
    
    def test_assess_difficulty_easy(self):
        """测试评估简单难度"""
        question = Question(
            id="test_7",
            type="reading",
            question_text="What is the main topic?",
            options=["A. Education", "B. Health", "C. Sports", "D. Music"]
        )
        
        analysis = self.classifier.classify_question(question)
        
        self.assertIn(analysis.difficulty, ['easy', 'medium', 'hard'])
    
    def test_assess_difficulty_hard(self):
        """测试评估困难难度"""
        long_question = Question(
            id="test_8",
            type="reading",
            question_text="According to the comprehensive analysis presented in the third paragraph, which of the following sophisticated factors most significantly contributes to the multifaceted challenges encountered in contemporary educational systems?",
            options=[
                "A. Simple technological issues",
                "B. Complex socioeconomic factors influencing educational accessibility and quality",
                "C. Basic teaching methods",
                "D. Standard curriculum problems"
            ]
        )
        
        analysis = self.classifier.classify_question(long_question)
        
        self.assertIn(analysis.difficulty, ['medium', 'hard'])
    
    def test_extract_keywords(self):
        """测试提取关键词"""
        question_text = "What are the main benefits of artificial intelligence in modern education?"
        passage = "Artificial intelligence offers numerous advantages for educational institutions."
        
        keywords = self.classifier._extract_keywords(question_text, passage)
        
        self.assertIn("main", keywords)
        self.assertIn("benefits", keywords)
        self.assertIn("artificial", keywords)
        self.assertIn("intelligence", keywords)
    
    def test_analyze_options(self):
        """测试分析选项"""
        options = [
            "A. AI is always beneficial and never causes problems",
            "B. AI has both advantages and disadvantages",
            "C. AI is more important than human intelligence",
            "D. AI will completely replace teachers"
        ]
        
        analysis = self.classifier._analyze_options(options)
        
        self.assertEqual(analysis['total_count'], 4)
        self.assertEqual(len(analysis['lengths']), 4)
        
        # 检查是否检测到绝对词
        self.assertTrue(
            any('absolute' in key for key in analysis['patterns'].keys()) or
            any('negative' in key for key in analysis['patterns'].keys())
        )
    
    def test_decompose_question(self):
        """测试拆解题目"""
        question_text = "According to the passage, what is the main reason for students' success?"
        
        parts = self.classifier._decompose_question(question_text)
        
        self.assertIn('question_word', parts)
        self.assertEqual(parts['question_word'], 'what')
        self.assertIn('condition', parts)
        self.assertIn('According to the passage', parts['condition'])
    
    def test_determine_reading_subtype(self):
        """测试确定阅读理解子类型"""
        # 测试细节题
        detail_text = "What specific information does the author provide about technology?"
        subtype = self.classifier._determine_reading_subtype(detail_text)
        self.assertEqual(subtype, 'detail')
        
        # 测试推理题
        inference_text = "What can be inferred from the author's argument?"
        subtype = self.classifier._determine_reading_subtype(inference_text)
        self.assertEqual(subtype, 'inference')
        
        # 测试主旨题
        main_idea_text = "What is the main purpose of this passage?"
        subtype = self.classifier._determine_reading_subtype(main_idea_text)
        self.assertEqual(subtype, 'main_idea')


if __name__ == '__main__':
    unittest.main()