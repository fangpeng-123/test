"""
数据读取模块测试用例
"""

import unittest
import tempfile
import os
from src.data_reader import ExamDataReader, Question, ExamData


class TestExamDataReader(unittest.TestCase):
    """测试数据读取器"""
    
    def setUp(self):
        """测试前准备"""
        self.reader = ExamDataReader()
        
        # 创建测试用的试卷内容
        self.test_content = """2024年考研英语真题

# 阅读理解

## Passage 1

This is the first passage for reading comprehension. It contains multiple sentences and paragraphs.

The passage discusses various topics related to education and technology. Many experts believe that technology will play an increasingly important role in education.

1. What is the main topic of the passage?
A. Education and technology
B. History of education
C. Future of technology
D. Social media impact

2. According to the passage, what do experts believe about technology?
A. It will replace teachers
B. It will play an important role in education
C. It is too expensive
D. It is not useful

## Passage 2

This is the second passage. It focuses on environmental issues and sustainability.

Climate change is one of the most pressing challenges facing humanity today.

3. What is the main concern discussed in this passage?
A. Economic development
B. Climate change
C. Education reform
D. Technology advancement

# 完形填空

Directions: Read the following passage and choose the best answer for each blank.

Education has always been (1)_____ important part of human society. It helps people develop their skills and knowledge.

1. A. a
B. an
C. the
D. /

# 翻译

Translate the following sentences into Chinese.

1. Technology has revolutionized the way we learn and teach.

# 写作

Directions: Write an essay of about 200 words on the topic "The Importance of Education in Modern Society".
"""
    
    def test_parse_exam_content(self):
        """测试解析试卷内容"""
        exam_data = self.reader.parse_exam_content(self.test_content)
        
        # 检查基本信息
        self.assertEqual(exam_data.year, 2024)
        self.assertIn("考研英语真题", exam_data.title)
        
        # 检查题目数量
        self.assertEqual(len(exam_data.questions), 6)  # 3阅读 + 1完形 + 1翻译 + 1写作
        
        # 检查阅读理解题目
        reading_questions = [q for q in exam_data.questions if q.type == 'reading']
        self.assertEqual(len(reading_questions), 3)
        
        # 检查第一题
        q1 = reading_questions[0]
        self.assertEqual(q1.id, "reading_1_1")
        self.assertIn("main topic", q1.question_text)
        self.assertEqual(len(q1.options), 4)
        self.assertIn("Education and technology", q1.options[0])
    
    def test_extract_header_info(self):
        """测试提取标题信息"""
        title, year = self.reader._extract_header_info(self.test_content)
        
        self.assertEqual(year, 2024)
        self.assertIn("考研英语真题", title)
    
    def test_split_by_question_type(self):
        """测试按题型分割"""
        sections = self.reader._split_by_question_type(self.test_content)
        
        self.assertIn('reading', sections)
        self.assertIn('cloze', sections)
        self.assertIn('translation', sections)
        self.assertIn('writing', sections)
    
    def test_parse_reading_questions(self):
        """测试解析阅读理解题目"""
        reading_section = sections = self.reader._split_by_question_type(self.test_content)['reading']
        questions = self.reader._parse_reading_questions(reading_section)
        
        self.assertEqual(len(questions), 3)
        
        # 检查第一题
        q1 = questions[0]
        self.assertEqual(q1.id, "reading_1_1")
        self.assertEqual(q1.type, "reading")
        self.assertIsNotNone(q1.passage)
        self.assertEqual(len(q1.options), 4)
    
    def test_parse_cloze_questions(self):
        """测试解析完形填空题目"""
        cloze_section = self.reader._split_by_question_type(self.test_content)['cloze']
        questions = self.reader._parse_cloze_questions(cloze_section)
        
        self.assertEqual(len(questions), 1)
        
        q1 = questions[0]
        self.assertEqual(q1.id, "cloze_1")
        self.assertEqual(q1.type, "cloze")
        self.assertIsNotNone(q1.passage)
    
    def test_parse_translation_questions(self):
        """测试解析翻译题目"""
        translation_section = self.reader._split_by_question_type(self.test_content)['translation']
        questions = self.reader._parse_translation_questions(translation_section)
        
        self.assertEqual(len(questions), 1)
        
        q1 = questions[0]
        self.assertEqual(q1.id, "translation_1")
        self.assertEqual(q1.type, "translation")
        self.assertIn("Technology has revolutionized", q1.question_text)
    
    def test_parse_writing_questions(self):
        """测试解析写作题目"""
        writing_section = self.reader._split_by_question_type(self.test_content)['writing']
        questions = self.reader._parse_writing_questions(writing_section)
        
        self.assertEqual(len(questions), 1)
        
        q1 = questions[0]
        self.assertEqual(q1.id, "writing_1")
        self.assertEqual(q1.type, "writing")
        self.assertIn("Importance of Education", q1.question_text)
    
    def test_read_markdown_file(self):
        """测试读取Markdown文件"""
        # 创建临时文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False, encoding='utf-8') as f:
            f.write(self.test_content)
            temp_file = f.name
        
        try:
            # 读取文件
            exam_data = self.reader.read_markdown_file(temp_file)
            
            # 验证结果
            self.assertEqual(exam_data.year, 2024)
            self.assertEqual(len(exam_data.questions), 6)
            
        finally:
            # 清理临时文件
            os.unlink(temp_file)


if __name__ == '__main__':
    unittest.main()