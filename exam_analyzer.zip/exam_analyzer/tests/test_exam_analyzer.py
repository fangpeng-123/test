"""
主程序测试用例
"""

import unittest
import tempfile
import os
from src.exam_analyzer import ExamAnalyzer


class TestExamAnalyzer(unittest.TestCase):
    """测试主程序"""
    
    def setUp(self):
        """测试前准备"""
        self.analyzer = ExamAnalyzer()
        
        # 创建测试用的试卷内容
        self.test_content = """2024年考研英语真题

# 阅读理解

## Passage 1

Technology has revolutionized education in recent years. Many schools now use digital tools to enhance learning experiences.

1. What is the main topic of the passage?
A. Technology and education
B. History of schools
C. Digital tools
D. Learning experiences

# 完形填空

Education has always been (1)_____ important part of society.

1. A. a
B. an
C. the
D. /

# 翻译

Translate the following sentence: Technology has changed the way we learn.

# 写作

Write an essay on "The Role of Technology in Education".
"""
    
    def test_analyze_exam(self):
        """测试分析试卷"""
        # 创建临时文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False, encoding='utf-8') as f:
            f.write(self.test_content)
            temp_file = f.name
        
        # 创建临时输出目录
        with tempfile.TemporaryDirectory() as temp_dir:
            try:
                # 分析试卷
                report_path = self.analyzer.analyze_exam(
                    temp_file, 
                    enable_source_tracking=False,  # 禁用溯源以避免网络请求
                    output_dir=temp_dir
                )
                
                # 检查报告是否生成
                self.assertTrue(os.path.exists(report_path))
                
                # 检查报告内容
                with open(report_path, 'r', encoding='utf-8') as f:
                    report_content = f.read()
                
                self.assertIn("2024年考研英语真题", report_content)
                self.assertIn("题型分布", report_content)
                self.assertIn("难度分布", report_content)
                
            finally:
                # 清理临时文件
                os.unlink(temp_file)
    
    def test_analyze_single_question(self):
        """测试分析单个题目"""
        question_text = "What is the main benefit of technology in education?"
        passage = "Technology provides many benefits for modern education systems."
        options = [
            "A. Cost reduction",
            "B. Improved learning experiences",
            "C. Less teacher involvement",
            "D. Simplified curriculum"
        ]
        
        analysis = self.analyzer.analyze_single_question(
            question_text, passage, options
        )
        
        self.assertEqual(analysis.question_type, "reading")
        self.assertIn("main", analysis.keywords)
        self.assertIn("benefit", analysis.keywords)
        self.assertIn("technology", analysis.keywords)
    
    def test_get_analysis_summary(self):
        """测试获取分析摘要"""
        # 创建临时文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False, encoding='utf-8') as f:
            f.write(self.test_content)
            temp_file = f.name
        
        try:
            # 获取摘要
            summary = self.analyzer.get_analysis_summary(temp_file)
            
            # 检查摘要结构
            self.assertIn('exam_info', summary)
            self.assertIn('statistics', summary)
            self.assertIn('question_types', summary)
            self.assertIn('difficulty_distribution', summary)
            
            # 检查基本信息
            self.assertEqual(summary['exam_info']['year'], 2024)
            self.assertEqual(summary['exam_info']['total_questions'], 4)
            
            # 检查题型分布
            self.assertIn('阅读理解', summary['question_types'])
            self.assertIn('完形填空', summary['question_types'])
            
        finally:
            # 清理临时文件
            os.unlink(temp_file)
    
    def test_batch_analyze(self):
        """测试批量分析"""
        # 创建多个临时文件
        temp_files = []
        for i in range(3):
            with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False, encoding='utf-8') as f:
                content = f"202{i+3}年考研英语真题\n\n# 阅读理解\n\nTest passage {i+1}.\n\n1. What is this?\nA. Test {i+1}\nB. Other\n"
                f.write(content)
                temp_files.append(f.name)
        
        # 创建临时输出目录
        with tempfile.TemporaryDirectory() as temp_dir:
            try:
                # 批量分析
                report_paths = self.analyzer.batch_analyze(
                    temp_files, 
                    output_dir=temp_dir
                )
                
                # 检查结果
                self.assertEqual(len(report_paths), 3)
                
                for path in report_paths:
                    self.assertTrue(os.path.exists(path))
                
            finally:
                # 清理临时文件
                for temp_file in temp_files:
                    os.unlink(temp_file)


if __name__ == '__main__':
    unittest.main()
