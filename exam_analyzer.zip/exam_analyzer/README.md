# 考研英语试卷分析智能体

基于LangChain框架开发的考研英语真题分析工具，能够对试卷进行全面分析并生成详细的MD格式报告。

## 功能特性

- 试卷数据读取和解析
- 题型分类和拆解
- 文章溯源分析
- 题型分类标注统计
- 技巧分析和统计
- MD格式文档生成

## 项目结构

```
exam_analyzer/
├── data/           # 试卷数据文件
├── src/            # 源代码
├── tests/          # 测试文件
├── output/         # 分析结果输出
└── requirements.txt # 依赖包列表
```

## 安装依赖

```bash
pip install -r requirements.txt
```

## 配置阿里云百炼API

### 方法1：环境变量配置
```bash
export DASHSCOPE_API_KEY="your_dashscope_api_key"
```

### 方法2：使用.env文件
```bash
cp .env.example .env
# 编辑.env文件，填入你的API密钥
```

### 方法3：代码中配置
```python
from src.config import Config
Config.set_dashscope_api_key("your_api_key")
```

## 使用方法

### 基本使用
```python
from src.exam_analyzer import ExamAnalyzer

# 使用AI增强分析
analyzer = ExamAnalyzer(use_ai=True)
result = analyzer.analyze_exam("path/to/exam_data.md")
analyzer.generate_report(result, "output/analysis_report.md")
```

### 命令行使用
```bash
# 基本分析
python main.py data/sample_exam.md

# 使用指定API密钥
python main.py data/sample_exam.md --dashscope-api-key your_api_key

# 测试AI连接
python main.py --test-ai --dashscope-api-key your_api_key

# 禁用AI分析（使用传统方法）
python main.py data/sample_exam.md --no-ai
```