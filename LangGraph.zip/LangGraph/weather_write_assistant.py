from  langchain.chat_models import init_chat_model
import os
import requests
from dotenv import load_dotenv
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from langgraph.prebuilt import create_react_agent
from langchain_tavily import TavilySearch

load_dotenv()
base_url = os.getenv("base_url")
api_key = os.getenv("api_key")
weather_api_key = os.getenv("weather_api_key")
tavily_api_key=os.getenv("tavily_api_key")

llm = init_chat_model(
    model="Qwen/Qwen3-8B",
    model_provider="openai",
    base_url=base_url,
    api_key=api_key
)

search_tool = TavilySearch(
    max_results=5,
    topic="general",
    tavily_api_key=tavily_api_key
)

class WeatherQuery(BaseModel):
    loc: str = Field(description="城市名称")

class WriteQuery(BaseModel):
    content: str = Field(description="需要写入文档的具体内容")

@tool(args_schema=WeatherQuery)
def get_weather(loc):
    """
        查询即时天气函数
        :param loc: 必要参数，字符串类型，用于表示查询天气的具体城市名称，\
        :return：心知天气 API查询即时天气的结果，具体URL请求地址为："https://api.seniverse.com/v3/weather/now.json"
        返回结果对象类型为解析之后的JSON格式对象，并用字符串形式进行表示，其中包含了全部重要的天气信息    
    """
    url = "https://api.seniverse.com/v3/weather/now.json"
    params = {
        "key": weather_api_key,
        "location": loc,
        "language": "zh-Hans",
        "unit": "c"
    }
    response = requests.get(url, params=params)
    temperature = response.json()
    return temperature['results'][0]['now']

@tool(args_schema=WriteQuery)
def write_file(content):
    """
    将指定内容写入本地文件。
    :param content: 必要参数，字符串类型，用于表示需要写入文档的具体内容。
    :return：是否成功写入    
    """
    with open('res.txt', 'w', encoding='utf-8') as f:
        f.write(content)
    return "已成功写入本地文件。"

tools = [get_weather, write_file, search_tool]

agent = create_react_agent(model=llm, tools=tools)

# try:
#     response = agent.invoke(
#         {
#             "messages": [
#                 {
#                     "role": "user",
#                     "content": "合肥和杭州今天天气怎么样？并把查询结果写入文件中。"
#                 }
#             ],
#         },
#         {
#             "recursion_limit": 4
#         },
#     )
#     print(response['messages'][-1].content)
# except Exception:
#     print('智能体由于超过最多调用次数而停止')

response = agent.invoke(
    {
        "messages": [
            {
                "role": "user",
                "content": "请帮我搜索最近 OpenAI CEO在访谈中的核心观点。"
            }
        ]
    }
)
print(response["messages"][-1].content)



# import os
# from dotenv import load_dotenv
# import requests
# from langchain_core.tools import tool
# from pydantic import BaseModel, Field
# from langchain.chat_models import init_chat_model
# from langgraph.prebuilt import create_react_agent

# load_dotenv()
# base_url=os.getenv("base_url")
# api_key=os.getenv("api_key")
# weather_api_key=os.getenv("weather_api_key")

# class WeatherQuery(BaseModel):
#     loc: str = Field(description="城市名称")

# class WriteQuery(BaseModel):
#     content: str = Field(description="需要写入文档的具体内容")

# @tool(args_schema=WeatherQuery)
# def get_weather(loc):
#     """
#         查询即时天气函数
#         :param loc: 必要参数，字符串类型，用于表示查询天气的具体城市名称，\
#         :return：心知天气 API查询即时天气的结果，具体URL请求地址为："https://api.seniverse.com/v3/weather/now.json"
#         返回结果对象类型为解析之后的JSON格式对象，并用字符串形式进行表示，其中包含了全部重要的天气信息
#     """
#     url = "https://api.seniverse.com/v3/weather/now.json"
#     params = {
#         "key": weather_api_key,
#         "location": loc,
#         "language": "zh-Hans",
#         "unit": "c",
#     }
#     response = requests.get(url, params=params)
#     temperature = response.json()
#     return temperature['results'][0]['now']

# @tool(args_schema=WriteQuery)
# def write_file(content):
#     """
#     将指定内容写入本地文件。
#     :param content: 必要参数，字符串类型，用于表示需要写入文档的具体内容。
#     :return：是否成功写入
#     """
#     with open('res.txt', 'w', encoding='utf-8') as f:
#         f.write(content)
#     return "已成功写入本地文件。"

# model = init_chat_model(
#     model='Qwen/Qwen3-8B',
#     model_provider='openai',
#     api_key=api_key,
#     base_url=base_url
# )

# tools = [get_weather, write_file]

# agent = create_react_agent(model=model, tools=tools)


# response = agent.invoke(
#     {
#         "messages": [
#             {
#                 "role": "user",
#                 "content": "北京和杭州现在的天气如何?并把查询结果写入文件中"
#             }
#         ]
#     }
# )

# print(response['messages'])
