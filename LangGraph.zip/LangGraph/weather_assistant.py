import requests
from langchain_core.tools import tool
from pydantic import BaseModel, Field

class WeatherQuery(BaseModel):
    loc: str = Field(description="城市名称")

# 创建工具
@tool(args_schema=WeatherQuery)
def get_weather(loc):
    """
        查询即时天气函数
        :param loc: 必要参数，字符串类型，用于表示查询天气的具体城市名称，\
        :return: 心知天气 API 查询即时天气的结果，具体 URL 请求地址为："https://api.seniverse.com/v3/weather/now.json"
        返回结果对象类型为解析之后的 JSON 格式对象，并用字符串形式进行表示，其中包含了全部重要的天气信息
    """
    url = "https://api.seniverse.com/v3/weather/now.json"
    params = {
        "key": "SUaojvLPfSQJD9N4k",
        "location": loc,
        "language": "zh-Hans",
        "unit": "c",
    }
    response = requests.get(url, params=params)
    temperature = response.json()
    return temperature['results'][0]['now']

print(f'''
name: {get_weather.name}
description: {get_weather.description}
arguments: {get_weather.args}
''')

# 声明模型
from langchain.chat_models import init_chat_model

model = init_chat_model(
    model="Qwen/Qwen3-8B",
    model_provider="openai",
    base_url="https://api.siliconflow.cn/v1/",
    api_key="sk-svrsbqfsmdepxorteqsydbovhryalhznqbeoragkbqmzmpsc"
)
# 声明工具
tools = [get_weather]

# 构建图结构智能体
from langgraph.prebuilt import create_react_agent

agent = create_react_agent(model=model, tools=tools)

response = agent.invoke(
    {
        "messages": [
            {
                "role": "user",
                "content": "合肥现在天气如何？"
            }
        ]
    }
)

print(response)