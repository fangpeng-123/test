from llama_index.core import SimpleDirectoryReader
# 加载目录下的 PDF
reader = SimpleDirectoryReader(input_dir="1.pdf", file_extractor={".pdf": "PDFReader"})
documents = reader.load_data()
print(f"已加载 {len(documents)} 篇文档")